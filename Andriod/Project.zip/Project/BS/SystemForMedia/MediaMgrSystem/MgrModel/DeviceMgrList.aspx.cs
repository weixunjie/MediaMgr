﻿using MediaMgrSystem.BusinessLayerLogic;
using MediaMgrSystem.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MediaMgrSystem.MgrModel
{
    public partial class DeviceMgrList : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Login.aspx");
            }


            if (!Page.IsPostBack)
            {


                string strIP = string.Empty;
                IPAddress[] arrIPAddresses = Dns.GetHostAddresses(Dns.GetHostName());
                foreach (IPAddress ip in arrIPAddresses)
                {
                    if (ip.AddressFamily.Equals(AddressFamily.InterNetwork))
                    {
                        strIP = ip.ToString();
                        break;
                    }
                }

                tbCurrentServerUrl.Text = ("http://" +Request.Url.Authority).Replace("localhost",strIP);

                BindListData();

                if (Request["pn"] != null)
                {
                    string strPn = Request["pn"].ToString();

                    int intPn = 0;
                    if (int.TryParse(strPn, out intPn))
                    {
                        if (dvList.PageCount >= intPn+1)
                        {
                            dvList.PageIndex = intPn ;
                            dvList.DataBind();
                        }
                    }
                }

            }
        }



  

        protected void Add_Click(object sender, EventArgs e)
        {

            Response.Redirect("~/MgrModel/DeviceMgrDetail.aspx?pn="+dvList.PageIndex);
        }


        private void BindListData()
        {
            List<DeviceInfo> dis = GlobalUtils.DeviceBLLInstance.GetAllDevices();
            List<DeviceInfo> disOnline = new List<DeviceInfo>();
            List<DeviceInfo> disOfflineline = new List<DeviceInfo>();

            List<DeviceInfo> all = new List<DeviceInfo>();
            if (dis != null)
            {
                foreach (var di in dis)
                {
                    List<string> ipReallySent = new List<string>();
                    if (GlobalUtils.GetConnectionIdsByIdentify(new List<string> { di.DeviceIpAddress }, SingalRClientConnectionType.ANDROID, out ipReallySent).Count > 0)
                    {
                        disOnline.Add(di);

                    }
                    else
                    {
                        disOfflineline.Add(di);
                    }
                }

            }

            all = disOnline;
            all.AddRange(disOfflineline);

            dvList.DataSource = all;
            dvList.DataBind();

        }

        protected void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < this.dvList.Rows.Count; i++)
            {
                ((CheckBox)this.dvList.Rows[i].FindControl("chkItem")).Checked =
                    ((CheckBox)this.dvList.HeaderRow.FindControl("chkAll")).Checked;
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            bool isDelSomething = false;
            for (int i = 0; i < this.dvList.Rows.Count; i++)
            {
                if (((CheckBox)this.dvList.Rows[i].FindControl("chkItem")).Checked)
                {
                    Label idLb = (Label)this.dvList.Rows[i].FindControl("lbId");

                    if (idLb != null && !string.IsNullOrEmpty(idLb.Text))
                    {
                        if (GlobalUtils.CheckIfPlaying())
                        {

                            ScriptManager.RegisterStartupScript(this.UpdatePanel1, this.GetType(), "alertForSheduleDetail", "alert('设备正在使用，不能删除');", true);

                            return;
                        }

                        GlobalUtils.DeviceBLLInstance.RemoveDevice(idLb.Text);
                        isDelSomething = true;
                    }
                }

            }

            if (isDelSomething)
            {
                BindListData();
            }
        }

        protected void dvGroupList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                Response.Redirect("~/MgrModel/DeviceMgrDetail.aspx?id=" + e.CommandArgument.ToString()+"&pn="+dvList.PageIndex);

            }
            else if (e.CommandName == "Del")
            {

                if (GlobalUtils.CheckIfPlaying())
                {
                    ScriptManager.RegisterStartupScript(this.UpdatePanel1, this.GetType(), "alertForDeviceList", "alert('设备正在使用，不能删除');", true);
                    return;
                }

                GlobalUtils.DeviceBLLInstance.RemoveDevice(e.CommandArgument.ToString());
                BindListData();
            }
        }

        protected void dvList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TableCell groupCell = e.Row.Cells[3];
                List<GroupInfo> result = GlobalUtils.GroupBLLInstance.GetGroupById(groupCell.Text);
                groupCell.Text = "默认分组";
                if (result != null && result.Count > 0)
                {
                    groupCell.Text = result[0].GroupName;
                }

                TableCell tbAudioCell = e.Row.Cells[5];

                TableCell tbVideoCell = e.Row.Cells[6];

                string strBusText = string.Empty;
                if (!string.IsNullOrWhiteSpace(tbAudioCell.Text) && !string.IsNullOrWhiteSpace(tbVideoCell.Text))
                {
                    if (tbAudioCell.Text.ToUpper() == "TRUE")
                    {

                        strBusText += "音频,";
                    }


                    if (tbVideoCell.Text.ToUpper() == "TRUE")
                    {

                        strBusText += "视频,";
                    }


                    strBusText = strBusText.TrimEnd(',');

                }

                tbVideoCell.Text = strBusText;

            }
        }

        protected void dvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            dvList.PageIndex = e.NewPageIndex;
            BindListData();

        }

        protected void dvList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.Cells.Count >= 6)
            {
                e.Row.Cells[5].Visible = false;
            }

        }


        private void  BroadcastMessage(byte[] message, int port)
        {
            using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
            {
                socket.EnableBroadcast = true;
                socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, true);
                IPEndPoint remoteEP = new IPEndPoint(IPAddress.Broadcast, port);
                socket.SendTo(message, remoteEP);
            }
        }

        protected void btnSendBroadcast_Click(object sender, EventArgs e)
        {
            BroadcastMessage(Encoding.ASCII.GetBytes("1@" + this.tbCurrentServerUrl.Text), 43708);
            ScriptManager.RegisterStartupScript(this.UpdatePanel1, base.GetType(), "braodcarmsg", "alert('广播已经发送，请等待终端连接。');", true);
        }
    }
}