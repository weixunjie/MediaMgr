package com.jld.jld.networkdebug.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

import microsoft.aspnet.signalr.client.ConnectionState;
import microsoft.aspnet.signalr.client.Logger;
import microsoft.aspnet.signalr.client.NullLogger;
import microsoft.aspnet.signalr.client.Platform;
import microsoft.aspnet.signalr.client.SignalRFuture;
import microsoft.aspnet.signalr.client.StateChangedCallback;
import microsoft.aspnet.signalr.client.http.android.AndroidPlatformComponent;
import microsoft.aspnet.signalr.client.hubs.HubConnection;
import microsoft.aspnet.signalr.client.hubs.HubProxy;
import microsoft.aspnet.signalr.client.hubs.SubscriptionHandler1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.jld.jld.networkdebug.utils.ProcessHelper;

import android.R;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.OperationApplicationException;
import android.media.AudioManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class MainService extends Service {

	private HubProxy hub = null;

	Context mContext = null;
	String sendingTotalTimes = "0";
	String url = "http://192.168.1.100:19671/signalr/hubs";

	public static final int MESSAGE_RESTARTCLIENT = 1;

	public static final int COMMANDSYNCGROUPS = 401;

	public static final int MESSAGE_REPLAY = 2;

	public static final int MESSAGE_RECONNECT = 3;

	public static final int COMMAND_MANUAL_CLOSE = 403;
	public static final int COMMAND_MANUAL_OPEN = 402;

	private ContentResolver mContentResolver = null;
	private boolean mIsClientRunning;

	public HubConnection conn;

	private String path;
	private boolean isSending = false;

	private String guidId;

	private boolean mIsConnected = false;

	private boolean mTestOpen = false;

	final String TAG = "NetDebug";
	private AudioManager mAudioManager = null;

	private double maxMusicAudio = 100;

	double maxAdb = 14;

	double lastAdbValue = -1;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onBind");
		return null;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onUnbind");
		return super.onUnbind(intent);
	}

	@Override
	public void onRebind(Intent intent) {
		// TODO Auto-generated method stub
		super.onRebind(intent);
		Log.i(TAG, "onRebind");
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.i(TAG, "onCreate");
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.i(TAG, "onDestroy");
	}

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);

		if (conn != null) {

			try {
				conn.stop();

			} catch (Exception ex) {

			}
			// conn.Stop();
			conn = null;
		}

		Platform.loadPlatformComponent(new AndroidPlatformComponent());

		mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

		// maxMusicAudio = mAudioManager
		// .getStreampeMaxVolume(AudioManager.STREAM_MUSIC);

		mContentResolver = this.getContentResolver();

		url = ProcessHelper.getMulticastAddr(this,
				"http://192.168.1.100:19671/signalr/hubs");

		mContext = this;

		try {
			connectToSignalRServer();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			// e.printtackTrace();
		}

		Log.i(TAG, "onStart");

	}

	Handler myHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			switch (msg.what) {
			case MESSAGE_RESTARTCLIENT:
				// notifyCommand(COMMAND_PLAY, bean, true);
				mIsClientRunning = true;
				break;

			case MESSAGE_RECONNECT:

				try {

					if (conn != null) {

						conn.stop();

						// conn.Stop();
						conn = null;
					}
					connectToSignalRServer();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// conn.Start();
				break;

			default:

			}
		}

	};

	private void sendFeedBackToServer(String error, String desp) {

		List<String> args = new ArrayList<String>();

		String js = "";

		JSONArray jsa = new JSONArray();
		JSONObject jo = new JSONObject();
		try {
			jo.put("guidId", guidId);
			jo.put("errorCode", error);
			jo.put("message", desp);
			jsa.put(0, jo);
			js = jsa.optString(0);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		args.add(js);
		if (conn != null) {
			args.add(conn.getConnectionId());
		}

		if (hub != null) {
			try {
				hub.invoke("SendEncoderAudioControlToMgrServer", js,
						conn.getConnectionId()).get();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public class TimeThread extends Thread {
		@Override
		public void run() {
			do {

				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (!sendingTotalTimes.equals("0")) {

					String fTime = ProcessHelper.getTimeValue(mContext,
							"Failed");

					Integer fTImeAdd = Integer.valueOf(fTime) + 1;

					ProcessHelper.setTimeValue(mContext, "Failed",
							String.valueOf(fTImeAdd));

					sendingTotalTimes = "0";
					MainActivity.commandNotice.command_Notice("1");
				}

				try {

					final String totalTimes = ProcessHelper.getTimeValue(
							mContext, "TotalTime");
					sendingTotalTimes = totalTimes;

					Integer totalAdd = Integer.valueOf(totalTimes) + 1;

					ProcessHelper.setTimeValue(mContext, "TotalTime",
							String.valueOf(totalAdd));

					MainActivity.commandNotice.command_Notice("1");

					Thread th = new Thread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								hub.invoke("SendDebugToMgrServer", totalTimes,
										conn.getConnectionId()).get();

							} catch (Exception ex) {
								// TODO Auto-generated catch block

							}
						}
					});
					th.start();

				} catch (Exception e) {
					e.printStackTrace();
				}
			} while (true);
		}
	}

	private void connectToSignalRServer() throws SocketException {
		if (mIsConnected) {
			return;
		}

		if (!url.startsWith("http://")) {
			url = "http://" + url;
		}

		if (url.indexOf("signalr/hubs") < 0) {
			url = url + "/signalr/hubs";
		}
		Log.i(TAG, "connection to url" + url);

		conn = new HubConnection(url,
				"clientType=ENCODERFORAUDIO&clientIdentify="
						+ ProcessHelper.getLocalIPAddress(), true,
				new NullLogger());

		conn.stateChanged(new StateChangedCallback() {

			@Override
			public void stateChanged(ConnectionState arg0, ConnectionState arg1) {

				if (arg1 == ConnectionState.Disconnected) {
					mIsConnected = false;
					ProcessHelper.IsSigalConncted = false;
					Log.i(TAG, "connection disconnected");
					// conn.Start();

					//MainActivity.statusChanged.status_change("�Ͽ�����");
					myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT, 5000);

				} else if (arg1 == ConnectionState.Reconnecting) {
					Log.i(TAG, "connection Reconnecting");
				} else if (arg1 == ConnectionState.Connected) {

					if (!isSending) {
						new TimeThread().start();
						isSending = true;
					}
					//MainActivity.statusChanged.status_change("������");
					// /sync device status

					ProcessHelper.GlobalConnection = conn;
					ProcessHelper.GlobalHub = hub;
					mIsConnected = true;

					ProcessHelper.IsSigalConncted = true;

				}
			};
		});

		hub = conn.createHubProxy("MediaMgrHub");

		hub.on("sendDebugToClient", new SubscriptionHandler1<String>() {
			@Override
			public void run(String status) {
				{

					if (sendingTotalTimes.equals(status)) {

						String fTime = ProcessHelper.getTimeValue(mContext,
								"Suc");

						Integer fTImeAdd = Integer.valueOf(fTime) + 1;

						ProcessHelper.setTimeValue(mContext, "Suc",
								String.valueOf(fTImeAdd));

						sendingTotalTimes = "0";
						MainActivity.commandNotice.command_Notice("1");
					}

					// try {
					// JSONObject resultObject = null;
					//
					// resultObject = new JSONObject(status);
					//
					// guidId = resultObject.get("guidId").toString();
					//
					// if (guidId.equals(ProcessHelper.RequestGuidId)) {
					// if (ProcessHelper.IsReqeustToOpen) {
					// JSONObject argObject = new JSONObject(
					// resultObject.get("arg")
					// .toString());
					//
					// String baudRate = argObject.get(
					// "baudRate").toString();
					// String udpBroadcastAddress = argObject
					// .get("udpBroadcastAddress")
					// .toString();
					//
					// ProcessHelper.startEncoder(baudRate,
					// udpBroadcastAddress);
					// MainActivity.commandNotice
					// .command_Notice("1");
					// } else {
					// ProcessHelper.stopEncoder();
					// MainActivity.commandNotice
					// .command_Notice("2");
					// }
					// }
					//
					// else {
					//
					// int commandType = Integer
					// .parseInt(resultObject.get(
					// "commandType").toString());
					//
					// Log.i(TAG, "commandType: " + commandType);
					//
					// if (commandType == COMMAND_MANUAL_OPEN) {
					//
					// JSONObject argObject = new JSONObject(
					// resultObject.get("arg")
					// .toString());
					//
					// String baudRate = argObject.get(
					// "baudRate").toString();
					// String udpBroadcastAddress = argObject
					// .get("udpBroadcastAddress")
					// .toString();
					//
					// ProcessHelper.startEncoder(baudRate,
					// udpBroadcastAddress);
					// sendFeedBackToServer("0", "");
					//
					// } else if (commandType == COMMAND_MANUAL_CLOSE) {
					//
					// ProcessHelper.stopEncoder();
					// sendFeedBackToServer("0", "");
					// // stop play
					// } else if (commandType == COMMANDSYNCGROUPS) {
					//
					// JSONArray groupList = new JSONArray(
					// resultObject.get("groups")
					// .toString());
					//
					// String groupids = "";
					// String groupNames = "";
					//
					// for (int i = 0; i < groupList.length(); i++) {
					// JSONObject argObject = new JSONObject(
					// groupList.get(i).toString());
					// String gid = argObject.get(
					// "groupId").toString();
					// String gn = argObject.get(
					// "groupName").toString();
					// groupids = groupids + gid + ",";
					// groupNames = groupNames + gn + ",";
					//
					// }
					//
					// groupids = groupids.substring(0,
					// groupids.length() - 1);
					// groupNames = groupNames.substring(0,
					// groupNames.length() - 1);
					//
					// ProcessHelper.setGroupIds(mContext,
					// groupids);
					// ProcessHelper.setGroupNames(mContext,
					// groupNames);
					//
					// MainActivity.commandNotice
					// .command_Notice("3");
					// // ProcessHelper.stopEncoder();
					// // sendFeedBackToServer(0,"");
					// // stop play
					// }
					//
					// }
					//
					// } catch (JSONException e) {
					// // TODO Auto-generated catch block
					// e.printStackTrace();
					// }
				}
			}
		}, String.class);

		// hub.On("sendRemoteControlToClient", new HubOnDataCallback() {
		// @Override
		// public void OnReceived(JSONArray args)
		//
		// });

		SignalRFuture<Void> awaitConnection = conn.start();
		try {
			awaitConnection.get();
		} catch (InterruptedException e) {

			String aa = "sf";

			// Handle ...
		} catch (ExecutionException e) {

			String aa = "sf";
			// Handle ...
		}
		// conn.Start();
	}
}
