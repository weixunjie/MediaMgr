USE [MediaMgrSystem]
GO

/****** Object:  Table [dbo].[ChannelInfo]    Script Date: 10/24/2014 10:42:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UpgradeInfo](
	[VersionId] [nvarchar](50) NULL,
	[UpgardeURL] [nvarchar](650) NULL,
	
) ON [PRIMARY]

GO


