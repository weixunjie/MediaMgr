package com.jld.jld.audiobroadcast.client.server;
public interface AudioServiceApi {
	public int init(int channels, int smaple,String addr,int port);
	public int start(boolean playback);
	public int stop();
}