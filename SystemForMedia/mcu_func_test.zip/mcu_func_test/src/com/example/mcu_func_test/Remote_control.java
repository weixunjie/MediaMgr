package com.example.mcu_func_test;


import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.os.Build;

import android.hardware.SerialManager;
import android.hardware.SerialPort;
import java.nio.ByteBuffer;
import java.io.IOException;

public class Remote_control extends Activity {
	private Button  bt_shutdown;
	private Button  bt_restart;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_remote_control);
		  bt_shutdown=(Button) findViewById(R.id.remote_shutdown);
		  bt_restart=(Button) findViewById(R.id.remote_restart);
		  bt_shutdown.setOnClickListener(new OnClickListener() {
		   
		   @Override
		   public void onClick(View v) {
		    // TODO Auto-generated method stub

		 	if(MainActivity.mSerialManager.shutdown_system())
		
		  	 Log.e("pengyong", "remote_shutdown ok");
			else
				
		  	 Log.e("pengyong", "remote_shutdown fail");
		   }
		  });
		  bt_restart.setOnClickListener(new OnClickListener() {
		   
		   @Override
		   public void onClick(View v) {
		    // TODO Auto-generated method stub
		 	if(MainActivity.mSerialManager.restart_system())

		    		Log.e("pengyong", "remote_restart ok");
		
			else

		    		Log.e("pengyong", "remote_restart fail");
		   }
		  });
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.remote_control, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_remote_control,
					container, false);
			return rootView;
		}
	}

}
