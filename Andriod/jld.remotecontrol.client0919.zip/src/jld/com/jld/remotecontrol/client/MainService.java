package jld.com.jld.remotecontrol.client;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.datamodels.DeviceInfo;
import com.example.iot.iot;
import com.example.iot.iot_observable;
import com.example.iot.state_observable;
import com.model.utils.DeviceOperation;
import com.model.utils.StorageHelper;
import com.zsoft.SignalA.ConnectionState;
import com.zsoft.SignalA.Hubs.HubConnection;
import com.zsoft.SignalA.Hubs.HubInvokeCallback;
import com.zsoft.SignalA.Hubs.HubOnDataCallback;
import com.zsoft.SignalA.Hubs.IHubProxy;
import com.zsoft.SignalA.Transport.StateBase;
import com.zsoft.SignalA.Transport.Longpolling.ConnectedState;
import com.zsoft.SignalA.Transport.Longpolling.LongPollingTransport;

import android.R;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.OperationApplicationException;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

public class MainService extends Service {

	private IHubProxy hub = null;

	Context mContext = null;

	String url = "http://192.168.1.100:19671/signalr/hubs";

	public static final String COMMAND_PLAY = "multicastplayer_play";
	public static final String COMMAND_STOP = "multicastplayer_stop";

	public static final String COMMAND_QUIT = "multicastplayer_QUIT";

	public static final int MESSAGE_RESTARTCLIENT = 1;

	public static final int MESSAGE_REPLAY = 2;

	public static final int MESSAGE_RECONNECT = 3;

	public static final int COMMAND_MANUAL_OPEN = 221;

	public static final int COMMAND_MANUAL_CLOSE = 222;

	public static final int REMOTE_CONTRL_SEND_STATUS = 231;

	private ContentResolver mContentResolver = null;
	private boolean mIsClientRunning;

	private iot iot_hw;

	private ConnectedState mState;

	public HubConnection conn;

	private String path;

	private String guidId;

	private state_observable state_callback;
	private boolean mIsConnected = false;

	private boolean mTestOpen = false;

	final String TAG = "Service";

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onBind");
		return null;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onUnbind");
		return super.onUnbind(intent);
	}

	@Override
	public void onRebind(Intent intent) {
		// TODO Auto-generated method stub
		super.onRebind(intent);
		Log.i(TAG, "onRebind");
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.i(TAG, "onCreate");
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.i(TAG, "onDestroy");
	}

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);

		mContentResolver = this.getContentResolver();

		url = StorageHelper.getMulticastAddr(this,
				"http://192.168.1.100:19671/signalr/hubs");

		mContext = this;

		try {
			connectToSignalRServer();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		iot_observable observable = new iot_observable() {

			@Override
			public int device_registered_callback(String device_id,
					int _port_number) {

				MainActivity.registerCallFromService.reg_done(device_id,
						_port_number);
				return 0;

			}
		};

		state_callback = new state_observable() {

			@Override
			public int state_callback(String device_id, int port, int state) {

				Log.e("Service", "state_callback   id=" + device_id + "state="
						+ state + "port=" + port);

				String foundType = "";
				for (int i = 1; i <= 5; i++) {
					DeviceInfo di = StorageHelper.getDeviceInfo(mContext,
							String.valueOf(i));
					if (di != null) {

						if (di.getDeviceId().equals(device_id)) {

							foundType = di.getDeviceType();
							break;
						}
					}
				}

				if (!foundType.equals("")) {
					sendDeviceStatusToServer(foundType, String.valueOf(port),
							String.valueOf(state));
				}

				return 0;

			}

		};

		iot_hw = new iot(observable, state_callback);

		// Do it weixunjie
	    iot_hw.init();

		DeviceOperation.ioClass = iot_hw;

		Log.i(TAG, "onStart");

	}

	private void sendDeviceStatusToServer(String deviceType, String port,
			String state) {
		List<String> args = new ArrayList<String>();

		String js = "";

		JSONArray jsa = new JSONArray();
		JSONObject jo = new JSONObject();
		try {
			jo.put("commandType", REMOTE_CONTRL_SEND_STATUS);
			jo.put("guidId", guidId);
			jo.put("deviceType", deviceType);
			jo.put("port", port);
			jo.put("state", state);
			jsa.put(0, jo);
			js = jsa.optString(0);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		args.add(js);
		if (conn != null) {
			args.add(conn.getConnectionId());
		}

		if (hub != null) {
			hub.Invoke("SendRemoteControlToMgrServer", args,
					new HubInvokeCallback() {

						@Override
						public void OnResult(boolean succeeded, String response) {
							// TODO Auto-generated method stub
							Log.d(TAG, " send result to server"
									+ (succeeded ? "success" : "failed"));
						}

						@Override
						public void OnError(Exception ex) {
							// TODO Auto-generated method stub
							Log.d(TAG,
									" send result to server exception:"
											+ ex.toString());
						}
					});

		}

	}

	private String getLocalIPAddress() throws SocketException {
		for (Enumeration<NetworkInterface> en = NetworkInterface
				.getNetworkInterfaces(); en.hasMoreElements();) {
			NetworkInterface intf = en.nextElement();
			for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr
					.hasMoreElements();) {
				InetAddress inetAddress = enumIpAddr.nextElement();
				if (!inetAddress.isLoopbackAddress()
						&& (inetAddress instanceof Inet4Address)) {
					return inetAddress.getHostAddress().toString();
				}
			}
		}
		return "null";
	}

	Handler myHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			switch (msg.what) {
			case MESSAGE_RESTARTCLIENT:
				// notifyCommand(COMMAND_PLAY, bean, true);
				mIsClientRunning = true;
				break;

			case MESSAGE_RECONNECT:

				try {

					if (conn != null) {
						conn.Stop();
						conn = null;
					}
					connectToSignalRServer();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// conn.Start();
				break;

			default:

			}
		}

	};

	private void sendFeedBackToServer(String error, String desp) {

		List<String> args = new ArrayList<String>();

		String js = "";

		JSONArray jsa = new JSONArray();
		JSONObject jo = new JSONObject();
		try {
			jo.put("guidId", guidId);
			jo.put("errorCode", error);
			jo.put("message", desp);
			jsa.put(0, jo);
			js = jsa.optString(0);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		args.add(js);
		if (conn != null) {
			args.add(conn.getConnectionId());
		}

		if (hub != null) {
			hub.Invoke("SendRemoteControlToMgrServer", args,
					new HubInvokeCallback() {

						@Override
						public void OnResult(boolean succeeded, String response) {
							// TODO Auto-generated method stub
							Log.d(TAG, " send result to server"
									+ (succeeded ? "success" : "failed"));
						}

						@Override
						public void OnError(Exception ex) {
							// TODO Auto-generated method stub
							Log.d(TAG,
									" send result to server exception:"
											+ ex.toString());
						}
					});
		}

	}

	private void connectToSignalRServer() throws SocketException {
		if (mIsConnected) {
			return;
		}

		if (!url.startsWith("http://")) {
			url = "http://" + url;
		}

		if (url.indexOf("signalr/hubs") < 0) {
			url = url + "/signalr/hubs";
		}

		conn = new HubConnection(url, this, new LongPollingTransport(),
				"clientType=REMOTECONTORLDEVICE&clientIdentify="
						+ getLocalIPAddress()) {
			@Override
			public void OnError(Exception exception) {
				// myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT, 5000);
			}

			@Override
			public void OnMessage(String message) {

			}

			@Override
			public void OnStateChanged(StateBase oldState, StateBase newState) {

				if (newState.getState() == ConnectionState.Disconnected) {
					mIsConnected = false;
					Log.i(TAG, "connection disconnected");
					// conn.Start();
					myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT, 5000);
				} else if (newState.getState() == ConnectionState.Reconnecting) {
					Log.i(TAG, "connection Reconnecting");
				} else if (newState.getState() == ConnectionState.Connected) {

					// /sync device status

					mIsConnected = true;

					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					for (int i = 1; i <= 5; i++) {
						DeviceInfo di = StorageHelper.getDeviceInfo(mContext,
								String.valueOf(i));

						if (di != null) {

							int staes = iot_hw.get_state(di.getDeviceId(),
									Integer.valueOf(di.getPortNumber()));

							sendDeviceStatusToServer(di.getDeviceType(),
									String.valueOf(di.getPortNumber()),
									String.valueOf(staes));

						}
					}

					// Toast.makeText(mContext, R.string.serversucess,
					// Toast.LENGTH_SHORT).show();
				}
			}
		};

		try {
			hub = conn.CreateHubProxy("MediaMgrHub");

		} catch (OperationApplicationException e) {
			e.printStackTrace();
		}

		hub.On("sendRemoteControlToClient", new HubOnDataCallback() {
			@Override
			public void OnReceived(JSONArray args) {
				try {
					JSONObject resultObject = null;

					for (int i = 0; i < args.length(); i++) {
						resultObject = new JSONObject(args.opt(i).toString());
					}

					String command = null;

					int commandType = Integer.parseInt(resultObject.get(
							"commandType").toString());

					guidId = resultObject.get("guidId").toString();

					Log.i(TAG, "commandType: " + commandType);

					if (commandType == COMMAND_MANUAL_OPEN) {

						processManuOper(resultObject, true);

					} else if (commandType == COMMAND_MANUAL_CLOSE) {

						processManuOper(resultObject, false);
						// stop play
					}

					// notifyCommand(command, bean, mIsClientRunning);
					// hub.Invoke("sendPlayResponseMessage", args, null);

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});
		conn.Start();
	}

	private String getDeviceDisplayByType(String deviceType) {
		if (deviceType.equals(DeviceOperation.DEVICE_AC)) {
			return mContext
					.getString(jld.com.jld.remotecontrol.client.R.string.ac_display);
		} else if (deviceType.equals(DeviceOperation.DEVICE_TV)) {
			return mContext
					.getString(jld.com.jld.remotecontrol.client.R.string.tv_display);
		} else if (deviceType.equals(DeviceOperation.DEVICE_PROJECTOR)) {
			return mContext
					.getString(jld.com.jld.remotecontrol.client.R.string.projector_display);
		} else if (deviceType.equals(DeviceOperation.DEVICE_PC)) {
			return mContext
					.getString(jld.com.jld.remotecontrol.client.R.string.computer_display);
		} else if (deviceType.equals(DeviceOperation.DEVICE_LIGHT)) {
			return mContext
					.getString(jld.com.jld.remotecontrol.client.R.string.ligtht_display);
		}

		return "";
	}

	private void processManuOper(JSONObject resultObject, boolean isOpen) {
		JSONObject argObject;
		try {
			argObject = new JSONObject(resultObject.get("arg").toString());

			String devicesType = argObject.get("devicesType").toString();

			if (devicesType != null && !devicesType.equals("")) {

				String[] strs = devicesType.split(",");

				if (strs != null && strs.length > 0) {
					for (int i = 0; i < strs.length; i++) {

						String deviceType = strs[i];

						String operText = "��";

						if (!isOpen) {
							operText = "�ر�";
						}
						DeviceInfo di = StorageHelper.getDeviceInfo(mContext,
								deviceType);

						if (di != null) {

							JSONObject paramsDataObject = new JSONObject(
									argObject.get("paramsData").toString());

							String acTemperature = paramsDataObject.get(
									"acTemperature").toString();

							String acMode = paramsDataObject.get("acMode")
									.toString();

							boolean oResult = DeviceOperation.setStatus(di,
									isOpen, acMode, acTemperature);

							if (oResult) {
								sendFeedBackToServer("0",

								getDeviceDisplayByType(deviceType) + operText
										+ "�ɹ�");
							} else {
								sendFeedBackToServer("0",

								getDeviceDisplayByType(deviceType) + operText
										+ "ʧ��");
							}

						} else {
							sendFeedBackToServer("21",

							getDeviceDisplayByType(deviceType) + "δע��");
						}

					}
				}

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
