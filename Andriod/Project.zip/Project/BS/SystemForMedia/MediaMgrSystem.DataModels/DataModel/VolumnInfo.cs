﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class VolumnInfo
    {
        public String IpAddress { get; set; }

        public String ScheduleOpenTime { get; set; }

        public String ScheduleCloseTime { get; set; }

        public String IsEnabledSchedule { get; set; }

        public String VolumValue { get; set; }

    }

}
