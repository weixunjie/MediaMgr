﻿package com.jld.jld.audiobroadcast.client.server;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.renderscript.Sampler;
import android.util.Log;

public class AudioServiceImpl implements AudioServiceApi {

	public static final String TAG = AudioServiceImpl.class.getName();

	MulticastSocket s;
	InetAddress group;
	boolean mDone = false;
	boolean mStopSend = false;
	int readBufferSize = 1056;
	int mSampleRate = 44100;
	int mChannels = 2;
	boolean mPlayback;

	File mFile;
	FileOutputStream mOutput;
	BufferedOutputStream mBufferOutput;

	String mAddr = "229.0.0.1";
	int mPort = 1236;

	Queue<byte[]> mQueue = new LinkedList<byte[]>();

	ArrayList<byte[]> mList = new ArrayList<byte[]>();

	@Override
	public int start(boolean playback) {
		boolean ret = false;

		new Thread(new CaptureThread()).start();
		// new Thread(new SendThread()).start();
		ret = true;
		mDone = false;
		mPlayback = playback;

		// String file = "sdcard/pcm.pcm";
		// mFile = new File(file);
		// if (mFile.exists()) {
		// mFile.delete();
		// }
		//
		// try {
		// mFile.createNewFile();
		// mOutput = new FileOutputStream(mFile);
		// mBufferOutput = new BufferedOutputStream(mOutput);
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		return 0;
	}

	public int stop() {
		mDone = true;
		return 0;
	}

	public synchronized byte[] getBuffer() {
		Log.d("AudioServer", "getBuffer" + mQueue.size());
		if (mQueue != null && mQueue.size() > 0) {
			byte[] buffer = mQueue.poll();
			return buffer;
		}
		return null;
	}

	public synchronized void putBuffer(byte[] buffer) {
		if (mQueue != null) {
			mQueue.add(buffer);
		}
	}

	public void initnetwork() {
		try {
			if (mAddr != null && mAddr != "" && mAddr.startsWith("udp://")) {
				mAddr = mAddr.substring(6);
				Log.d(TAG, "host:" + mAddr);
			}
			group = InetAddress.getByName(mAddr);
			s = new MulticastSocket(mPort);
			s.setSendBufferSize(2048);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendData(byte[] buffer) {
		if (buffer == null) {
			return;
		}

		DatagramPacket packet = new DatagramPacket(buffer, buffer.length,
				group, mPort);
		try {
			s.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public class CaptureThread implements Runnable {
		public void run() {

			try {
				initnetwork();

				int channelConfig = AudioFormat.CHANNEL_CONFIGURATION_STEREO;

				if (mChannels == 1) {
					channelConfig = AudioFormat.CHANNEL_CONFIGURATION_MONO;
				}

				int minBuffSize = AudioRecord.getMinBufferSize(mSampleRate,
						AudioFormat.CHANNEL_CONFIGURATION_STEREO,
						AudioFormat.ENCODING_PCM_16BIT);
				AudioRecord mAudioRecorder = new AudioRecord(
						MediaRecorder.AudioSource.MIC, mSampleRate,
						channelConfig, AudioFormat.ENCODING_PCM_16BIT,
						minBuffSize * 2);
				// 开始录音
				mAudioRecorder.startRecording();
				try {
					group = InetAddress.getByName(mAddr);
					s = new MulticastSocket(mPort);
					Log.d(TAG, "start to read pcm data");
					byte[] mBuffer = new byte[readBufferSize];
					while (!mDone) {
						int len = mAudioRecorder.read(mBuffer, 0,
								readBufferSize);

						// putBuffer(mBuffer);

						// Log.d(TAG, "read pcm data:" + len);
						if (!mStopSend) {
							DatagramPacket packet = new DatagramPacket(mBuffer,
									(int) len, group, mPort);
							try {
								s.send(packet);
								// if (mBufferOutput != null) {
								// mBufferOutput.write(mBuffer);
								// }
								//
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}

					if (mBufferOutput != null) {
						mBufferOutput.close();
						mOutput.close();

						mBufferOutput = null;
						mOutput = null;
						mFile = null;
					}

					mAudioRecorder.stop();
					mAudioRecorder = null;
					if (s != null) {
						s.close();
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			} catch (Exception ex2) {
				Log.e("WX", ex2.getMessage());
			}
		}
	}

	@Override
	public int init(int channels, int sample, String addr, int port) {
		// TODO Auto-generated method stub
		if (channels > 2 || channels < 1) {
			channels = 2;
		}
		this.mChannels = channels;

		if (sample < 0) {
			return 0;
		}

		if (addr == null || "".equals(addr) || port < 0 || port > 65535) {
			return -1;
		}

		this.mAddr = addr;
		this.mPort = port;
		return 0;
	}

	public class SendThread implements Runnable {
		public void run() {
			while (!mDone) {
				sendData(getBuffer());
			}
		}
	}

}
