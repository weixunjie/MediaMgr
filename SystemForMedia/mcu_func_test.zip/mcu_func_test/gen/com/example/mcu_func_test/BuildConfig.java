/** Automatically generated file. DO NOT MODIFY */
package com.example.mcu_func_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}