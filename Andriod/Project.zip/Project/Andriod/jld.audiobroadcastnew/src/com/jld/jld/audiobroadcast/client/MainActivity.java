package com.jld.jld.audiobroadcast.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.jld.jld.audiobroadcast.utils.ProcessHelper;

import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.util.Log;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.os.Build;

public class MainActivity extends Activity {

	private ArrayList<String> checkBoxList = new ArrayList<String>();

	private Uri uriToPlay;
	private ImageView imgNewworkStatus;
	private TextView tvShowTime;

	private CheckBoxList cbList;

	private Button btnStartCall;

	private Button btnStopCall;
	private TextView tvVolValue;
	MediaPlayer player = new MediaPlayer();
	private Button btnAddVol;

	private boolean isShowGroupInfo = false;
	private ProgressDialog proDialogForNoNewWork;
	private ProgressDialog proDialog;
	private Button btnDecreaseVol;

	private AudioManager mAudioManager = null;

	private int maxMusicAudio = 100;

	private int currentVolToSet = 0;

	private Context mContext;
	private ArrayList<String> groupListIds;
	private ArrayList<String> groupListNames;

	private ArrayList<String> classListIds;
	private ArrayList<String> classListNames;

	private Button btnCallbyGroup;
	private Button btnCallAll;
	private Button btnCallbyClass;
	private GridView gvGroupList;

	public interface statusChangedInterface {
		public void status_change(boolean isConnected, String statusText);
	}

	public static statusChangedInterface statusChanged;

	public interface commandNoticeInteface {
		public void command_Notice(String isOpen, String message);
	}

	public static commandNoticeInteface commandNotice;

	public interface networkNoticeInteface {
		public void networkNotice(String isOpen, String message);
	}

	public static networkNoticeInteface networkNotice;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mContext = this;

		LinearLayout llMain = (LinearLayout) findViewById(R.id.llLeftMain);

		LayoutParams lp = new LayoutParams(dip2px(px2dip(800) - 200),
				LayoutParams.FILL_PARENT);

		llMain.setLayoutParams(lp);

		gvGroupList = (GridView) findViewById(R.id.gvGroupList);

		tvVolValue = (TextView) findViewById(R.id.tvVolValue);

		btnAddVol = (Button) findViewById(R.id.btnAddVol);
		btnDecreaseVol = (Button) findViewById(R.id.btnDecreaseVol);

		mAudioManager = (AudioManager) getSystemService(this.AUDIO_SERVICE);

		maxMusicAudio = mAudioManager
				.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

		currentVolToSet = mAudioManager
				.getStreamVolume(AudioManager.STREAM_MUSIC);

		String strVol = String.valueOf(currentVolToSet);
		if (currentVolToSet < 10) {
			strVol = "0" + strVol;

		}

		tvVolValue.setText("(" + strVol + ")");

		btnAddVol.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				if (currentVolToSet < maxMusicAudio) {
					currentVolToSet++;
				}

				String strVol = String.valueOf(currentVolToSet);
				if (currentVolToSet < 10) {
					strVol = "0" + strVol;

				}

				mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
						currentVolToSet, AudioManager.FLAG_PLAY_SOUND);
				tvVolValue.setText("(" + strVol + ")");

			}
		});

		btnDecreaseVol.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				if (currentVolToSet > 0) {
					currentVolToSet--;
				}
				mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
						currentVolToSet, AudioManager.FLAG_PLAY_SOUND);

				String strVol = String.valueOf(currentVolToSet);
				if (currentVolToSet < 10) {
					strVol = "0" + strVol;

				}

				tvVolValue.setText("(" + strVol + ")");

			}
		});

		imgNewworkStatus = (ImageView) findViewById(R.id.imageNetwork);

		tvShowTime = (TextView) findViewById(R.id.tvShowTime);
		cbList = new CheckBoxList(this);

		// / //cbAllGroups = (CheckBox) findViewById(R.id.cbAllGroups);

		// cbAllGroups.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		// //
		// // Intent intent = new Intent();
		// // intent.setAction(Intent.ACTION_GET_CONTENT);
		// // intent.setType("audio/*");
		// // startActivityForResult(intent, 0);
		//
		// for (int i = 0; i < checkBoxSates.size(); i++) {
		// Integer status = 0;
		// if (cbAllGroups.isChecked()) {
		// status = 1;
		// }
		// checkBoxSates.set(i, status);
		//
		// }
		//
		// cbList.notifyDataSetChanged();
		//
		// }
		// });

		String url = ProcessHelper.getMulticastAddr(this, "");

		if (url.equals("")) {
			showSettingDialog();
		} else {

			if (ProcessHelper.isServiceRunning(this)) {
				Intent intent = new Intent();
				intent.setClass(this, MainService.class);
				this.stopService(intent);

			} else {

				Intent intent = new Intent();
				intent.setClass(this, MainService.class);
				startService(intent);
				// finish();
			}
		}

		regCallBack();
		gvGroupList.setAdapter(cbList);
		loadGroupsInfo(null, null);

		btnCallbyGroup = (Button) findViewById(R.id.btnCallbyGroup);

		btnCallbyGroup.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(mContext,
						ActivityChooseGroupClass.class);

				intent.putExtra("IsByGroup", "Y");
				startActivityForResult(intent, 200);
			}
		});

		btnCallAll = (Button) findViewById(R.id.btnCallAll);

		btnCallAll.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				ArrayList<String> gIdArray = ProcessHelper.getGroupIds(
						mContext, "");

				ArrayList<String> gNameArray = ProcessHelper.getGroupNames(
						mContext, "");
				// TODO Auto-generated method stub

				loadGroupsInfo(gIdArray, gNameArray);
				if (ProcessHelper.IsSigalConncted) {
					openVoiceCall(
							ProcessHelper.getGroupIdStrings(mContext, ""), "");
				}

			}
		});

		btnCallbyClass = (Button) findViewById(R.id.btnCallbyClass);

		btnCallbyClass.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(mContext,
						ActivityChooseGroupClass.class);

				intent.putExtra("IsByGroup", "N");
				startActivityForResult(intent, 200);
			}
		});

		btnStartCall = (Button) findViewById(R.id.btnStartCall);
		btnStopCall = (Button) findViewById(R.id.btnStopCall);

		btnStopCall.setVisibility(View.GONE);
		btnStartCall.setVisibility(View.GONE);

		// btnStartCall.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// String groupIds = "";
		// boolean isNotSelectedGroup = true;
		// for (int i = 0; i < checkBoxSates.size(); i++) {
		//
		// if (checkBoxSates.get(i) == 1) {
		// isNotSelectedGroup = false;
		// groupIds = groupIds + groupListIds.get(i) + ",";
		// }
		//
		// }
		//
		// if (isNotSelectedGroup) {
		// Dialog alertDialog = new AlertDialog.Builder(mContext)
		// .setTitle("ºô½ÐÌ¨²Ù×÷")
		// .setPositiveButton("È·ÈÏ", new OnClickListener() {
		//
		// @Override
		// public void onClick(DialogInterface arg0,
		// int arg1) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// }).setMessage("ÇëÑ¡ÔñÒªºô½ÐµÄ·Ö×é").create();
		//
		// alertDialog.show();
		// } else {
		//
		// // btnEndCall.setVisibility(View.VISIBLE);
		// // btnStartCall.setVisibility(View.GONE);
		// groupIds = groupIds.substring(0, groupIds.length() - 1);
		// openVoiceCall(groupIds);
		//
		// }
		//
		// }
		// });

		btnStopCall.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				// ProcessHelper.processUIRequest(false, "");
				stopCallByEndUser();
				// btnEndCall.setVisibility(View.GONE);
				// btnStartCall.setVisibility(View.VISIBLE);

			}
		});

		new TimeThread().start();

	}

	private void stopCallByEndUser() {

		ProcessCommucationThread pThread = new ProcessCommucationThread();
		pThread.setIsOpen(false);
		pThread.setGroupId("");
		pThread.setDevId("");
		Thread thread = new Thread(pThread);
		thread.start();

		Message msg = new Message();

		msg.obj = "正在关闭呼叫台,请稍候...";
		msg.what = 1;

		processDialogProgress.sendMessage(msg);
	}

	public int dip2px(float dpValue) {
		final float scale = mContext.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * ¸ù¾ÝÊÖ»úµÄ·Ö±æÂÊ´Ó px(ÏñËØ) µÄµ¥Î» ×ª³ÉÎª dp
	 */
	public int px2dip(float pxValue) {
		final float scale = mContext.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	private void openVoiceCall(String groupIds, String devId) {

		ProcessCommucationThread pThread = new ProcessCommucationThread();
		pThread.setIsOpen(true);
		pThread.setGroupId(groupIds);
		pThread.setDevId(devId);
		Thread thread = new Thread(pThread);
		thread.start();

		Message msg = new Message();

		msg.obj = "正在打开呼叫台,请稍候...";
		msg.what = 1;

		processDialogProgress.sendMessage(msg);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == 200) {
			String groupIds = data.getStringExtra("groupIds");
			if (!groupIds.equals("")) {
				groupIds = groupIds.substring(0, groupIds.length() - 1);

				ArrayList<String> gIdArray = data
						.getStringArrayListExtra("groupIdsArray");

				ArrayList<String> gNameArray = data
						.getStringArrayListExtra("groupNamesArray");

				loadGroupsInfo(gIdArray, gNameArray);
				openVoiceCall(groupIds, "");
			}
		}

		if (resultCode == 201) {
			String devIds = data.getStringExtra("devIds");
			if (!devIds.equals("")) {
				devIds = devIds.substring(0, devIds.length() - 1);
				openVoiceCall("", devIds);

				ArrayList<String> devIdArray = data
						.getStringArrayListExtra("devIdsArray");

				ArrayList<String> devNameArray = data
						.getStringArrayListExtra("devNamesArray");

				loadClassInfo(devIdArray, devNameArray);

			}
		}

		// /Change objects.

		super.onActivityResult(requestCode, resultCode, data);
	}

	// public void setMedia() {
	//
	// try {
	// player.release();
	// player = new MediaPlayer();
	// // player.reset();
	//
	// player.setDataSource(mContext, uriToPlay);
	// player.prepare();
	// player.start();
	// } catch (IllegalArgumentException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// } catch (IllegalStateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

	private void regCallBack() {
		statusChanged = new statusChangedInterface() {

			@Override
			public void status_change(boolean isConnected, String statusText) {

				if (!isConnected) {

					Message msg = new Message();
					msg.what = 1;
					msg.obj = "ÍøÂçÁ¬½ÓÖÐ£¬ÇëÉÔºò...";

					processNetworkDialogProgress.sendMessage(msg);

				} else {

					Message msg = new Message();
					msg.what = 2;

					processNetworkDialogProgress.sendMessage(msg);
				}
				Message msg = new Message();
				msg.obj = statusText;
				msg.what = 1;
				mHandlerRefreshUI.sendMessage(msg);

			}

		};

		networkNotice = new networkNoticeInteface() {

			@Override
			public void networkNotice(String isOpen, String message) {

				ProcessHelper.stopEncoder();

				btnCallbyGroup.setEnabled(true);
				btnCallAll.setEnabled(true);

				btnCallbyGroup.setVisibility(View.VISIBLE);
				btnCallAll.setVisibility(View.VISIBLE);

				// btnStartCall.setVisibility(View.VISIBLE);

				btnStopCall.setVisibility(View.GONE);
				// TODO Auto-generated method stub
				// stopCallByEndUser();
			}

		};

		commandNotice = new commandNoticeInteface() {

			@Override
			public void command_Notice(String commandType, String message) {

				Message msg = new Message();

				if (commandType.equals("110")) {
					msg.obj = message;
					msg.what = 110;
				} else {
					msg.obj = commandType;
					msg.what = 2;
				}
				mHandlerRefreshUI.sendMessage(msg);

			}

		};
	}

	private void loadGroupsInfo(ArrayList<String> gids, ArrayList<String> gName) {

		isShowGroupInfo = true;
		if (gids != null && gids.size() > 0) {
			groupListIds = gids;
			groupListNames = gName;
		} else

		{
			groupListIds = ProcessHelper.getGroupIds(mContext, "");
			groupListNames = ProcessHelper.getGroupNames(mContext, "");
		}

		checkBoxList = groupListNames;

		cbList.notifyDataSetChanged();
	}

	private void loadClassInfo(ArrayList<String> cIds, ArrayList<String> cNames) {

		isShowGroupInfo = true;

		classListIds = cIds;
		classListNames = cNames;
		checkBoxList = groupListNames;

		cbList.notifyDataSetChanged();
	}

	private void showSettingDialog() {

		LayoutInflater factory = LayoutInflater.from(mContext);
		final View textEntryView = factory
				.inflate(R.layout.serversetting, null);

		EditText addrEdit = new EditText(mContext);

		addrEdit.setText(ProcessHelper.getMulticastAddr(mContext, ""));

		AlertDialog dlg = new AlertDialog.Builder(mContext)
				.setTitle("服务器地址")
				.setView(textEntryView)
				.setPositiveButton("好", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						EditText addrEdit = (EditText) textEntryView
								.findViewById(R.id.addr_edit);
						String addr = addrEdit.getText().toString();

						if (addr != null && !"".equals(addr)) {

							ProcessHelper.setPathAddr(mContext, addr);

							if (ProcessHelper.isServiceRunning(mContext)) {
								// notifyServer(COMMAND_CLIENT_UPDATEADDR);

								Intent intent = new Intent();
								intent.setClass(mContext, MainService.class);
								mContext.stopService(intent);

							} else {

								Intent intent = new Intent();
								intent.setClass(mContext, MainService.class);
								startService(intent);
								// finish();
							}

							// Toast.makeText(
							// mContext,
							// mContext.getString(R.string.serversettingok),
							// Toast.LENGTH_LONG).show();
							// finish();
						} else {
							// Dialog mDialog = new
							// MyDialog(mContext,R.style.MyDialog);
							// mDialog.show();
						}
					}
				})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {

					}
				}).create();
		dlg.show();
	}

	public class ProcessCommucationThread implements Runnable {
		private boolean isOpen;
		private String groupId;
		private String devId;

		public void setIsOpen(boolean ipen) {
			this.isOpen = ipen;
		}

		public void setGroupId(String gid) {
			this.groupId = gid;
		}

		public void setDevId(String devId) {
			this.devId = devId;
		}

		public void run() {

			ProcessHelper.processUIRequest(isOpen, groupId, devId);

			// System.out.println("hello " + name);
		}

	}

	public class TimeThread extends Thread {
		@Override
		public void run() {
			do {
				try {
					Thread.sleep(1000);
					Message msg = new Message();
					msg.what = 1;
					handlerShowTime.sendMessage(msg);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} while (true);
		}
	}

	private Handler handlerShowTime = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				long sysTime = System.currentTimeMillis();
				CharSequence sysTimeStr = DateFormat
						.format("kk:mm:ss", sysTime);
				tvShowTime.setText("" + sysTimeStr);
				break;

			}
		}
	};

	private Handler mHandlerRefreshUI = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:

				// imgNewworkStatus.setText(msg.obj.toString());
				break;

			case 2:

				String str = msg.obj.toString();

				if (str.equals("3")) {
					loadGroupsInfo(null, null);
				} else {

					if (str.equals("1")) {

						if (proDialog != null) {
							proDialog.dismiss();
						}

						btnCallbyClass.setEnabled(false);
						btnCallbyGroup.setEnabled(false);
						btnCallAll.setEnabled(false);

						btnCallbyClass.setVisibility(View.GONE);
						btnCallbyGroup.setVisibility(View.GONE);
						btnCallAll.setVisibility(View.GONE);
						btnStartCall.setVisibility(View.GONE);

						btnStopCall.setVisibility(View.VISIBLE);

						pause5SecForStop.sendEmptyMessageDelayed(0, 5000);

					} else {

						if (proDialog != null) {
							proDialog.dismiss();
						}

						btnCallbyClass.setEnabled(true);
						btnCallbyGroup.setEnabled(true);
						btnCallAll.setEnabled(true);

						btnCallbyGroup.setVisibility(View.VISIBLE);
						btnCallAll.setVisibility(View.VISIBLE);
						btnCallbyClass.setVisibility(View.VISIBLE);

						// btnStartCall.setVisibility(View.VISIBLE);

						btnStopCall.setVisibility(View.GONE);
					}

				}
				break;
			case 110:
				if (proDialog != null) {
					proDialog.dismiss();
				}

				Dialog alertDialog = new AlertDialog.Builder(mContext)
						.setTitle("呼叫台操作")
						.setPositiveButton("确认", new OnClickListener() {

							@Override
							public void onClick(DialogInterface arg0, int arg1) {
								// TODO Auto-generated method stub

							}

						}).setMessage(msg.obj.toString()).create();

				alertDialog.show();

				break;
			default:
				break;
			}
		}
	};

	private Handler processNetworkDialogProgress = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				if (proDialogForNoNewWork == null) {
					proDialogForNoNewWork = new ProgressDialog(mContext);

				}

				if (!proDialogForNoNewWork.isShowing()) {

					proDialogForNoNewWork.setTitle("ÒôÆµºô½ÐÌ¨");

					proDialogForNoNewWork.setMessage(msg.obj.toString());
					// proDialog.setCancelable(false);

					proDialogForNoNewWork.show();
				}

				imgNewworkStatus
						.setBackgroundResource(R.drawable.ic_image_network_offline);

				break;

			case 2:

				imgNewworkStatus
						.setBackgroundResource(R.drawable.ic_image_network_receive);

				if (proDialogForNoNewWork != null) {
					proDialogForNoNewWork.dismiss();
				}

				break;
			default:
				break;
			}
		}
	};

	private Handler processDialogProgress = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				if (proDialog == null) {
					proDialog = new ProgressDialog(mContext);

				}

				if (!proDialog.isShowing()) {

					proDialog.setTitle("音频呼叫台");

					proDialog.setMessage(msg.obj.toString());
					// proDialog.setCancelable(false);

					proDialog.show();
				}

				break;

			case 2:

				if (proDialog != null) {
					proDialog.dismiss();
				}

				break;
			default:
				break;
			}
		}
	};

	private Handler pause5SecForStop = new Handler() {
		public void handleMessage(Message paramMessage) {
			super.handleMessage(paramMessage);
			switch (paramMessage.what) {

			case 0:

				btnStopCall.setEnabled(true);
				break;
			default:
			}
		};

	};

	public class CheckBoxList extends BaseAdapter {
		Activity activity;
		LayoutInflater inflater;

		// construct
		public CheckBoxList(Activity a) {
			activity = a;
			inflater = LayoutInflater.from(activity);
		}

		@Override
		public int getCount() {
			return checkBoxList.size();
		}

		@Override
		public Object getItem(int position) {
			return checkBoxList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub

			if (arg1 == null) {

				arg1 = inflater
						.inflate(R.layout.checkbox_item_show_group, null);
				// arg1.setTag(im);

			}

			ToggleButton tbItem = null;

			TextView tvItemText = null;

			if (isShowGroupInfo) {
				tvItemText = (TextView) arg1
						.findViewById(R.id.tvItemShowGroupText);
				tbItem = (ToggleButton) arg1.findViewById(R.id.tvItemShowGroup);
			} else {
				tvItemText = (TextView) arg1
						.findViewById(R.id.tbShowClassItemText);
				tbItem = (ToggleButton) arg1.findViewById(R.id.tbShowClassItem);
			}

			tbItem.setText("");

			tvItemText.setText(checkBoxList.get(arg0));

			tbItem.setTag(arg0);
			tbItem.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
					// TODO Auto-generated method stub

					Integer selInt = 0;
					if (arg1) {
						selInt = 1;
					}

				}
			});

			return arg1;
		}
	}
}
