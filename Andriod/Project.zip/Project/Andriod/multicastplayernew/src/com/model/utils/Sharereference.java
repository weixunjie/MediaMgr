package com.model.utils;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.datamodels.ScheduleInfo;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.codec.binary.Base64;

public class Sharereference {

	public static String AppVersion = "20150603";

	public static String getIsDownloading(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"isdwning", paramString);
	}

	public static String getIsLastRebootTime(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"lastReboottime", paramString);
	}

	public static String getIsLocalPlaying(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"localPlaing", paramString);
	}

	public static boolean getIsOneMoreTime(Context paramContext,
			boolean paramBoolean) {
		return paramContext.getSharedPreferences("isAnotherTime", 4)
				.getBoolean("secend", paramBoolean);
	}

	public static String getIsPlaying(Context paramContext, String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"isPlaying", paramString);
	}

	public static String getLastPlayTime(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"lastPlyTime", paramString);
	}

	public static String getMulticastAddr(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"addr", paramString);
	}

	public static ScheduleInfo getScheduleInfo(Context paramContext) {
		String str = paramContext.getSharedPreferences("scheduleInfoBase64", 4)
				.getString("scheduleInfo", "");
		ByteArrayInputStream localByteArrayInputStream = null;
		if ((str != null) && (!str.equals(""))) {
			localByteArrayInputStream = new ByteArrayInputStream(
					Base64.decodeBase64(str.getBytes()));
		}
		try {
			ObjectInputStream localObjectInputStream = new ObjectInputStream(
					localByteArrayInputStream);
			try {
				ScheduleInfo localScheduleInfo = (ScheduleInfo) localObjectInputStream
						.readObject();
				return localScheduleInfo;
			} catch (ClassNotFoundException localClassNotFoundException) {
				localClassNotFoundException.printStackTrace();
			}
		} catch (StreamCorruptedException localStreamCorruptedException) {
			for (;;) {
				localStreamCorruptedException.printStackTrace();
			}
		} catch (IOException localIOException) {
			for (;;) {
				localIOException.printStackTrace();
			}
		}
		return null;
	}

	public static String getScheduleMCUTask(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"ScheduleMCUTask", paramString);
	}

	public static String getVersionNumber(Context paramContext,
			String paramString) {
		return paramContext.getSharedPreferences("multcast", 4).getString(
				"versionId", paramString);
	}

	public static boolean isServiceRunning(Context paramContext) {
		Iterator localIterator = ((ActivityManager) paramContext
				.getSystemService("activity")).getRunningServices(
				Integer.MAX_VALUE).iterator();
		do {
			if (!localIterator.hasNext()) {
				return false;
			}
		} while (!"com.model.commandreceiver.CommandReceiver"
				.equals(((ActivityManager.RunningServiceInfo) localIterator
						.next()).service.getClassName()));
		return true;
	}

	public static void setIsDownloading(Context paramContext, String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("isdwning", paramString);
		localEditor.commit();
	}

	public static void setIsLastRebootTime(Context paramContext,
			String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("lastReboottime", paramString);
		localEditor.commit();
	}

	public static void setIsLocalPlaying(Context paramContext,
			String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("localPlaing", paramString);
		localEditor.commit();
	}

	public static void setIsOneMoreTime(Context paramContext,
			boolean paramBoolean) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("isAnotherTime", 4).edit();
		localEditor.putBoolean("secend", paramBoolean);
		localEditor.commit();
	}

	public static void setIsPlaying(Context paramContext, String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("isPlaying", paramString);
		localEditor.commit();
	}

	public static void setLastPlayTime(Context paramContext, String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("lastPlyTime", paramString);
		localEditor.commit();
	}

	public static void setPathAddr(Context paramContext, String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("addr", paramString);
		localEditor.commit();
	}

	public static void setScheduleInfo(Context paramContext,
			ScheduleInfo paramScheduleInfo) {
		ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
		try {
			new ObjectOutputStream(localByteArrayOutputStream)
					.writeObject(paramScheduleInfo);
			SharedPreferences localSharedPreferences = paramContext
					.getSharedPreferences("scheduleInfoBase64", 4);
			String str = new String(
					Base64.encodeBase64(localByteArrayOutputStream
							.toByteArray()));
			SharedPreferences.Editor localEditor = localSharedPreferences
					.edit();
			localEditor.putString("scheduleInfo", str);
			localEditor.commit();
			return;
		} catch (IOException localIOException) {
			for (;;) {
				localIOException.printStackTrace();
			}
		}
	}

	public static void setScheduleMCUTask(Context paramContext,
			String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("ScheduleMCUTask", paramString);
		localEditor.commit();
	}

	public static void setVersionNumber(Context paramContext, String paramString) {
		SharedPreferences.Editor localEditor = paramContext
				.getSharedPreferences("multcast", 4).edit();
		localEditor.putString("versionId", paramString);
		localEditor.commit();
	}
}
