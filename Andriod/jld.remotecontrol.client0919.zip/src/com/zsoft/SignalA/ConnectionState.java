package com.zsoft.SignalA;

public enum ConnectionState {
	Disconnected,
	Connecting,
	Connected,
	Reconnecting, 
	Disconnecting
}
