﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class EncoderSyncDevInfo
    {
        public String devId { get; set; }

        public String devName { get; set; }

     


    }
}
