﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class UpgradeInfo
    {
        public String VersionId { get; set; }

        public String UpgardeUrl { get; set; }


        public string VersionType { get; set; }


    }
}
