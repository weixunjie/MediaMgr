package com.example.mcu_func_test;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import android.hardware.SerialManager;
import android.hardware.SerialPort;

import java.nio.ByteBuffer;
import java.io.IOException;

public class Shutdown extends BroadcastReceiver {
    private String ACTION_SHUTDOWN = "android.intent.action.ACTION_SHUTDOWN";

    public void onReceive(Context context, Intent intent) {
       
        if(intent.getAction().equals(ACTION_SHUTDOWN)){
  

            Log.i("pengyong", "Shut down this system!!!");
        }
    }

}
