/*      */package android.hardware;

/*      */
/*      */import android.content.BroadcastReceiver;
/*      */
import android.content.Context;
/*      */
import android.content.Intent;
/*      */
import android.content.IntentFilter;
/*      */
import android.os.IBinder;
/*      */
import android.os.RemoteException;
/*      */
import android.os.ServiceManager;
/*      */
import android.os.SystemClock;
/*      */
import android.util.Log;
/*      */
import java.io.IOException;
/*      */
import java.util.Calendar;

/*      */
/*      */public class SerialManager
/*      */{
	/*      */private static final String TAG = "SerialManager";
	/*      */private final Context mContext;
	/*      */private final ISerialManager mService;
	/*      */private static int week;
	/* 58 */private int RETRY = 2;
	/*      */public static SerialManager mInstance;
	/* 60 */private int flag = 0;
	/*      */
	/* 62 */private BroadcastReceiver mBroadcastReceiver_shutdown = new BroadcastReceiver() {
		/*      */public void onReceive(Context context, Intent intent) {
			/* 64 */String action = intent.getAction();
			/* 65 */if (action.equals("android.intent.action.ACTION_SHUTDOWN")) {
				/* 66 */Log.e("pengyong", " shut down");
				/* 67 */SerialManager.this.send_system_state_to_mcu(3);
				/*      */}
			/*      */}
		/* 62 */
	};

	/*      */
	/*      */public synchronized boolean sync_system_tiem_from_rtc()
	/*      */{
		/* 78 */int[] time = new int[6];
		/* 79 */time = get_mcu_time();
		/*      */
		/* 82 */if (time[0] == -1)
		/*      */{
			/* 84 */Log.e("pengyong", "get_mcu_time: return fail");
			/* 85 */return false;
			/*      */}
		/*      */
		/* 88 */Log.e("pengyong", "sync_system_tiem_from_rtctime=" + time[0]
				+ ":" + time[1] + ":" + time[2] + ":" + time[3] + ":" + time[4]
				+ ":" + time[5]);
		/*      */
		/* 90 */Calendar c = Calendar.getInstance();
		/*      */
		/* 92 */c.set(1, time[0]);
		/* 93 */c.set(2, time[1] - 1);
		/* 94 */c.set(5, time[2]);
		/*      */
		/* 96 */c.set(11, time[3]);
		/* 97 */c.set(12, time[4]);
		/* 98 */c.set(13, time[5]);
		/* 99 */c.set(14, 0);
		/*      */
		/* 101 */long when = c.getTimeInMillis();
		/* 102 */Log.e("pengyong", "when=" + when);
		/*      */
		/* 104 */if (when / 1000L < 2147483647L) {
			/* 105 */this.flag = 1;
			/* 106 */SystemClock.setCurrentTimeMillis(when);
			/* 107 */Log.e("pengyong", "set_rtc on poweron");
			/*      */}
		/*      */
		/* 110 */return true;
		/*      */}

	/*      */
	/*      */public SerialManager(Context context, ISerialManager service)
	/*      */{
		/* 119 */this.mContext = context;
		/* 120 */this.mService = service;
		/*      */
		/* 123 */if (this.mContext != null)
			/* 124 */this.mContext.registerReceiver(
					this.mBroadcastReceiver_shutdown, new IntentFilter(
							"android.intent.action.ACTION_SHUTDOWN"), null,
					null);
		/*      */}

	/*      */
	/*      */public static SerialManager getInstance(Context context)
	/*      */{
		/* 131 */Log.e("pengong", "get_instanch in serialManager mInstanch="
				+ mInstance);
		/* 132 */if (mInstance == null)
		/*      */{
			/* 135 */Log.e("pengong", "new mInstance");
			/* 136 */IBinder b = ServiceManager.getService("serial");
			/* 137 */mInstance = new SerialManager(context,
					ISerialManager.Stub.asInterface(b));
			/* 138 */Log.e("pengong", "new mInstance=" + mInstance + "111="
					+ mInstance);
			/*      */try
			/*      */{
				/* 142 */mInstance.openSerialPort("/dev/ttyS3", 9600);
				/*      */}
			/*      */catch (IOException e) {
				/* 145 */Log.e("SerialManager",
						"exception in UsbManager.openDevice", e);
				/*      */}
			/*      */}
		/*      */
		/* 149 */return mInstance;
		/*      */}

	/*      */
	/*      */public String[] getSerialPorts()
	/*      */{
		/*      */try
		/*      */{
			/* 161 */return this.mService.getSerialPorts();
			/*      */} catch (RemoteException e) {
			/* 163 */Log.e("SerialManager",
					"RemoteException in getSerialPorts", e);
		}
		/* 164 */return null;
		/*      */}

	/*      */
	/*      */public void openSerialPort(String name, int speed)
	/*      */throws IOException
	/*      */{
		/*      */try
		/*      */{
			/* 181 */this.mService.openSerialPort(name);
			/*      */}
		/*      */catch (RemoteException e)
		/*      */{
			/* 185 */Log.e("SerialManager",
					"exception in UsbManager.openDevice", e);
			/*      */}
		/*      */}

	/*      */
	/*      */private int get_value(byte[] value, int start, int stop)
	/*      */{
		/* 194 */int re = 0;
		/*      */
		/* 197 */String str = new String(value, start, stop - start + 1);
		/* 198 */re = Integer.valueOf(str, 16).intValue();
		/* 199 */return re;
		/*      */}

	/*      */
	/*      */private byte[] calu_parity(byte[] value)
	/*      */{
		/* 207 */byte[] result = new byte[2];
		/*      */
		/* 209 */int ret = 0;
		/* 210 */int number = 0;
		/* 211 */if (value.length < 8)
		/*      */{
			/* 213 */Log.e("pengyong", "length is wrong");
			/* 214 */return result;
			/*      */}
		/*      */
		/* 218 */for (int i = 1; i < value.length - 3; i += 2)
		/*      */{
			/* 221 */number = get_value(value, i, i + 1);
			/* 222 */ret ^= number;
			/*      */}
		/*      */
		/* 227 */result = String.format("%02x",
				new Object[] { Integer.valueOf(ret) }).getBytes();
		/* 228 */if (result[0] >= 97)
			/* 229 */result[0] = (byte) (result[0] - 97 + 65);
		/* 230 */if (result[1] >= 97)
			/* 231 */result[1] = (byte) (result[1] - 97 + 65);
		/* 232 */Log.e("pengong", "parity[0]= " + result[0] + "parity[1]="
				+ result[1]);
		/* 233 */return result;
		/*      */}

	/*      */
	/*      */private boolean check_parity(byte[] value)
	/*      */{
		/* 239 */byte[] parity = calu_parity(value);
		/*      */
		/* 243 */return ((parity[0] == value[(value.length - 3)]) && (parity[1] == value[(value.length - 2)]));
		/*      */}

	/*      */
	/*      */private String transfer_uart(byte[] value)
	/*      */{
		/* 260 */Log.e("pengyong",
				"transfer_uart in  write value=" + value.toString());
		/*      */
		/* 262 */String str = new String(value, 0, value.length);
		/*      */try
		/*      */{
			/* 267 */this.mService.uart_write(str);
			/*      */}
		/*      */catch (RemoteException e)
		/*      */{
			/*      */}
		/*      */try {
			/* 273 */str = this.mService.uart_read();
			/*      */}
		/*      */catch (RemoteException e)
		/*      */{
			/*      */}
		/* 278 */Log.e("pengyong", "transfer_uart out read  " + str);
		/*      */
		/* 280 */return str;
		/*      */}

	/*      */
	/*      */public synchronized int[] get_mcu_time()
	/*      */{
		/* 287 */int length = 0;
		/*      */
		/* 294 */byte[] data = new byte[128];
		/*      */
		/* 296 */byte[] value = { 64, 48, 49, 48, 49, 13 };
		/*      */
		/* 299 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 302 */String str = transfer_uart(value);
			/* 303 */if (str == null)
			/*      */{
				/*      */continue;
				/*      */}
			/*      */
			/* 308 */byte[] resu = str.getBytes();
			/*      */
			/* 311 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 314 */if (resu.length < 5)
			/*      */{
				/* 316 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 320 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 49) && (check_parity(resu)))
				/*      */{
					/* 322 */Log.e("pengyong", "parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 326 */Log.e("pengyong", "parity is wrong");
					/* 327 */continue;
					/*      */}
				/*      */
				/* 331 */int year = get_value(resu, 5, 6) + 2000;
				/* 332 */int month = get_value(resu, 7, 8);
				/* 333 */int day = get_value(resu, 9, 10);
				/* 334 */int hour = get_value(resu, 11, 12);
				/* 335 */int minute = get_value(resu, 13, 14);
				/* 336 */int second = get_value(resu, 15, 16);
				/*      */
				/* 338 */int[] ret = { year, month, day, hour, minute, second };
				/* 339 */String date = String.format("%s",
						new Object[] { "data=" + year + "-" + month + "-" + day
								+ ":" + hour + ":" + minute + ":" + second });
				/* 340 */Log.e("pengyong", date);
				/* 341 */return ret;
				/*      */}
			/*      */}
		/* 344 */int[] ret_false = new int[1];
		/* 345 */ret_false[0] = -1;
		/* 346 */return ret_false;
		/*      */}

	/*      */
	/*      */public synchronized boolean set_mcu_time(int[] set_value)
	/*      */{
		/* 353 */int length = 0;
		/*      */
		/* 359 */byte[] result = new byte[2];
		/* 360 */byte[] data = new byte[128];
		/*      */
		/* 362 */byte[] value = { 64, 48, 50, 48, 69, 48, 51, 49, 53, 48, 49,
				49, 69, 49, 57, 49, 67, 13 };
		/* 363 */result = String.format("%02x",
				new Object[] { Integer.valueOf(set_value[0] - 2000) })
				.getBytes();
		/* 364 */if (result[0] >= 97)
			/* 365 */result[0] = (byte) (result[0] - 97 + 65);
		/* 366 */if (result[1] >= 97) {
			/* 367 */result[1] = (byte) (result[1] - 97 + 65);
			/*      */}
		/* 369 */value[3] = result[0];
		/* 370 */value[4] = result[1];
		/*      */
		/* 372 */for (int i = 1; i < 6; ++i)
		/*      */{
			/* 374 */result = String.format("%02x",
					new Object[] { Integer.valueOf(set_value[i]) }).getBytes();
			/* 375 */if (result[0] >= 97)
				/* 376 */result[0] = (byte) (result[0] - 97 + 65);
			/* 377 */if (result[1] >= 97) {
				/* 378 */result[1] = (byte) (result[1] - 97 + 65);
				/*      */}
			/* 380 */value[(2 * i + 3)] = result[0];
			/* 381 */value[(2 * i + 4)] = result[1];
			/*      */}
		/*      */
		/* 385 */result = calu_parity(value);
		/* 386 */value[15] = result[0];
		/* 387 */value[16] = result[1];
		/*      */
		/* 391 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 393 */String str = transfer_uart(value);
			/* 394 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 398 */byte[] resu = str.getBytes();
			/* 399 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 401 */if (resu.length < 5)
			/*      */{
				/* 403 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 407 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 50) && (check_parity(resu)))
				/*      */{
					/* 409 */Log.e("pengyong", "parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 413 */Log.e("pengyong", "parity is wrong");
					/* 414 */continue;
					/*      */}
				/*      */
				/* 417 */return true;
			}
			/*      */}
		/* 419 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean set_onoff_by_week(int[] set_value)
	/*      */{
		/* 426 */int length = 0;
		/*      */
		/* 430 */byte[] data = new byte[128];
		/* 431 */byte[] value = { 64, 48, 51, 48, 49, 48, 49, 48, 66, 48, 50,
				49, 54, 49, 67, 13 };
		/*      */
		/* 433 */byte[] result = new byte[2];
		/*      */
		int i;
		/* 435 */for (i = 0; i < 5; ++i)
		/*      */{
			/* 437 */result = String.format("%02x",
					new Object[] { Integer.valueOf(set_value[i]) }).getBytes();
			/* 438 */if (result[0] >= 97)
				/* 439 */result[0] = (byte) (result[0] - 97 + 65);
			/* 440 */if (result[1] >= 97) {
				/* 441 */result[1] = (byte) (result[1] - 97 + 65);
				/*      */}
			/* 443 */value[(2 * i + 3)] = result[0];
			/* 444 */value[(2 * i + 4)] = result[1];
			/*      */}
		/*      */
		/* 448 */result = calu_parity(value);
		/* 449 */value[(2 * i + 3)] = result[0];
		/* 450 */value[(2 * i + 4)] = result[1];
		/*      */
		/* 452 */for (i = 0; i < 16; ++i)
		/*      */{
			/* 454 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 460 */for (i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 462 */String str = transfer_uart(value);
			/* 463 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 467 */byte[] resu = str.getBytes();
			/*      */
			/* 469 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 471 */if (resu.length < 5)
			/*      */{
				/* 473 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 477 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 51) && (check_parity(resu)))
				/*      */{
					/* 479 */Log.e("pengyong",
							"set_autopoweron_by_week :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 483 */Log.e("pengyong",
							"set_autopoweron_by_week: parity is wrong");
					/* 484 */continue;
					/*      */}
				/*      */
				/* 487 */return true;
				/*      */}
			/*      */}
		/* 490 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean save_system_time_to_rtc(long millionsecond)
	/*      */{
		/* 497 */Log.e("pengyong", "set_mcurtc_by_system millionsecond="
				+ millionsecond);
		/* 498 */Calendar calendar = Calendar.getInstance();
		/* 499 */int year = calendar.get(1);
		/* 500 */int month = calendar.get(2) + 1;
		/* 501 */int day = calendar.get(5);
		/* 502 */int hour = calendar.get(11);
		/* 503 */int minute = calendar.get(12);
		/* 504 */int second = calendar.get(13);
		/* 505 */int[] time = { year, month, day, hour, minute, second };
		/* 506 */Log.e("pengyong ", "flag=" + this.flag + "time=" + year + ":"
				+ month + ":" + day + ":" + hour + ":" + minute + ":" + second);
		/*      */
		/* 509 */return set_mcu_time(time);
		/*      */}

	/*      */
	/*      */public synchronized int[] get_onoff_by_week(int week)
	/*      */{
		/* 517 */int length = 0;
		/*      */
		/* 519 */byte[] data = new byte[128];
		/* 520 */byte[] value = { 64, 48, 52, 48, 49, 48, 53, 13 };
		/*      */
		/* 522 */byte[] result = new byte[2];
		/* 523 */int[] ret = new int[4];
		/*      */
		/* 525 */result = String.format("%02x",
				new Object[] { Integer.valueOf(week) }).getBytes();
		/* 526 */if (result[0] >= 97)
			/* 527 */result[0] = (byte) (result[0] - 97 + 65);
		/* 528 */if (result[1] >= 97) {
			/* 529 */result[1] = (byte) (result[1] - 97 + 65);
			/*      */}
		/* 531 */value[3] = result[0];
		/* 532 */value[4] = result[1];
		/*      */
		/* 534 */result = calu_parity(value);
		/* 535 */value[5] = result[0];
		/* 536 */value[6] = result[1];
		/*      */
		/* 538 */for (int i = 0; i < 8; ++i)
		/*      */{
			/* 540 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 546 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 550 */String str = transfer_uart(value);
			/* 551 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 555 */byte[] resu = str.getBytes();
			/*      */
			/* 558 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 560 */if (resu.length < 5)
			/*      */{
				/* 562 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 567 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 52) && (check_parity(resu)))
				/*      */{
					/* 569 */Log.e("pengyong",
							"get_autopoweron_by_week :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 573 */Log.e("pengyong",
							"get_autopoweron_by_week: parity is wrong");
					/*      */
					/* 575 */continue;
					/*      */}
				/*      */
				/* 578 */ret[0] = get_value(resu, 7, 8);
				/* 579 */ret[1] = get_value(resu, 9, 10);
				/* 580 */ret[2] = get_value(resu, 11, 12);
				/* 581 */ret[3] = get_value(resu, 13, 14);
				/*      */
				/* 584 */return ret;
				/*      */}
			/*      */}
		/*      */
		/* 588 */int[] ret_false = new int[1];
		/* 589 */ret_false[0] = -1;
		/* 590 */return ret_false;
		/*      */}

	/*      */
	/*      */public synchronized boolean enable_onoff_by_week(int[] set_value)
	/*      */{
		/* 598 */int length = 0;
		/*      */
		/* 600 */byte[] data = new byte[128];
		/* 601 */byte[] value = { 64, 48, 53, 48, 48, 48, 53, 13 };
		/*      */
		/* 605 */int week = 0;
		/*      */
		/* 607 */for (int i = 0; i < 7; ++i)
		/*      */{
			/* 609 */if (set_value[i] == 1)
			/*      */{
				/* 612 */week |= 1 << i;
				/*      */}
			/* 614 */else if (set_value[i] == 0)
			/*      */{
				/* 616 */week &= (1 << i ^ 0xFFFFFFFF);
				/*      */}
			/*      */else
			/*      */{
				/* 620 */Log.e("pengyong", "parameter is error");
				/* 621 */return false;
				/*      */}
			/*      */}
		/*      */
		/* 625 */byte[] result = String.format("%02x",
				new Object[] { Integer.valueOf(week) }).getBytes();
		/* 626 */value[3] = result[0];
		/* 627 */value[4] = result[1];
		/*      */
		/* 629 */result = calu_parity(value);
		/* 630 */value[5] = result[0];
		/* 631 */value[6] = result[1];
		/*      */
		/* 633 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 635 */String str = transfer_uart(value);
			/* 636 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 640 */byte[] resu = str.getBytes();
			/*      */
			/* 642 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 644 */if (resu.length < 5)
			/*      */{
				/* 646 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 651 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 53) && (check_parity(resu)))
				/*      */{
					/* 653 */Log.e("pengyong",
							"set_autopoweron_command :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 657 */Log.e("pengyong",
							"set_autopoweron_command: parity is wrong");
					/* 658 */continue;
					/*      */}
				/*      */
				/* 661 */return true;
				/*      */}
			/*      */}
		/* 664 */return false;
		/*      */}

	/*      */
	/*      */public synchronized int check_onoff_by_week()
	/*      */{
		/* 672 */int length = 0;
		/*      */
		/* 674 */byte[] data = new byte[128];
		/* 675 */byte[] value = { 64, 48, 54, 48, 54, 13 };
		/*      */
		/* 681 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 683 */String str = transfer_uart(value);
			/* 684 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 688 */byte[] resu = str.getBytes();
			/*      */
			/* 690 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 692 */if (resu.length < 5)
			/*      */{
				/* 694 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 698 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 54) && (check_parity(resu)))
				/*      */{
					/* 700 */Log.e("pengyong",
							"get_autopoweron_command :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 704 */Log.e("pengyong",
							"get_autopoweron_command: parity is wrong");
					/* 705 */continue;
					/*      */}
				/*      */
				/* 710 */if (resu[6] == 48)
				/*      */{
					/* 713 */return 1;
					/*      */}
				/*      */
				/* 717 */return 0;
				/*      */}
			/*      */}
		/*      */
		/* 721 */return -1;
		/*      */}

	/*      */
	/*      */public synchronized String get_mcu_id()
	/*      */{
		/* 729 */int length = 0;
		/*      */
		/* 732 */byte[] data = new byte[128];
		/* 733 */byte[] value = { 64, 48, 55, 48, 55, 13 };
		/*      */
		/* 736 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 739 */String str = transfer_uart(value);
			/*      */
			/* 741 */if (str == null)
			/*      */{
				/*      */continue;
				/*      */}
			/*      */
			/* 747 */byte[] resu = str.getBytes();
			/*      */
			/* 750 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 752 */if (resu.length < 5)
			/*      */{
				/* 754 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 759 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 55) && (check_parity(resu)))
				/*      */{
					/* 761 */Log.e("pengyong", "get_id :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 765 */Log.e("pengyong", "get_id: parity is wrong");
					/* 766 */continue;
					/*      */}
				/*      */
				/* 770 */return new String(resu, 5, 24);
				/*      */}
			/*      */}
		/* 773 */return null;
		/*      */}

	/*      */
	/*      */public synchronized boolean send_system_state_to_mcu(int state)
	/*      */{
		/* 782 */int length = 0;
		/*      */
		/* 784 */byte[] data = new byte[128];
		/* 785 */byte[] value = { 64, 48, 56, 48, 49, 48, 57, 13 };
		/*      */
		/* 788 */value[4] = (byte) (state + 48);
		/*      */
		/* 790 */byte[] result = calu_parity(value);
		/* 791 */value[5] = result[0];
		/* 792 */value[6] = result[1];
		/* 793 */for (int i = 0; i < 8; ++i)
		/*      */{
			/* 795 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 800 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 802 */String str = transfer_uart(value);
			/*      */
			/* 804 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 808 */byte[] resu = str.getBytes();
			/* 809 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 811 */if (resu.length < 5)
			/*      */{
				/* 813 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 818 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 56) && (check_parity(resu)))
				/*      */{
					/* 820 */Log.e("pengyong",
							"send_A20_state :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 824 */Log.e("pengyong",
							"send_A20_state: parity is wrong");
					/* 825 */continue;
					/*      */}
				/*      */
				/* 828 */return true;
				/*      */}
			/*      */}
		/* 831 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean send_heartbeat_to_mcu()
	/*      */{
		/* 839 */int length = 0;
		/*      */
		/* 841 */byte[] data = new byte[128];
		/* 842 */byte[] value = { 64, 48, 57, 48, 57, 13 };
		/*      */
		/* 845 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 848 */String str = transfer_uart(value);
			/*      */
			/* 850 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 854 */byte[] resu = str.getBytes();
			/*      */
			/* 856 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 858 */if (resu.length < 5)
			/*      */{
				/* 860 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 865 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 57) && (check_parity(resu)))
				/*      */{
					/* 867 */Log.e("pengyong",
							"send_heartbeat :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 871 */Log.e("pengyong",
							"send_heartbeat: parity is wrong");
					/* 872 */continue;
					/*      */}
				/*      */
				/* 875 */return true;
				/*      */}
			/*      */}
		/* 878 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean enable_watchdog(int enable)
	/*      */{
		/* 916 */int length = 0;
		/*      */
		/* 921 */byte[] data = new byte[128];
		/* 922 */byte[] value = { 64, 48, 65, 48, 48, 48, 65, 13 };
		/*      */
		/* 927 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 930 */if (enable == 1)
			/*      */{
				/* 932 */value[4] = 48;
				/*      */}
			/*      */else
			/*      */{
				/* 936 */value[4] = 49;
				/*      */}
			/*      */
			/* 939 */byte[] result = calu_parity(value);
			/* 940 */value[5] = result[0];
			/* 941 */value[6] = result[1];
			/*      */
			/* 944 */for (int j = 0; j < 8; ++j)
			/*      */{
				/* 946 */Log.e(
						"pengyong",
						String.format("0x%02x",
								new Object[] { Byte.valueOf(value[j]) }));
				/*      */}
			/*      */
			/* 950 */String str = transfer_uart(value);
			/* 951 */if (str == null)
			/*      */{
				/*      */continue;
				/*      */}
			/*      */
			/* 957 */byte[] resu = str.getBytes();
			/* 958 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 960 */if (resu.length < 5)
			/*      */{
				/* 962 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 966 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 65) && (check_parity(resu)))
				/*      */{
					/* 968 */Log.e("pengyong",
							"enable_watchdog :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 972 */Log.e("pengyong",
							"enable_watchdog: parity is wrong");
					/* 973 */continue;
					/*      */}
				/*      */
				/* 977 */return true;
			}
			/*      */}
		/* 979 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean shutdown_system()
	/*      */{
		/* 986 */int length = 0;
		/*      */
		/* 988 */byte[] data = new byte[128];
		/* 989 */byte[] value = { 64, 48, 66, 48, 48, 48, 66, 13 };
		/*      */
		/* 993 */value[4] = 48;
		/* 994 */byte[] result = calu_parity(value);
		/* 995 */value[5] = result[0];
		/* 996 */value[6] = result[1];
		/*      */
		/* 998 */for (int i = 0; i < 8; ++i)
		/*      */{
			/* 1000 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 1004 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1006 */String str = transfer_uart(value);
			/* 1007 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1011 */byte[] resu = str.getBytes();
			/*      */
			/* 1013 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1015 */if (resu.length < 5)
			/*      */{
				/* 1017 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1022 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 66) && (check_parity(resu)))
				/*      */{
					/* 1024 */Log.e("pengyong",
							"send_shutdown :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1028 */Log.e("pengyong",
							"send_shutdown: parity is wrong");
					/* 1029 */continue;
					/*      */}
				/*      */
				/* 1032 */return true;
				/*      */}
			/*      */}
		/* 1035 */return false;
		/*      */}

	/*      */
	/*      */public synchronized boolean restart_system()
	/*      */{
		/* 1041 */int length = 0;
		/*      */
		/* 1043 */byte[] data = new byte[128];
		/* 1044 */byte[] value = { 64, 48, 66, 48, 48, 48, 66, 13 };
		/*      */
		/* 1047 */value[4] = 49;
		/* 1048 */byte[] result = calu_parity(value);
		/* 1049 */value[5] = result[0];
		/* 1050 */value[6] = result[1];
		/*      */
		/* 1052 */for (int i = 0; i < 8; ++i)
		/*      */{
			/* 1054 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 1058 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1060 */String str = transfer_uart(value);
			/* 1061 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1065 */byte[] resu = str.getBytes();
			/*      */
			/* 1067 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1069 */if (resu.length < 5)
			/*      */{
				/* 1071 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1075 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 66) && (check_parity(resu)))
				/*      */{
					/* 1077 */Log.e("pengyong",
							"send_shutdown :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1081 */Log.e("pengyong",
							"send_shutdown: parity is wrong");
					/* 1082 */continue;
					/*      */}
				/*      */
				/* 1085 */return true;
				/*      */}
			/*      */}
		/* 1088 */return false;
		/*      */}

	/*      */
	/*      */public synchronized int get_mcu_firmware()
	/*      */{
		/* 1095 */int length = 0;
		/*      */
		/* 1098 */byte[] data = new byte[128];
		/*      */
		/* 1100 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1103 */byte[] value = { 64, 48, 67, 48, 67, 13 };
			/*      */
			/* 1105 */String str = transfer_uart(value);
			/*      */
			/* 1107 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1111 */byte[] resu = str.getBytes();
			/* 1112 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1114 */if (resu.length < 5)
			/*      */{
				/* 1116 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1120 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 67) && (check_parity(resu)))
				/*      */{
					/* 1122 */Log.e("pengyong",
							"get_mcu_firmware :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1126 */Log.e("pengyong",
							"get_mcu_firmware: parity is wrong");
					/*      */
					/* 1128 */continue;
					/*      */}
				/*      */
				/* 1133 */return get_value(resu, 5, 6);
				/*      */}
			/*      */}
		/*      */
		/* 1137 */return -1;
		/*      */}

	/*      */
	/*      */public synchronized boolean set_onoff_by_day(int[] set_value2)
	/*      */{
		/* 1146 */int length = 0;
		/*      */
		/* 1148 */byte[] data = new byte[128];
		/* 1149 */byte[] result = new byte[2];
		/* 1150 */byte[] value = { 64, 48, 69, 48, 69, 48, 49, 48, 49, 48, 53,
				48, 54, 48, 69, 48, 49, 48, 49, 48, 52, 48, 51, 48, 52, 13 };
		/*      */
		/* 1152 */int i = 0;
		/*      */
		/* 1154 */Log.e("pengyong", "set_autopower_by_day: ENTER");
		/*      */
		/* 1157 */result = String.format("%02X",
				new Object[] { Integer.valueOf(set_value2[0] - 2000) })
				.getBytes();
		/*      */
		/* 1162 */value[3] = result[0];
		/* 1163 */value[4] = result[1];
		/*      */
		/* 1166 */for (i = 1; i < 10; ++i)
		/*      */{
			/* 1168 */result = String.format("%02X",
					new Object[] { Integer.valueOf(set_value2[i]) }).getBytes();
			/* 1169 */value[(2 * i + 3)] = result[0];
			/* 1170 */value[(2 * i + 4)] = result[1];
			/*      */}
		/*      */
		/* 1174 */result = String.format("%02X",
				new Object[] { Integer.valueOf(set_value2[5] - 2000) })
				.getBytes();
		/*      */
		/* 1179 */value[13] = result[0];
		/* 1180 */value[14] = result[1];
		/*      */
		/* 1184 */result = calu_parity(value);
		/* 1185 */value[(2 * i + 3)] = result[0];
		/* 1186 */value[(2 * i + 4)] = result[1];
		/*      */
		/* 1188 */for (i = 0; i < 26; ++i)
		/*      */{
			/* 1190 */Log.e(
					"pengyong",
					String.format("0x%02x",
							new Object[] { Byte.valueOf(value[i]) }));
			/*      */}
		/*      */
		/* 1195 */for (i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1197 */String str = transfer_uart(value);
			/* 1198 */if (str == null)
			/*      */{
				/*      */continue;
				/*      */}
			/*      */
			/* 1203 */byte[] resu = str.getBytes();
			/*      */
			/* 1205 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1207 */if (resu.length < 5)
			/*      */{
				/* 1209 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1214 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 69) && (check_parity(resu)))
				/*      */{
					/* 1216 */Log.e("pengyong",
							"set_autopower_by_day :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1220 */Log.e("pengyong",
							"set_autopower_by_day: parity is wrong");
					/* 1221 */continue;
					/*      */}
				/*      */
				/* 1224 */return true;
			}
			/*      */}
		/* 1226 */return false;
		/*      */}

	/*      */
	/*      */public synchronized int[] get_onoff_by_day()
	/*      */{
		/* 1232 */int length = 0;
		/*      */
		/* 1234 */byte[] data = new byte[128];
		/* 1235 */byte[] value = { 64, 48, 70, 48, 70, 13 };
		/*      */
		/* 1239 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1242 */String str = transfer_uart(value);
			/* 1243 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1247 */byte[] resu = str.getBytes();
			/*      */
			/* 1249 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1251 */if (resu.length < 5)
			/*      */{
				/* 1253 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1258 */if ((resu[2] == 48) && (resu[3] == 48)
						&& (resu[4] == 70) && (check_parity(resu)))
				/*      */{
					/* 1260 */Log.e("pengyong",
							"get_autopower_by_day :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1264 */Log.e("pengyong",
							"get_autopower_by_day: parity is wrong");
					/* 1265 */continue;
					/*      */}
				/*      */
				/* 1269 */int open_year = get_value(resu, 5, 6) + 2000;
				/* 1270 */int open_month = get_value(resu, 7, 8);
				/* 1271 */int open_day = get_value(resu, 9, 10);
				/* 1272 */int open_hour = get_value(resu, 11, 12);
				/* 1273 */int open_minute = get_value(resu, 13, 14);
				/*      */
				/* 1275 */int shut_year = get_value(resu, 15, 16) + 2000;
				/* 1276 */int shut_month = get_value(resu, 17, 18);
				/* 1277 */int shut_day = get_value(resu, 19, 20);
				/* 1278 */int shut_hour = get_value(resu, 21, 22);
				/* 1279 */int shut_minute = get_value(resu, 23, 24);
				/*      */
				/* 1281 */int[] ret = { open_year, open_month, open_day,
						open_hour, open_minute, shut_year, shut_month,
						shut_day, shut_hour, shut_minute };
				/* 1282 */return ret;
				/*      */}
			/*      */}
		/*      */
		/* 1286 */int[] ret_false = { -1 };
		/* 1287 */return ret_false;
		/*      */}

	/*      */
	/*      */public synchronized boolean enable_onoff_by_day(int enable)
	/*      */{
		/* 1294 */int length = 0;
		/*      */
		/* 1296 */byte[] data = new byte[128];
		/* 1297 */byte[] value = { 64, 49, 48, 48, 48, 49, 48, 13 };
		/*      */
		/* 1302 */if (enable == 1)
		/*      */{
			/* 1305 */value[4] = 48;
			/*      */}
		/*      */else
		/*      */{
			/* 1309 */value[4] = 49;
			/*      */}
		/*      */
		/* 1313 */byte[] result = calu_parity(value);
		/* 1314 */value[5] = result[0];
		/* 1315 */value[6] = result[1];
		/*      */
		/* 1317 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1320 */String str = transfer_uart(value);
			/* 1321 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1325 */byte[] resu = str.getBytes();
			/*      */
			/* 1327 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1329 */if (resu.length < 5)
			/*      */{
				/* 1331 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1336 */if ((resu[2] == 48) && (resu[3] == 49)
						&& (resu[4] == 48) && (check_parity(resu)))
				/*      */{
					/* 1338 */Log.e("pengyong",
							"set_autopower_by_day_command :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1343 */Log.e("pengyong",
							"set_autopower_by_day_command: parity is wrong");
					/* 1344 */continue;
					/*      */}
				/* 1346 */return true;
				/*      */}
			/*      */}
		/* 1349 */return false;
		/*      */}

	/*      */
	/*      */public synchronized int check_onoff_by_day()
	/*      */{
		/* 1356 */int length = 0;
		/*      */
		/* 1358 */byte[] data = new byte[128];
		/* 1359 */byte[] value = { 64, 49, 49, 49, 49, 13 };
		/*      */
		/* 1363 */for (int i = 0; i < this.RETRY; ++i)
		/*      */{
			/* 1366 */String str = transfer_uart(value);
			/* 1367 */if (str == null) {
				/*      */continue;
				/*      */}
			/*      */
			/* 1371 */byte[] resu = str.getBytes();
			/*      */
			/* 1374 */Log.e("pengyong", str + "resu[0]=" + resu[0]);
			/*      */
			/* 1376 */if (resu.length < 5)
			/*      */{
				/* 1378 */Log.e("pengyong", "return bytes too short!");
				/*      */}
			/*      */else
			/*      */{
				/* 1383 */if ((resu[2] == 48) && (resu[3] == 49)
						&& (resu[4] == 49) && (check_parity(resu)))
				/*      */{
					/* 1385 */Log.e("pengyong",
							"get_autopower_by_day_command :parity is right");
					/*      */}
				/*      */else
				/*      */{
					/* 1390 */Log.e("pengyong",
							"get_autopower_by_day_command: parity is wrong");
					/* 1391 */continue;
					/*      */}
				/*      */
				/* 1395 */if (resu[6] == 48)
				/*      */{
					/* 1397 */return 1;
					/*      */}
				/*      */
				/* 1401 */return 0;
				/*      */}
			/*      */
			/*      */}
		/*      */
		/* 1406 */return -1;
		/*      */}
	/*      */
}

/*
 * Location: E:\MyProject\trunk\Andriod\libs\SeriaSDK.jar Qualified Name:
 * android.hardware.SerialManager JD-Core Version: 0.5.3
 */