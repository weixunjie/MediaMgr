package com.example.mcu_func_test;


import android.content.Context;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.AdapterView.OnItemClickListener;
import android.hardware.SerialManager;
import android.hardware.SerialPort;

import java.nio.ByteBuffer;
import java.io.IOException;

public class MainActivity extends Activity {


	public static  SerialManager mSerialManager;
	public static  SerialPort mSerialPort;
	private GridView gvinfo;

	private String[] title=new String[]{"按周设置开关机","读取按周开关机","启动按周开关机","按天设置开关机","读取按天开关机",
                               "启动按天开关机","远程关机"};
	private int[] images= new int[]{R.drawable.icon3,R.drawable.icon4,R.drawable.icon5,
                                R.drawable.icon13,R.drawable.icon14,R.drawable.icon15,R.drawable.icon11};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);	
		
     
      		mSerialManager = (SerialManager)getSystemService("serial");
        

		gvinfo=(GridView)findViewById(R.id.gvinfo);
		gridadapter  adapter =new gridadapter(title, images, this);
		gvinfo.setAdapter(adapter);
		gvinfo.setOnItemClickListener(new OnItemClickListener() {
		public  void onItemClick(AdapterView<?> arg0,View arg1,int arg2,long arg3)
		{
			Intent intent=null;
			Log.e("pengyong", "touch icon"+arg2);
			switch(arg2)
			{

			//按周定时开关机：
			case 0://2:
				intent=new Intent(MainActivity.this, Set_ap_by_week.class);
				startActivity(intent);
				break;
			case 1://3:
				intent=new Intent(MainActivity.this, Get_ap_by_week.class);
				startActivity(intent);
				break;		
			case 2://4:
				intent=new Intent(MainActivity.this, AP_week_work_control.class);
				startActivity(intent);
				
				break;	
				
				
			//按天定时开关机：	
			case 3:
				intent=new Intent(MainActivity.this, Set_ap_by_day.class);
				startActivity(intent);
				
				break;	
				
			case 4:
				intent=new Intent(MainActivity.this, Get_ap_by_day.class);
				startActivity(intent);
				break;	
			case 5:
				intent=new Intent(MainActivity.this, AP_data_work_control.class);
				startActivity(intent);
				break;	

			//远程关机：
			case 6:
				intent=new Intent(MainActivity.this, Remote_control.class);
				startActivity(intent);
				break;	

			}
			
			
			
		}
		});

	
	}

    @Override
    public void onResume() {
        super.onResume();


	}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

	
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		
	
		super.onDestroy();
	}
}
