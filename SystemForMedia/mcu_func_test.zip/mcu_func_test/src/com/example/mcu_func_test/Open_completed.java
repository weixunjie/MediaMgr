package com.example.mcu_func_test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.hardware.SerialManager;
import android.hardware.SerialPort;

import java.nio.ByteBuffer;
import java.io.IOException;

public class Open_completed extends BroadcastReceiver {
    private String ACTION_BOOT = "android.intent.action.BOOT_COMPLETED";

    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals(ACTION_BOOT)){

            Log.e("pengyong", "Boot this system!!!");
        }
    }

}
