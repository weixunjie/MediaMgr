package com.example.mcu_func_test;



import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.os.Build;


import android.hardware.SerialManager;
import android.hardware.SerialPort;
import java.nio.ByteBuffer;
import java.io.IOException;
public class Get_ap_by_day extends Activity {
	private Button bt;
	private TextView tv;
	private Switch  sw;
	private int[]  value=new int[10];
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_get_ap_by_day);
		sw=(Switch) findViewById(R.id.myTimerPicker);
		bt=(Button) findViewById(R.id.bt_get);
		  tv=(TextView) findViewById(R.id.get_values);
		  bt.setOnClickListener(new OnClickListener() {
		   
		   @Override
		   public void onClick(View v) {
		    // TODO Auto-generated method stub

            	    value=MainActivity.mSerialManager.get_onoff_by_day();
            	    if(value[0]!=-1)
		              tv.setText(String.format("open %d-%d-%d  %d:%d   shutdown: %d-%d-%d  %d:%d",value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8],value[9]));
            	    else
            	    	tv.setText(String.format("error!")); 	 
		   }
		  });
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.get_ap_by_day, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_get_ap_by_day,
					container, false);
			return rootView;
		}
	}

}
