/** Automatically generated file. DO NOT MODIFY */
package com.jld.jld.audiobroadcast.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}