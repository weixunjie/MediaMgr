USE [MediaMgrSystem]
GO

/****** Object:  Table [dbo].[VolumnMapping]    Script Date: 01/06/2015 10:33:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VolumnMapping](
	[IpAddress] [nvarchar](50) NULL,
	[VolumnValue] [nvarchar](10) NULL
) ON [PRIMARY]

GO


