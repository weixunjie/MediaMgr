/** Automatically generated file. DO NOT MODIFY */
package com.jld.jld.networkdebug.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}