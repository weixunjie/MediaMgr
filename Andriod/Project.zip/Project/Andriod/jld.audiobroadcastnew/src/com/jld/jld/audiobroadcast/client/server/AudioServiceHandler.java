package com.jld.jld.audiobroadcast.client.server;

public class AudioServiceHandler {
	
	private static AudioServiceApi mAudioServiceApi = new AudioServiceImpl();
	
	
	private static AudioServiceHandler mAudioServiceHandler;
	
	public static synchronized AudioServiceApi getInstance() {
		if (mAudioServiceApi == null) {
			mAudioServiceApi = new AudioServiceImpl();
		}
		return mAudioServiceApi;
	}
	
	public static synchronized AudioServiceApi createApi() {
		if (mAudioServiceApi == null) {
			mAudioServiceApi = new AudioServiceImpl();
		}
		return mAudioServiceApi;
	}

}
