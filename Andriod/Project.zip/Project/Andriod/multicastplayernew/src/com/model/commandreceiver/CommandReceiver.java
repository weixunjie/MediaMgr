package com.model.commandreceiver;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.net.*;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;

import microsoft.aspnet.signalr.client.hubs.HubProxy;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.datamodels.ScheduleInfo;
import com.datamodels.TaskInfo;
import com.model.multicastplayer.MulticastAudioPlayer;
import com.model.multicastplayer.MulticastVideoPlayer;
import com.model.multicastplayer.R;
import com.model.utils.HttpDownloadUtil;
import com.model.utils.Sharereference;

import microsoft.aspnet.signalr.client.ConnectionState;
import microsoft.aspnet.signalr.client.ErrorCallback;
import microsoft.aspnet.signalr.client.Logger;
import microsoft.aspnet.signalr.client.NullLogger;
import microsoft.aspnet.signalr.client.Platform;
import microsoft.aspnet.signalr.client.SignalRFuture;
import microsoft.aspnet.signalr.client.StateChangedCallback;
import microsoft.aspnet.signalr.client.http.android.AndroidPlatformComponent;
import microsoft.aspnet.signalr.client.hubs.HubConnection;
import microsoft.aspnet.signalr.client.hubs.HubProxy;
import microsoft.aspnet.signalr.client.hubs.SubscriptionHandler1;
import android.app.Notification;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.OperationApplicationException;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.hardware.SerialManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.Gpio;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import android.util.Log;
import android.widget.Toast;

public class CommandReceiver extends Service {

	public static final String TAG = "CommandReceiver";

	private HubProxy hub = null;
	private AudioManager mAudioManager = null;

	Context mContext = null;
	public SerialManager mSerialManager;
	String url = "http://192.168.1.100:19671/jiexun";

	private TimeThread th;

	public static final String COMMAND_PLAY = "multicastplayer_play";
	public static final String COMMAND_STOP = "multicastplayer_stop";

	private boolean isConnected;
	public static final String COMMAND_QUIT = "multicastplayer_QUIT";

	Socket socket;
	static DatagramPacket udpPacket = null;
	static DatagramSocket udpSocket = null;

	public static final int MESSAGE_RESTARTCLIENT = 1;

	public static final int MESSAGE_REPLAY = 2;

	final Calendar candStart = Calendar.getInstance();

	final Calendar candEnd = Calendar.getInstance();

	final Calendar tmpCand = Calendar.getInstance();

	public static final int MESSAGE_RECONNECT = 3;

	public static final int COMMAND_SERVER_PLAY = 111;

	public static final int COMMAND_SYNC_TASK = 602;
	public static final int COMMAND_SERVER_PSTOP = 112;

	public static final int COMMAND_SERVER_PPCMSTART = 402;
	public static final int COMMAND_SERVER_PPCMSTOP = 403;

	public static final int COMMAND_SERVER_PLIVESTART = 501;
	public static final int COMMAND_SERVER_PLIVESTOP = 502;

	public static final int COMMAND_SYNC_TIME = 130;

	public static final int COMMAND_CHANGE_IPADDR = 128;

	public static final int COMMAND_RESTART_DEVICE = 124;

	public static final int COMMAND_SHUTDOWN_DEVICE = 125;

	public static final int COMMAND_OPEN_SCREEN = 122;

	public static final int COMMAND_CLOSE_SCREEN = 123;

	public static final int COMMAND_SCHEDULE_TRUNONSHUTDOWN_DEVICE = 127;

	public static final int COMMAND_ADJUST_VOL = 129;

	public static ArrayList<String> networkStatusStrings = new ArrayList<String>();

	public static Object lockForNewworkLog = new Object();
	public boolean isSendingLogs = false;

	public static boolean beginToSendLogs = false;

	private boolean mIsClientRunning;

	public HubConnection conn;

	private String path;

	private String guidId;

	// private boolean mIsConnected = false;

	private boolean mTestOpen = false;

	CommandBean bean = null;

	public MulticastAudioPlayer mAudioPlayer = null;

	private ConnectivityManager connectivity = null;

	public enum MediaType {
		vodaduio, vodvideo, liveaudio, livevideo
	}

	private HttpDownloadUtil httpDownloadUtil;

	MediaType mediatype;

	class NetWorkChangedReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();

			try {
				Log.e(TAG, "current network type action:" + action);

				if (TextUtils.equals(action,
						"android.net.conn.CONNECTIVITY_CHANGE")) {

					NetworkInfo info = connectivity.getActiveNetworkInfo();

					SimpleDateFormat formatter = new SimpleDateFormat(
							"yyyy-MM-dd閿熸枻鎷�   HH:mm:ss");
					Date curDate = new Date(System.currentTimeMillis());// 閿熸枻鎷峰彇閿熸枻鎷峰墠鏃堕敓鏂ゆ嫹
					String str = formatter.format(curDate);
					if (null == info) {

						Log.e(TAG,
								"current network type:connetion status:disconnected");

						// return;
					} else

					{
						Log.e(TAG, "current network type:" + info.getTypeName()
								+ ", connetion status:"
								+ info.getState().toString());

						// return;
					}
				}

			} catch (Exception ex) {
				Log.e(TAG, "get network type Error" + ex.getMessage());
			}
		}

	}

	NetWorkChangedReceiver netWorkStatusReceiver;

	public void registerReceiver(Context context) {
		if (netWorkStatusReceiver == null) {
			netWorkStatusReceiver = new NetWorkChangedReceiver();
		}
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
		filter.setPriority(1000);
		context.registerReceiver(netWorkStatusReceiver, filter);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub

		super.onCreate();

		try {
			mContext = this;

			connectivity = (ConnectivityManager) mContext
					.getSystemService(Context.CONNECTIVITY_SERVICE);

			IntentFilter filter = new IntentFilter();
			filter.addAction(MulticastVideoPlayer.COMMAND_NETWORK_ERROR);
			filter.addAction(MulticastVideoPlayer.COMMAND_PLAYER_ERROR);
			filter.addAction(MulticastVideoPlayer.COMMAND_CLIENT_UPDATEADDR);
			filter.addAction(MulticastVideoPlayer.COMMAND_PLAY_RESULT);
			registerReceiver(mClientListener, filter);
			mIsClientRunning = false;
			url = Sharereference.getMulticastAddr(this,
					"http://192.168.1.100:19671/jiexun/signalr/hubs");

			mSerialManager = (SerialManager) getSystemService("serial");
			mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

			String str = Sharereference.getScheduleMCUTask(this.mContext, "");
			if ((str != null) && (!str.equals(""))) {
				Log.i("TaskMCU", str + " Oncreate set....");
				String[] arrayOfString = str.split(",");
				if ((arrayOfString != null) && (arrayOfString.length > 0)) {
					setTimeByDay(arrayOfString[0].equals("1"),
							arrayOfString[1], arrayOfString[2]);
				}
			}

			// play a short music when service start
			AssetManager assetManager = getAssets();
			AssetFileDescriptor in;
			try {
				Log.d("asserts test", "start to get asserts");
				// in = assetManager.openFd("dylan.mp3");
				in = assetManager.openFd("nosense.mp3");
				mAudioPlayer = new MulticastAudioPlayer(null);
				mAudioPlayer.play(in.getFileDescriptor());

				myHandler.postDelayed(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (mAudioPlayer != null) {

							Sharereference.setIsLocalPlaying(mContext, "");
							mAudioPlayer.stop();

							if (th != null) {
								th.stop();
								th = null;
							}
							mAudioPlayer = new MulticastAudioPlayer(mContext);
							th = new TimeThread();
							th.start();
						}
					}
				}, 10000);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			new Thread(new Runnable() {

				public void run() {
					byte abyte0[] = new byte[256];
					String s;
					String s1;
					IOException ioexception3;
					String as[];
					try {
						CommandReceiver.udpSocket = new DatagramSocket(43708);
						CommandReceiver.udpPacket = new DatagramPacket(abyte0,
								abyte0.length);
					} catch (SocketException socketexception) {
						socketexception.printStackTrace();
					}

					do
						try {
							CommandReceiver.udpSocket
									.receive(CommandReceiver.udpPacket);
						} catch (Exception exception3) {
						}
					while (CommandReceiver.udpPacket.getAddress() == null);
					CommandReceiver.udpPacket.getAddress().toString();
					s = new String(abyte0, 0, CommandReceiver.udpPacket
							.getLength());
					if (!s.equals("")) {
						Log.e("LW", (new StringBuilder(
								"get command to set server url ")).append(s)
								.toString());
						as = s.split("@");
						if (as != null && as.length >= 2) {
							Log.e("LW", (new StringBuilder(
									"set new server url ")).append(as[1])
									.toString());
							Sharereference.setPathAddr(mContext, as[1]);
							try {
								Thread.sleep(2000);
							} catch (InterruptedException interruptedexception) {
								interruptedexception.printStackTrace();
							}
							try {
								execShell("reboot");
							} catch (Exception exception5) {
							}
						}
					}
					s1 = CommandReceiver.udpPacket.getAddress().toString()
							.substring(1);
					try {
						socket = new Socket(s1, 8080);
					} catch (UnknownHostException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						if (socket == null) {
							socket.close();
						}
					}
					// Misplaced declaration of an exception variable
					catch (IOException ioexception31) {
						ioexception31.printStackTrace();
					}

				}
			});

			Log.i("laowei", "Palyer Service On Create");
		} catch (Exception ex) {
			Log.i("laowei",
					"Palyer Service On Create Exception" + ex.getMessage());

		}

	}

	private void setTimeByDay(boolean paramBoolean, String paramString1,
			String paramString2) {
		if (paramBoolean) {
			String[] arrayOfString1 = paramString1.split(":");
			String[] arrayOfString2 = paramString2.split(":");
			int i = Integer.valueOf(arrayOfString1[0]).intValue();
			int j = Integer.valueOf(arrayOfString1[1]).intValue();
			int k = Integer.valueOf(arrayOfString2[0]).intValue();
			int m = Integer.valueOf(arrayOfString2[1]).intValue();
			long l1 = System.currentTimeMillis();
			String str1 = DateFormat.format("yyyy-MM-dd ", l1) + paramString1;
			String str2 = DateFormat.format("yyyy-MM-dd ", l1) + paramString2;
			SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd kk:mm:ss");
			try {
				try {
					this.candStart.setTime(localSimpleDateFormat.parse(str1));
				} catch (java.text.ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					this.candEnd.setTime(localSimpleDateFormat.parse(str2));
				} catch (java.text.ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				long l2 = System.currentTimeMillis();
				long l3 = l2 + 86400000L;
				if (this.candEnd.getTimeInMillis() > l1) {
					this.tmpCand.setTimeInMillis(l2);
				}

				this.tmpCand.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
				int n = this.tmpCand.get(1);
				int i1 = 1 + this.tmpCand.get(2);
				int i2 = this.tmpCand.get(5);
				this.tmpCand.setTimeInMillis(l3);
				this.tmpCand.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
				int i3 = this.tmpCand.get(1);
				int i4 = 1 + this.tmpCand.get(2);
				int i5 = this.tmpCand.get(5);
				int[] arrayOfInt = { i3, i4, i5, i, j, n, i1, i2, k, m };
				Log.i("TaskMCU",
						"Set Schdule Turn off and on Open Time:"
								+ String.valueOf(i3) + "-" + String.valueOf(i4)
								+ "-" + String.valueOf(i5) + " "
								+ String.valueOf(i) + ":" + String.valueOf(j)
								+ " Close Time:" + String.valueOf(n) + "-"
								+ String.valueOf(i1) + "-" + String.valueOf(i2)
								+ " " + String.valueOf(k) + ":"
								+ String.valueOf(m));
				this.mSerialManager.set_onoff_by_day(arrayOfInt);
				this.mSerialManager.enable_onoff_by_day(1);
				this.tmpCand.setTimeInMillis(l3);

			} catch (ParseException localParseException) {
				localParseException.printStackTrace();
			}
		} else {

			this.mSerialManager.enable_onoff_by_day(0);
		}
		Log.i("TaskMCU", "Set OFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF now");
	}

	private boolean getIsNotNetwork() {
		NetworkInfo localNetworkInfo = this.connectivity.getActiveNetworkInfo();
		boolean bool = false;
		if (localNetworkInfo == null) {
			bool = true;
		}
		return bool;
	}

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);

		try {

			try

			{
				if (conn != null) {

					try {
						conn.stop();

					} catch (Exception ex) {

					}
					// conn.Stop();
					conn = null;

				}
			} catch (Exception ex) {

				Log.i("laowei", "onStart release conn error" + ex.getMessage());
			}

			Notification notification = new Notification();
			notification.flags = Notification.FLAG_ONGOING_EVENT;
			notification.flags |= Notification.FLAG_NO_CLEAR;
			notification.flags |= Notification.FLAG_FOREGROUND_SERVICE;
			startForeground(1, notification);

			Platform.loadPlatformComponent(new AndroidPlatformComponent());

			beginConnect();

			// mIsConnected = false;
			// Log.d("laowei", "onStart exec error");
			//
			// myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT, 5000);
			//
			// Log.d("laowei", "onStart exec" + e.getMessage());

			registerReceiver(this);

			Log.i("laowei", "Palyer Service On Start");
		} catch (Exception ex) {
			Log.i("laowei", "Palyer Service On Start" + ex.getMessage());

		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		//
		// Intent localIntent = new Intent();
		// localIntent.setClass(this, CommandReceiver.class); // 销毁时重新启动Service
		// this.startService(localIntent);

		try {

			unregisterReceiver(mClientListener);

			Log.e("laowei", "Palyer Service On Destory, try to reboot system");
			execShell("reboot");

		} catch (Exception ex) {
			Log.e("laowei", "on Destory reboot failed");
		}

	}

	private BroadcastReceiver mClientListener = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {

			String action = intent.getAction();
			Log.i(TAG, "onReceive action :" + action);

			if (action.equals(MulticastVideoPlayer.COMMAND_PLAYER_ERROR)) {
				myHandler.sendEmptyMessageDelayed(MESSAGE_RESTARTCLIENT, 1000);
			} else if (action.equals(MulticastVideoPlayer.COMMAND_CLIENT_QUIT)) {
				mIsClientRunning = false;
			} else if (action
					.equals(MulticastVideoPlayer.COMMAND_CLIENT_UPDATEADDR)) {
				url = Sharereference.getMulticastAddr(context,
						"http://192.168.1.100:19671/signalr/hubs");
			} else if (action
					.equals(MulticastVideoPlayer.COMMAND_OPEN_TEST_TAG)) {
				mTestOpen = true;
			} else if (action.equals(MulticastVideoPlayer.COMMAND_PLAY_RESULT)) {

				String errCode = intent.getStringExtra("errcode");

				if (errCode.equals("1")) {
					Sharereference.setIsPlaying(mContext, errCode);

					serverCallBack(hub, "0");

					Sharereference.setLastPlayTime(mContext,
							String.valueOf(System.currentTimeMillis()));
					return;
				}
				if (errCode.equals("2")) {
					Sharereference.setIsPlaying(mContext, errCode);
					Sharereference.setLastPlayTime(mContext,
							String.valueOf(System.currentTimeMillis()));

					serverCallBack(hub, "0");
					return;
				}

				serverCallBack(hub, "119");
			}
		}
	};

	Handler myHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			switch (msg.what) {
			case MESSAGE_RESTARTCLIENT:
				notifyCommand(COMMAND_PLAY, bean, true);
				mIsClientRunning = true;
				break;

			case MESSAGE_RECONNECT:

				try {

					if (conn != null) {
						try {
							conn.stop();
							conn = null;
						} catch (Exception ex) {
							conn = null;
						}
					}
					beginConnect();
				} catch (Exception e) {

					// Log.d("laowei", "connection exec error");
					//
					// Looper.prepare();
					//
					// myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT,
					// 5000);
					//
					// Looper.loop();
					//
					// Log.d("laowei", "connection exec" + e.getMessage());
					// conn.Start();
					// TODO Auto-generated catch block
					// e.printStackTrace();
				}
				// conn.Start();
				break;

			default:

			}
		}

	};

	Handler handlerShowTime = new Handler() {
		@Override
		public void handleMessage(Message message) {
			super.handleMessage(message);

			switch (message.what) {

			case 0:
				String lastBootTime = Sharereference.getIsLastRebootTime(
						mContext, "");
				SimpleDateFormat simpledateformat = new SimpleDateFormat(
						"yyyyMMddkkmm");
				String currentTime = simpledateformat
						.format(new java.util.Date());

				Log.e("LW",
						(new StringBuilder("Check reoobt")).append(currentTime)
								.append(" ")
								.append(currentTime.substring(8, 4)).toString());
				if (currentTime.substring(8, 4).equals("0100")
						&& currentTime.equals(lastBootTime)) {
					Log.e("LW",
							(new StringBuilder("Check reoobt")).append(
									currentTime).toString());
					Sharereference.setIsLastRebootTime(mContext, currentTime);

					try {
						Thread.sleep(2000);
						Log.e("LW", (new StringBuilder(" reboot now..."))
								.append(currentTime).toString());
						execShell("reboot");
					} catch (Exception exception1) {
					}
				}

				String strIsPlaying = Sharereference.getIsPlaying(mContext, ""); // s2
				String isLocalPlaying = Sharereference.getIsLocalPlaying(
						mContext, ""); // s3
				if (strIsPlaying.equals("1") || isLocalPlaying.equals("1")) {
					return;
				}

				ScheduleInfo scheduleinfo = Sharereference
						.getScheduleInfo(mContext);
				if (scheduleinfo == null || scheduleinfo.getTasks() == null
						|| scheduleinfo.getTasks().size() <= 0) {
					for (int i = 0; i < scheduleinfo.getTasks().size(); i++) {

						TaskInfo taskinfo = scheduleinfo.getTasks().get(i);
						if (taskinfo != null) {

							boolean isTodayFlag = false;
							if (taskinfo.getWeeks() == null
									|| taskinfo.getWeeks().equals("")) {
								String strDays = taskinfo.getDays(); // s4

								if (strDays != null && !strDays.equals("")) {
									String[] strTaskDay = taskinfo.getDays()
											.split(","); // as

									for (int k = 0; k < strTaskDay.length; k++) {

										SimpleDateFormat strSimpleFormat = new SimpleDateFormat(
												"yyyy-MM-dd kk:mm:ss"); // simpledateformat1
										try {
											try {
												candStart
														.setTime(strSimpleFormat
																.parse((new StringBuilder(
																		String.valueOf(strTaskDay[k])))
																		.append(" 00:00:01")
																		.toString()));
											} catch (java.text.ParseException e) {
												// TODO Auto-generated catch
												// block
												e.printStackTrace();
											}
										}
										// Misplaced declaration of an exception
										// variable
										catch (ParseException parseexception) {
											parseexception.printStackTrace();
										}
										if (DateUtils.isToday(candStart
												.getTimeInMillis())) {
											isTodayFlag = true;
											break;
										}

									}
								}

							} else {
								String[] taskWeeks = taskinfo.getWeeks().split(
										","); // as1

								if (taskWeeks != null && taskWeeks.length > 0) {
									for (int j = 0; j < taskWeeks.length; j++) {

										String weekNumber = getWeekNumber();

										if (weekNumber.equals(taskWeeks[j])) {
											isTodayFlag = true;
											break;
										}

									}
								}
							}

							if (isTodayFlag) {

								String strLastPlayTime = Sharereference
										.getLastPlayTime(mContext, ""); // s5
								long currentLongTime = System
										.currentTimeMillis(); // li
								String strStartTime = (new StringBuilder())
										.append(DateFormat.format(
												"yyyy-MM-dd ", currentLongTime))
										.append(taskinfo.getStartTime())
										.toString(); // s6
								String strEndTime = (new StringBuilder())
										.append(DateFormat.format(
												"yyyy-MM-dd ", currentLongTime))
										.append(taskinfo.getEndTime())
										.toString();// s7
								SimpleDateFormat tmpFormat = new SimpleDateFormat(
										"yyyy-MM-dd kk:mm:ss");
								try {
									candStart.setTime(tmpFormat
											.parse(strStartTime));
								} catch (java.text.ParseException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								try {
									candEnd.setTime(tmpFormat.parse(strEndTime));
								} catch (java.text.ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								if (currentLongTime
										- candStart.getTimeInMillis() <= 5000
										|| currentLongTime >= candEnd
												.getTimeInMillis()) {
									boolean isLastPlayisBefore12Sec = false;

									if (strLastPlayTime != null
											&& !strLastPlayTime.equals("")) {
										if (currentLongTime
												- Long.valueOf(strLastPlayTime) >= 12000) {
											isLastPlayisBefore12Sec = true;
										}
									}

								}

								if (mAudioPlayer != null)

									try {
										mAudioPlayer.stop();
									}
									// Misplaced declaration of an exception
									// variable
									catch (Exception exception) {
									}

								mAudioPlayer = new MulticastAudioPlayer(null);

								Sharereference.setIsLocalPlaying(mContext, "1");
								Log.i("STask",
										(new StringBuilder(
												"Fun, playing now...."))
												.append(taskinfo.getStartTime())
												.append(taskinfo.getFileName())
												.toString());
								mAudioPlayer.play((new StringBuilder())
										.append(Environment
												.getExternalStorageDirectory())
										.append("/scRings/")
										.append(taskinfo.getFileName())
										.toString());

								myHandler.postDelayed(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										if (mAudioPlayer != null) {

											Sharereference.setIsLocalPlaying(
													mContext, "");
											mAudioPlayer.stop();
										}
									}
								}, candEnd.getTimeInMillis() - currentLongTime);
							}
						}
					}
				}
			}
		}

	};

	private void beginConnect() {

		try {

			if (getIsNotNetwork() == true) {
				Log.d("laowei",
						"Network is not avaiable, no need connect to singalR, after 5 sec to check again");

				myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT, 5000);

				return;
			}

			if (!url.startsWith("http://")) {
				url = "http://" + url;
			}

			if (url.indexOf("signalr/hubs") < 0) {
				url = url + "/signalr/hubs";
			}

			Log.d("laowei", "begin connecti to " + url);

			try {
				conn = new HubConnection(url,
						"clientType=ANDROID&clientIdentify="
								+ this.getLocalIPAddress() + "&macAddress="
								+ getMacAddress(), true, new NullLogger());
			} catch (SocketException e2) {

				Log.e("laowei", "mIsConnected Hub" + e2.getMessage());
				// beginConnect();

			}

			conn.stateChanged(new StateChangedCallback() {

				@Override
				public void stateChanged(ConnectionState arg0,
						ConnectionState arg1) {

					if (arg1 == ConnectionState.Disconnected) {

						isConnected = false;
						Log.d("laowei", "DISConnected");
						// conn.Start();
						myHandler.sendEmptyMessageDelayed(MESSAGE_RECONNECT,
								5000);

						isConnected = false;
						if (bean == null)
							bean = new CommandBean("", "", "", "");
						Sharereference.setIsPlaying(mContext, "2");
						Sharereference.setLastPlayTime(mContext,
								String.valueOf(System.currentTimeMillis()));
						notifyCommand("multicastplayer_stop", bean, false);

					} else if (arg1 == ConnectionState.Reconnecting) {
						Log.d("laowei", "Reconnecting");

					} else if (arg1 == ConnectionState.Connected) {

						isConnected = true;
						beginToSendLogs = true;
						Log.d("laowei", "Connected");
						Toast.makeText(mContext, R.string.serversucess,
								Toast.LENGTH_LONG).show();
					}
				}
			});

			hub = conn.createHubProxy("MediaMgrHub");

			hub.on("SendMessageToClient", new SubscriptionHandler1<String>() {
				@Override
				public void run(String status) {

					{

						try {

							Log.i(TAG, "received Json from Server: " + status);

							JSONObject resultObject = null;

							resultObject = new JSONObject(status);

							String command = null;

							int commandType = Integer.parseInt(resultObject
									.get("commandType").toString());

							guidId = resultObject.get("guidId").toString();

							Log.i(TAG, "commandType: " + commandType);

							if (commandType == COMMAND_SYNC_TASK) {

								ArrayList localArrayList = new ArrayList();
								JSONArray localJSONArray = new JSONArray(
										resultObject.get("tasks").toString());
								ScheduleInfo localScheduleInfo = new ScheduleInfo();

								localScheduleInfo.setTasks(new ArrayList());

								for (int j = 0; j < localJSONArray.length(); j++) {

									Sharereference.setScheduleInfo(mContext,
											localScheduleInfo);

									JSONObject localJSONObject2 = new JSONObject(
											localJSONArray.get(j).toString());
									TaskInfo localTaskInfo = new TaskInfo();
									localTaskInfo.setDays(localJSONObject2.get(
											"days").toString());
									localTaskInfo.setEndTime(localJSONObject2
											.get("endTime").toString());
									localTaskInfo.setStartTime(localJSONObject2
											.get("startTime").toString());
									localTaskInfo.setWeeks(localJSONObject2
											.get("weeks").toString());
									localTaskInfo.setFileName(localJSONObject2
											.get("fileName").toString());
									String strFilePath = localJSONObject2.get(
											"filePath").toString();
									String strAddress = Sharereference
											.getMulticastAddr(mContext, "");
									if (!strAddress.startsWith("http://")) {
										strAddress = "http://" + strAddress;
									}
									String strReallyPath = strFilePath
											.replaceAll("\\\\", "/");
									if (!localArrayList.contains(localTaskInfo
											.getFileName())) {
										localArrayList.add(localTaskInfo
												.getFileName());
										new downloadTask(strAddress
												+ "/FileSource/"
												+ strReallyPath, "scRings",
												localTaskInfo.getFileName())
												.start();
										// new downloadTask(
										// this.this$0, str2
										// + "/FileSource/"
										// + strReallyPath,
										// "scRings", localTaskInfo
										// .getFileName()).start();
									}

									localScheduleInfo.getTasks().add(
											localTaskInfo);
								}
							}

							else if (commandType == COMMAND_SERVER_PLAY) {

								if (Sharereference.getIsLocalPlaying(mContext,
										"").equals("1")) {

									return;
								}

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String url = argObject.get(
										"udpBroadcastAddress").toString();
								String streamName = (String) argObject.get(
										"streamName").toString();

								String mineType = argObject.get("mediaType")
										.toString();
								String bitrate = argObject.get("bitRate")
										.toString();

								String mediaType;
								if (mineType.equals("1")) {
									mediaType = "audio";
								} else {
									mediaType = "video";
								}

								if (bean == null) {
									bean = new CommandBean(url, mediaType,
											streamName, bitrate);
								} else {
									bean.mUdpBroadcastAddress = url;
									bean.mMediaType = mediaType;
									bean.mStreamName = streamName;
									bean.mBitrate = bitrate;
								}

								// start play
								command = COMMAND_PLAY;
								mIsClientRunning = true;
							} else if (commandType == COMMAND_SERVER_PSTOP) {
								command = COMMAND_STOP;
								mIsClientRunning = false;
								// stop play
							}

							else if (commandType == COMMAND_SERVER_PPCMSTART) {

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String url = argObject.get(
										"udpBroadcastAddress").toString();

								String bitrate = argObject.get("baudRate")
										.toString();

								String mediaType = "pcm";

								if (bean == null) {
									bean = new CommandBean(url, mediaType, "",
											bitrate);
								} else {
									bean.mUdpBroadcastAddress = url;
									bean.mMediaType = mediaType;
									bean.mStreamName = "";
									bean.mBitrate = bitrate;
								}

								// start play
								command = COMMAND_PLAY;
								mIsClientRunning = true;

							} else if (commandType == COMMAND_SERVER_PPCMSTOP) {
								command = COMMAND_STOP;
								mIsClientRunning = false;

							} else if (commandType == COMMAND_SERVER_PLIVESTART) {
								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String url = argObject.get(
										"udpBroadcastAddress").toString();
								// String streamName = (String) argObject
								// .get("streamName").toString();

								String mineType = "0";
								String bitrate = argObject.get("biteRate")
										.toString();

								String mediaType = "live";
								if (mineType.equals("1")) {
									mediaType = "live";
								} else {
									mediaType = "live";
								}

								if (bean == null) {
									bean = new CommandBean(url, mediaType, "",
											bitrate);
								} else {
									bean.mUdpBroadcastAddress = url;
									bean.mMediaType = mediaType;
									bean.mStreamName = "";
									bean.mBitrate = bitrate;
								}

								// start play
								command = COMMAND_PLAY;
								mIsClientRunning = true;

								// stop play
							} else if (commandType == COMMAND_SERVER_PLIVESTOP) {
								command = COMMAND_STOP;
								mIsClientRunning = false;
								// stop play
							} else if (commandType == COMMAND_CHANGE_IPADDR) {

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String newIpAddress = argObject.get(
										"newIpAddress").toString();

								Log.e("ip", newIpAddress);
								Settings.Secure.putString(getContentResolver(),
										"eth_ip", newIpAddress);

								execShell("if config eth0 down");

								Thread.sleep(2000);
								execShell("if config eth0 up");

								// Gpio.writeGpio(group, num, value)

								// wifiAdmin = new WifiAdmin(context);
								//
								// DhcpInfoInternal mDhcpInfoInternal = new
								// DhcpInfoInternal();
								// String ipAddress = "192.168.22.69";
								// String DNS1 = "192.168.10.247";
								// String DNS2 = "192.168.10.247";
								// InetAddress iRoute = NetworkUtils
								// .numericToInetAddress("192.168.22.1");
								// InetAddress iNetmask = NetworkUtils
								// .numericToInetAddress("255.255.255.0");
								// try {
								// int netmask = NetworkUtils
								// .inetAddressToInt(iNetmask);
								// int prefixLength = NetworkUtils
								// .netmaskIntToPrefixLength(netmask);
								// mDhcpInfoInternal.prefixLength =
								// prefixLength;
								// } catch (IllegalArgumentException e) {
								// e.printStackTrace();
								// }
								// mDhcpInfoInternal.ipAddress = ipAddress;
								// mDhcpInfoInternal.addRoute(new
								// RouteInfo(iRoute));
								// mDhcpInfoInternal.dns1 = DNS1;
								// mDhcpInfoInternal.dns2 = DNS2;
								// mDhcpInfoInternal.serverAddress =
								// "255.255.255.0";
								//
								// mEthManager.saveEthernetIpInfo(
								// mDhcpInfoInternal.makeDhcpInfo(),
								// EthernetManager.ETHERNET_CONNECT_MODE_MANUAL);
								// mEthManager.setEthernetEnabled(true);
								// DhcpInfo dhcpInfo = mEthManager
								// .getSavedEthernetIpInfo();
								// dhcp_gateway = Formatter
								// .formatIpAddress(dhcpInfo.gateway);

								// DataOutputStream dos = null;
								// DataInputStream dis = null;
								//
								// String result = "";
								// try {
								//
								// String cmd = "ifconfig eth0 " + newIpAddress
								// + " netmask 255.255.255.0";
								// Process p = Runtime.getRuntime().exec(cmd);
								// // dos = new
								// // DataOutputStream(p.getOutputStream());
								// dis = new
								// DataInputStream(p.getInputStream());
								// // System.out.println(cmd);
								//
								// // dos.writeBytes(cmd + "\n");
								// // dos.flush();andriod toggle texton empty
								// // dos.writeBytes("exit\n");
								// // dos.flush();
								//
								// String line = null;
								// while ((line = dis.readLine()) != null) {
								// result += line;
								// }
								// p.waitFor();
								// } catch (Exception e) {
								// e.printStackTrace();
								// } finally {
								// // if (dos != null) {
								// // try {
								// // //dos.close();
								// // } catch (IOException e) {
								// // e.printStackTrace();
								// // }
								// // }
								// if (dis != null) {
								// try {
								// dis.close();
								// } catch (IOException e) {
								// e.printStackTrace();
								// }
								// }
								// }
								//
								// execShell("ifconfig eth0 " + newIpAddress
								// + " netmask 255.255.255.0");

								String serverUrl = argObject.get("serverUrl")
										.toString();

								if (serverUrl != null && !serverUrl.equals("")) {

									Sharereference.setPathAddr(mContext,
											serverUrl);
								}

								serverCallBack(hub, "0");
								// restart when change server url
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								try {

									execShell("reboot");
									// mSerialManager.restart_system();
								} catch (Exception ex) {
								}

							}

							else if (commandType == COMMAND_RESTART_DEVICE) {

								serverCallBack(hub, "0");

								try {
									Thread.sleep(2000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								try {

									execShell("reboot");
									// mSerialManager.restart_system();
								} catch (Exception ex) {
								}

							}

							else if (commandType == COMMAND_SHUTDOWN_DEVICE) {

								serverCallBack(hub, "0");

								try {
									Thread.sleep(2000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								try {
									mSerialManager.shutdown_system();
								} catch (Exception ex) {

								}
							} else if (commandType == COMMAND_ADJUST_VOL) {

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String volValue = argObject.get("volValue")
										.toString();

								mAudioManager.setStreamVolume(
										AudioManager.STREAM_MUSIC,
										Integer.valueOf(volValue),
										AudioManager.FLAG_SHOW_UI);

								serverCallBack(hub, "0");

							}

							else if (commandType == COMMAND_SCHEDULE_TRUNONSHUTDOWN_DEVICE) {

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String scheduleTurnOnTime = argObject.get(
										"scheduleTurnOnTime").toString();

								String scheduleShutDownTime = argObject.get(
										"scheduleShutDownTime").toString();

								String isEnabled = argObject.get("isEnabled")
										.toString();

								Sharereference.setScheduleMCUTask(mContext,
										isEnabled + "," + scheduleTurnOnTime
												+ "," + scheduleShutDownTime);

								setTimeByDay(isEnabled.equals("1"),
										scheduleTurnOnTime,
										scheduleShutDownTime);

								// String[] scheduleTurnOnTimeArray =
								// scheduleTurnOnTime
								// .split(":");
								//
								// String[] scheduleShutDownTimeArray =
								// scheduleShutDownTime
								// .split(":");
								//
								// int open_hour = Integer
								// .valueOf(scheduleTurnOnTimeArray[0]);
								// int open_minute = Integer
								// .valueOf(scheduleTurnOnTimeArray[1]);
								//
								// int close_hour = Integer
								// .valueOf(scheduleShutDownTimeArray[0]);
								// int close_minute = Integer
								// .valueOf(scheduleShutDownTimeArray[1]);
								//
								// try
								//
								// {
								//
								// int[] weeks = new int[] { 0x01, 0x02, 0x03,
								// 0x04, 0x05, 0x06, 0x07 };
								//
								// for (int i = 0; i < 7; i++) {
								// int set_value[] = { weeks[i],
								// open_hour, open_minute,
								// close_hour, close_minute };
								// mSerialManager
								// .set_onoff_by_week(set_value);
								// }
								//
								// int[] week_value = { 0, 0, 0, 0, 0, 0, 0 };
								//
								// week_value[0] = isEnabled.charAt(0) - 0x30;
								// week_value[1] = isEnabled.charAt(0) - 0x30;
								// week_value[2] = isEnabled.charAt(0) - 0x30;
								// week_value[3] = isEnabled.charAt(0) - 0x30;
								// week_value[4] = isEnabled.charAt(0) - 0x30;
								// week_value[5] = isEnabled.charAt(0) - 0x30;
								// week_value[6] = isEnabled.charAt(0) - 0x30;
								//
								// // mSerialManager.
								//
								// mSerialManager
								// .enable_onoff_by_week(week_value);
								// } finally {
								// }

								serverCallBack(hub, "0");

							} else if (commandType == COMMAND_SYNC_TIME) {

								JSONObject argObject = new JSONObject(
										resultObject.get("arg").toString());
								String serverNowTime = argObject.get(
										"serverNowTime").toString();

								String upgradeUrl = argObject.get("upgradeUrl")
										.toString();

								String verisonId = argObject.get("upgradeVer")
										.toString();

								String dbVid = Sharereference.getVersionNumber(
										mContext, "1");

								Log.v("laowei", "dbVId" + dbVid + "RVid"
										+ verisonId);

								// JSONObject localJSONObject8 = new
								// JSONObject(localJSONObject1.get("arg").toString());
								// String str21 =
								// localJSONObject8.get("serverNowTime").toString();
								// String str22 =
								// localJSONObject8.get("upgradeUrl").toString();
								// String str23 =
								// localJSONObject8.get("upgradeVer").toString();
								// String str24 =
								// Sharereference.getVersionNumber(this.this$0.mContext,
								// "1");
								// Log.v("laowei", "dbVId" + str24 + "RVid" +
								// str23);
								// if (!str24.equals(str23))
								// {
								// Sharereference.setVersionNumber(this.this$0.mContext,
								// str23);
								// Intent localIntent = new Intent();
								// localIntent.addFlags(268435456);
								// localIntent.putExtra("upgradeUrl", str22);
								// localIntent.putExtra("md5String", "");
								// localIntent.putExtra("isOTA", false);
								// localIntent.setClass(this.this$0.mContext,
								// UpgradeService.class);
								// this.this$0.mContext.startService(localIntent);
								// }
								// try
								// {
								// SystemClock.setCurrentTimeMillis(Long.valueOf(str21).longValue());
								// str9 = null;
								// }
								// catch (Exception localException4)
								// {
								// Log.v("CommandReceiver", "Set Time Error" +
								// localException4.getMessage());
								// str9 = null;
								// }
								//
								// Intent intentU = new Intent();
								//
								// intentU.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								// intentU.putExtra("upgradeUrl", upgradeUrl);
								// intentU.setClass(
								// mContext,
								// com.model.multicastplayer.UpgradeService.class);
								// mContext.startService(intentU);

								if (!dbVid.equals(verisonId)) {

									Sharereference.setVersionNumber(mContext,
											verisonId);
									Intent intentU = new Intent();

									intentU.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
									intentU.putExtra("upgradeUrl", upgradeUrl);

									intentU.putExtra("md5String", "");
									intentU.putExtra("isOTA", false);
									intentU.setClass(
											mContext,
											com.model.multicastplayer.UpgradeService.class);
									mContext.startService(intentU);

								}

								try {

									// mSerialManager.save_system_time_to_rtc(millionsecond)
									// mSerialManager.(Long
									// .valueOf(serverNowTime));
									SystemClock.setCurrentTimeMillis(Long
											.valueOf(serverNowTime));

								} catch (Exception ex) {

									Log.v(TAG,
											"Set Time Error" + ex.getMessage());
									// serverCallBack(hub,
									// "13","Set Time Error: "+ex.getMessage());
								}

							}

							if (bean == null) { // solve stop command can not
												// executed after service
												// restated
												// 2015-1-8
								bean = new CommandBean("", "", "", "");
							}

							notifyCommand(command, bean, mIsClientRunning);
							// hub.Invoke("sendPlayResponseMessage", args,
							// null);

						} catch (JSONException e) {
							// TODO Auto-generated catch block
							// e.printStackTrace();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							// e1.printStackTrace();
						}
					}

				}

			}, String.class);

			SignalRFuture<Void> awaitConnection = conn.start();

			awaitConnection.get();

		} catch (Exception ex) {

			Log.e("laowei",
					"Exception beging conn global Hub" + ex.getMessage());
			// beginConnect();

		}
	}

	private String getWeekNumber() {
		Calendar.getInstance().setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
		int i = Calendar.getInstance().get(7);
		if (i == 1) {
		}
		for (int j = i - 7;; j = i - 1) {
			return String.valueOf(j);
		}
	}

	MulticastAudioPlayer ap;

	public String getMacAddress() {
		String result = "";
		String Mac = "";
		result = callCmd("busybox ifconfig", "HWaddr");

		if (result == null) {
			return "";
		}

		if (result.length() > 0 && result.contains("HWaddr") == true) {
			Mac = result.substring(result.indexOf("HWaddr") + 6,
					result.length() - 1);
			Log.i("test", "Mac:" + Mac + " Mac.length: " + Mac.length());

			if (Mac.length() > 1) {
				Mac = Mac.replaceAll(" ", "");
				result = "";
				String[] tmp = Mac.split(":");
				for (int i = 0; i < tmp.length; ++i) {
					result += tmp[i];
				}
			}
			// Log.i("test", result + " result.length: " + result.length());
		}
		return Mac;
	}

	public String callCmd(String cmd, String filter) {
		String result = "";
		String line = "";
		try {
			Process proc = Runtime.getRuntime().exec(cmd);
			InputStreamReader is = new InputStreamReader(proc.getInputStream());
			BufferedReader br = new BufferedReader(is);

			// 鎵ч敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹cmd閿熸枻鎷峰彧鍙栭敓鏂ゆ嫹閿熸枻鎷锋郴閿熸枻鎷烽敓绲漣lter閿熸枻鎷烽敓鏂ゆ嫹涓�敓鏂ゆ嫹
			while ((line = br.readLine()) != null
					&& line.contains(filter) == false) {
				// result += line;
				Log.i("test", "line: " + line);
			}

			result = line;
			Log.i("test", "result: " + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void execShell(String cmd) {
		try {
			// 鏉冮敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
			Process p = Runtime.getRuntime().exec("su");
			// 閿熸枻鎷峰彇閿熸枻鎷烽敓鏂ゆ嫹閿燂拷
			OutputStream outputStream = p.getOutputStream();
			DataOutputStream dataOutputStream = new DataOutputStream(
					outputStream);
			// 閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷峰啓閿熸枻鎷�
			dataOutputStream.writeBytes(cmd);
			// 閿熺粨浜ら敓鏂ゆ嫹閿熸枻鎷�
			dataOutputStream.flush();
			// 閿熸埅鎲嬫嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
			dataOutputStream.close();
			outputStream.close();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private void notifyCommand(String command, CommandBean bean,
			boolean firstStart) {

		Log.i(TAG, "before call notifyCommand");

		if (bean == null && !command.equals(COMMAND_STOP)) {
			return;
		}

		Log.i(TAG, "notifyCommand:" + command + ", isfirststart:" + firstStart);
		Log.i(TAG, "typ:" + bean.mMediaType + ", mTestOpen:" + mTestOpen);
		if ("audio".equals(bean.mMediaType) && !mTestOpen) {
			if (command.equals(COMMAND_PLAY)) {

				Log.i(TAG, "notifyCommand:" + "inside playing now "
						+ bean.mMediaType);

				if (ap != null) {
					ap.stop();
					ap = null;
				}

				Log.i(TAG, "notifyCommand:" + "After stop inseide now "
						+ bean.mMediaType);

				ap = new MulticastAudioPlayer(this);

				Log.i(TAG, "notifyCommand:" + "After new plaer inseide now "
						+ bean.mMediaType);

				if (bean.mMediaType == null || "".equals(bean.mMediaType)) {
					bean.mMediaType = "audio";
				}

				if (bean.mBitrate == null || "".equals(bean.mBitrate)
						|| Integer.parseInt(bean.mBitrate) <= 0) {
					bean.mBitrate = "320";
				}

				Log.i(TAG, "notifyCommand:" + "Call playing now "
						+ bean.mMediaType + bean.mBitrate);

				ap.play(bean.mUdpBroadcastAddress + "-" + bean.mMediaType + "/"
						+ bean.mBitrate);
			} else if (command.equals(COMMAND_STOP)) {

				Log.i(TAG, "notifyCommand:" + "Call stop now ");
				if (ap != null) {
					ap.stop();
					ap = null;
				}
				Log.i(TAG, "notifyCommand:" + "afer callter stop now ");
			}
			return;
		}

		if (bean.mMediaType == null || "".equals(bean.mMediaType)) {
			bean.mMediaType = "video";
		}

		if (bean.mBitrate == null || "".equals(bean.mBitrate)
				|| Integer.parseInt(bean.mBitrate) <= 0) {
			bean.mBitrate = "2000";
		}

		if (firstStart && !command.equals(COMMAND_STOP)) {
			Log.i(TAG, "notifyCommand:" + command + "start to play!");
			Intent intent = new Intent();
			intent.setClass(mContext, MulticastVideoPlayer.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.putExtra("address", bean.mUdpBroadcastAddress + "-"
					+ bean.mMediaType + "/" + bean.mBitrate);
			intent.putExtra("mediaType", bean.mMediaType);
			intent.putExtra("streamName", bean.mStreamName);
			intent.putExtra("bitRate", bean.mBitrate);
			startActivity(intent);
			return;
		}

		if (command != null) {

			Log.i(TAG, "notifyCommand:" + command + "stop the play what ever!");

			Intent i = new Intent();
			i.setAction(command);

			// if (bean == null) {
			// Log.e(TAG,
			// "there is no server and stream info, mustbe some error happened!");
			// return;
			// }

			// for command stop the bean can be null ,in sometimes such as
			// server been killed in background, the bean may be null.
			i.putExtra("address", bean == null ? "" : bean.mUdpBroadcastAddress);
			i.putExtra("mediaType", bean == null ? "" : bean.mMediaType);
			i.putExtra("streamName", bean == null ? "" : bean.mStreamName);
			i.putExtra("bitrate", bean == null ? "" : bean.mBitrate);
			sendBroadcast(i);
		}
	}

	private String getLocalIPAddress() throws SocketException {
		for (Enumeration<NetworkInterface> en = NetworkInterface
				.getNetworkInterfaces(); en.hasMoreElements();) {
			NetworkInterface intf = en.nextElement();
			for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr
					.hasMoreElements();) {
				InetAddress inetAddress = enumIpAddr.nextElement();
				if (!inetAddress.isLoopbackAddress()
						&& (inetAddress instanceof Inet4Address)) {
					return inetAddress.getHostAddress().toString();
				}
			}
		}
		return "null";
	}

	public String getIp() {

		WifiManager wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);

		if (!wifiManager.isWifiEnabled()) {
			wifiManager.setWifiEnabled(true);
		}
		WifiInfo wifiInfo = wifiManager.getConnectionInfo();
		int ipAddress = wifiInfo.getIpAddress();
		String ip = intToIp(ipAddress);
		return ip;
	}

	private String intToIp(int i) {

		return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF)
				+ "." + (i >> 24 & 0xFF);
	}

	private void serverCallBack(HubProxy hub, String error) {

		if (!isConnected) {
			return;
		}

		String errorCode = error;

		String message = "player send";

		List<String> args = new ArrayList<String>();

		String js = "";

		JSONArray jsa = new JSONArray();
		JSONObject jo = new JSONObject();
		try {
			jo.put("guidId", guidId);
			jo.put("errorCode", error);
			jo.put("message", message);
			jsa.put(0, jo);
			js = jsa.optString(0);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		args.add(js);
		if (conn != null) {
			args.add(conn.getConnectionId());
		}
		// args.add(errorCode);
		// args.add(message);
		// try {
		// args.add(getLocalIPAddress());
		// } catch (SocketException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		if (hub != null) {

			try {

				Log.d("laowei", "Server callback now.....invoke");
				hub.invoke("SendMessageToMgrServer", js, conn.getConnectionId())
						.get();
			} catch (Exception e) {

			}

		}

	}

	public class TimeThread extends Thread {
		public TimeThread() {
		}

		public void run() {
			try {

				Thread.sleep(1000);
				Message localMessage = new Message();
				localMessage.what = 1;
				handlerShowTime.sendMessage(localMessage);

			} catch (InterruptedException localInterruptedException) {
				localInterruptedException.printStackTrace();
			}
		}
	}

	public class downloadTask extends Thread {
		String fileName;
		String folderName;
		String urlStr;

		public downloadTask(String urlStr, String folderName, String fileName) {
			this.urlStr = urlStr;
			this.folderName = folderName;
			this.fileName = fileName;
		}

		public void run() {
			httpDownloadUtil = new HttpDownloadUtil();
			httpDownloadUtil.downFile(this.urlStr, this.folderName,
					this.fileName);
		}
	}
}
