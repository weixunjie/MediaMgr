package com.example.iot;

public interface iot_observable {
	public int  device_registered_callback(String  device_id,int port_number);
}
