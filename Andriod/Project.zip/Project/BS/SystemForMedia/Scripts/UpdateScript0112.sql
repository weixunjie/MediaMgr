alter table dbo.ScheduleTaskInfo add IsForAudio int
