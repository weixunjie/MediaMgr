/** Automatically generated file. DO NOT MODIFY */
package jld.com.jld.remotecontrol.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}