package com.datamodels;

import java.io.Serializable;

public class TaskInfo
  implements Serializable
{
  private String baseUrl;
  private String days;
  private String endTime;
  private String fileName;
  private String startTime;
  private String weeks;
  
  public String getBaseUrl()
  {
    return this.baseUrl;
  }
  
  public String getDays()
  {
    return this.days;
  }
  
  public String getEndTime()
  {
    return this.endTime;
  }
  
  public String getFileName()
  {
    return this.fileName;
  }
  
  public String getStartTime()
  {
    return this.startTime;
  }
  
  public String getWeeks()
  {
    return this.weeks;
  }
  
  public void setBaseUrl(String paramString)
  {
    this.baseUrl = paramString;
  }
  
  public void setDays(String paramString)
  {
    this.days = paramString;
  }
  
  public void setEndTime(String paramString)
  {
    this.endTime = paramString;
  }
  
  public void setFileName(String paramString)
  {
    this.fileName = paramString;
  }
  
  public void setStartTime(String paramString)
  {
    this.startTime = paramString;
  }
  
  public void setWeeks(String paramString)
  {
    this.weeks = paramString;
  }
}
