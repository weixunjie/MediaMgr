﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class VideoOperAndriodClientCommand : ComunicationBase
    {
        public VideoOperAndriodClientArg arg
        {
            get;
            set;
        }      

    }
}
