package com.example.mcu_func_test;



import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.os.Build;

import android.hardware.SerialManager;
import android.hardware.SerialPort;
import java.nio.ByteBuffer;
import java.io.IOException;

public class Set_ap_by_week extends Activity {

	private TimePicker  tpo;

	private TimePicker  tpc;
	private Button      bt;
	private EditText   et;
	private int open_hour,open_minute,close_hour,close_minute;
	String str;
	int []  value=new int[6];
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_set_ap_by_week);
		tpo=(TimePicker) findViewById(R.id.open_for_week);
		tpc=(TimePicker) findViewById(R.id.close_for_week);
		tpo.setIs24HourView(true);
		tpc.setIs24HourView(true);
		bt=(Button)findViewById(R.id.set_rtc_button_for_week);
		et=(EditText)findViewById(R.id.week);
		
		
bt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
			// TODO Auto-generated method stub
		
		
				
		     int week=et.getText().toString().charAt(0)-0x30;
         
				
		       //   Log.e("pengyong", "str="+str);
			
			open_hour=tpo.getCurrentHour();
			open_minute=tpo.getCurrentMinute();			
			close_hour=tpc.getCurrentHour();
			close_minute=tpc.getCurrentMinute();

	                int set_value[]={week,open_hour,open_minute,close_hour,close_minute};
	                Log.e("pengyong", "setvalue="+week+" "+open_hour+" "+open_minute+" "+close_hour+" "+close_minute);  

            	        //boolean	ret=MainActivity.mSerialManager.enable_onoff_by_week(set_value);
			boolean	ret=MainActivity.mSerialManager.set_onoff_by_week(set_value);

			if(ret)	
			{
				Log.e("pengyong","set ok");
			}
			else
			{

				Log.e("pengyong","set false");
			}
				
			}
		});
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.set_ap_by_week, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_set_ap_by_week,
					container, false);
			return rootView;
		}
	}

}
