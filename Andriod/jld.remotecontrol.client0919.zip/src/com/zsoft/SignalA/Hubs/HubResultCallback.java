package com.zsoft.SignalA.Hubs;

public class HubResultCallback {

}
