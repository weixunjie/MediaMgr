package com.model.commandreceiver;

import com.model.utils.Sharereference;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootCompletedReceiver extends BroadcastReceiver {
	public static final String TAG = "BroadcastReceiver";

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.i("BroadcastReceiver", "boot over start service");
		if (!Sharereference.getIsOneMoreTime(context, false)) {
			Sharereference.setPathAddr(context, "http://192.168.1.200/jld");
			Sharereference.setIsOneMoreTime(context, true);
		}
		context.startService(new Intent(context, CommandReceiver.class));
	}
}
