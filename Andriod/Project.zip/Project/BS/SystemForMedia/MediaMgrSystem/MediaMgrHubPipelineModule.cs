﻿using MediaMgrSystem.DataModels;
using Microsoft.AspNet.SignalR.Hubs;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;
using System.Xml;

namespace MediaMgrSystem
{


    public class MediaMgrHubPipelineModule : HubPipelineModule
    {

        public MediaMgrHubPipelineModule()
        {

            GlobalUtils.SingalConnectedClientsBLLIntance.RemoveAll();

        }

        //protected override void OnAfterReconnect(IHub hub)
        //{
        //    System.Diagnostics.Debug.WriteLine("Reconnectining->" + hub.Context.ConnectionId);
        //    lock (GlobalUtils.PublicObjectForLockConnected)
        //    {


        //        SingalConnectedClient sc = new SingalConnectedClient();
        //        SingalRClientConnectionType singalRClientConnectionType = SingalRClientConnectionType.PC;
        //        sc.ConnectionId = hub.Context.ConnectionId;

        //        string type = string.Empty;

        //        string strIdentify = string.Empty;


        //        if (hub.Context.QueryString["clientIdentify"] != null)
        //        {
        //            strIdentify = hub.Context.QueryString["clientIdentify"].ToString();
        //        }

        //        if (hub.Context.QueryString["clientType"] != null)
        //        {
        //            type = hub.Context.QueryString["clientType"].ToString().ToUpper();

        //            if (type == "ANDROID")
        //            {

        //                singalRClientConnectionType = SingalRClientConnectionType.ANDROID;



        //            }
        //            else if (type == "VIDEOSERVER")
        //            {
        //                singalRClientConnectionType = SingalRClientConnectionType.VEDIOSERVER;
        //                return;


        //            }

        //            else if (type == "ENCODERFORAUDIO")
        //            {

        //                singalRClientConnectionType = SingalRClientConnectionType.ENCODERAUDIODEVICE;


        //            }

        //            else if (type == "WINDOWSSERVICE")
        //            {

        //                singalRClientConnectionType = SingalRClientConnectionType.WINDOWSSERVICE;
        //                return;

        //            }
        //            else if (type == "REMOTECONTORLDEVICE")
        //            {
        //                singalRClientConnectionType = SingalRClientConnectionType.REMOTECONTORLDEVICE;

        //            }

        //        }

        //        sc.ConnectionType = singalRClientConnectionType;

        //        sc.ConnectionId = hub.Context.ConnectionId;

        //        sc.ConnectionIdentify = strIdentify;
        //        string extingCid = GlobalUtils.SingalConnectedClientsBLLIntance.GetSingalConnectedClientsByIndetify(strIdentify, sc.ConnectionType.ToString());

        //        if (!string.IsNullOrEmpty(extingCid))
        //        {
        //            GlobalUtils.DeleteSingalConnectedClientByConnectIds(extingCid);
        //        }

        //        if (sc.ConnectionType == SingalRClientConnectionType.REMOTECONTORLDEVICE)
        //        {
        //            SendRefreshRemoteControlDeviceNotice(hub);
        //        }

        //        if (sc.ConnectionType == SingalRClientConnectionType.ANDROID)
        //        {
        //            SendRefreshAudioDeviceNotice(hub);
        //        }

        //        if (!string.IsNullOrEmpty(sc.ConnectionId) && !string.IsNullOrEmpty(sc.ConnectionIdentify))
        //        {


        //            GlobalUtils.AddConnection(sc);
        //        }
        //    }

        //}

        protected override void OnAfterConnect(IHub hub)
        {
            System.Diagnostics.Debug.WriteLine("Connected->" + hub.Context.ConnectionId);
            ProcessConnect(hub);
        }

        protected override void OnAfterReconnect(IHub hub)
        {

            ProcessConnect(hub);


        }

        private void ProcessConnect(IHub hub)
        {
            lock (GlobalUtils.PublicObjectForLockConnected)
            {
                try
                {

                    SingalConnectedClient sc = new SingalConnectedClient();
                    SingalRClientConnectionType singalRClientConnectionType = SingalRClientConnectionType.PC;
                    sc.ConnectionId = hub.Context.ConnectionId;

                    string type = string.Empty;

                    string strIdentify = string.Empty;


                    string strVersion = string.Empty;

                    if (hub.Context.QueryString["clientIdentify"] != null)
                    {
                        strIdentify = hub.Context.QueryString["clientIdentify"].ToString();
                    }




                    String macAddress = string.Empty;
                    if (hub.Context.QueryString["macAddress"] != null)
                    {
                        macAddress = hub.Context.QueryString["macAddress"];

                    }

                    if (hub.Context.QueryString["clientVersion"] != null)
                    {
                        strVersion = hub.Context.QueryString["clientVersion"];

                    }


                    if (hub.Context.QueryString["clientType"] != null)
                    {
                        type = hub.Context.QueryString["clientType"].ToString().ToUpper();

                        if (type == "ANDROID")
                        {

                            singalRClientConnectionType = SingalRClientConnectionType.ANDROID;

                            UpgradeInfo ui = GlobalUtils.UpgradeConfigBLLInstance.GetUpgradeConfig("1");

                            SendSyncTimeAndVersionCheck(ui, hub, singalRClientConnectionType);

                            object[] objs = new object[2];

                            objs[0] = hub;
                            objs[1] = strIdentify;

                            new Thread(SendDoingBusinessToClient).Start(objs);


                            objs = new object[2];

                            objs[0] = hub;
                            objs[1] = strIdentify;

                            new Thread(SyncRingShedule).Start(objs);


                        }
                        else if (type == "VIDEOSERVER")
                        {
                            singalRClientConnectionType = SingalRClientConnectionType.VEDIOSERVER;

                            hub.Clients.Clients(GlobalUtils.GetAllPCDeviceConnectionIds()).sendResultBrowserClient("视频服务器连接成功", "20");

                        }

                        else if (type == "ENCODERFORAUDIO")
                        {

                            singalRClientConnectionType = SingalRClientConnectionType.ENCODERAUDIODEVICE;

                            EncoderAudioSendGroupsInfoCommand cmdSyncGrouOps = new EncoderAudioSendGroupsInfoCommand();
                            cmdSyncGrouOps.commandType = CommandTypeEnum.ENCODERSENDGROUPSINFO;
                            cmdSyncGrouOps.guidId = Guid.NewGuid().ToString();
                            cmdSyncGrouOps.groups = new List<EncoderSyncGroupInfo>();

                            EncoderAudioInfo ei = GlobalUtils.EncoderBLLInstance.GetEncoderByClientIdentify(strIdentify);

                            if (ei == null)
                            {
                                EncoderAudioInfo eif = new EncoderAudioInfo();
                                eif.BaudRate = "1100";
                                eif.ClientIdentify = strIdentify;
                                eif.EncoderName = strIdentify;
                                eif.Priority = "1";
                                GlobalUtils.EncoderBLLInstance.AddEncoder(eif);

                            }
                            //  GlobalUtils.VideoEncoderQueues
                            List<GroupInfo> gi = GlobalUtils.GroupBLLInstance.GetAllGroupsByBusinessType(BusinessType.AUDITBROADCAST);

                            foreach (var g in gi)
                            {

                                if (g.Devices != null && g.Devices.Count > 0)
                                {
                                    cmdSyncGrouOps.groups.Add(new EncoderSyncGroupInfo { groupId = g.GroupId, groupName = g.GroupName });
                                }



                            }

                            hub.Clients.Client(hub.Context.ConnectionId).sendAudioEncoderCommandToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmdSyncGrouOps));



                            EncoderAudioSendDevsInfoCommand cmdSyncDev = new EncoderAudioSendDevsInfoCommand();
                            cmdSyncDev.commandType = CommandTypeEnum.ENCODERSENDDEVINFO;
                            cmdSyncDev.guidId = Guid.NewGuid().ToString();
                            cmdSyncDev.devs = new List<EncoderSyncDevInfo>();


                            foreach (var g in gi)
                            {
                                if (g.Devices != null && g.Devices.Count > 0)
                                {
                                    foreach (var di in g.Devices)
                                    {
                                        cmdSyncDev.devs.Add(new EncoderSyncDevInfo { devId = di.DeviceId, devName = di.DeviceName });
                                    }
                                }
                            }

                            hub.Clients.Client(hub.Context.ConnectionId).sendAudioEncoderCommandToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmdSyncDev));


                        }

                        else if (type == "WINDOWSSERVICE")
                        {
                            singalRClientConnectionType = SingalRClientConnectionType.WINDOWSSERVICE;

                        }
                        else if (type == "REMOTECONTORLDEVICE")
                        {
                            singalRClientConnectionType = SingalRClientConnectionType.REMOTECONTORLDEVICE;

                            UpgradeInfo ui = GlobalUtils.UpgradeConfigBLLInstance.GetUpgradeConfig("2");

                            SendSyncTimeAndVersionCheck(ui, hub, singalRClientConnectionType);
                        }

                    }



                    sc.ConnectionType = singalRClientConnectionType;



                    if (singalRClientConnectionType == SingalRClientConnectionType.PC)
                    {
                        strIdentify = Guid.NewGuid().ToString();

                    }
                    sc.ConnectionIdentify = strIdentify;

                    if (sc.ConnectionType == SingalRClientConnectionType.VEDIOSERVER)
                    {

                        string extingViedoServerCid = GlobalUtils.VideoServerConnectionId;

                        if (!string.IsNullOrEmpty(extingViedoServerCid))
                        {
                            GlobalUtils.DeleteSingalConnectedClientByConnectIds(extingViedoServerCid);

                        }

                        GlobalUtils.AddLogs(hub.Clients, "系统提示", "视频服务器已连接");


                    }

                    if (sc.ConnectionType == SingalRClientConnectionType.WINDOWSSERVICE)
                    {

                        string extingId = GlobalUtils.GetWindowsServiceConnectionIds();

                        if (!string.IsNullOrEmpty(extingId))
                        {
                            GlobalUtils.DeleteSingalConnectedClientByConnectIds(extingId);

                        }

                        GlobalUtils.AddLogs(hub.Clients, "系统提示", "后台计划服务已连接");



                    }

                    bool isExstingDevice = true;
                    string idExstingDev = string.Empty;
                    if (sc.ConnectionType == SingalRClientConnectionType.ANDROID ||
                        sc.ConnectionType == SingalRClientConnectionType.REMOTECONTORLDEVICE)
                    {

                        List<DeviceInfo> dis = GlobalUtils.DeviceBLLInstance.GetADevicesByIPAddress(sc.ConnectionIdentify);

                        if (dis != null && dis.Count > 0)
                        {
                            idExstingDev = dis[0].DeviceId;

                            GlobalUtils.DeviceBLLInstance.UpdateDeviceVersion(idExstingDev, strVersion);
                        }
                        else
                        {

                            isExstingDevice = false;
                            DeviceInfo di = new DeviceInfo();
                            di.DeviceIpAddress = sc.ConnectionIdentify;
                            di.DeviceName = sc.ConnectionIdentify;
                            di.GroupId = "-1";
                            di.MacAddress = macAddress;
                            di.DeviceVersion = strVersion;
                            di.UsedToAudioBroandcast = true;
                            di.UsedToVideoOnline = false;

                            di.UsedToRemoteControl = sc.ConnectionType == SingalRClientConnectionType.REMOTECONTORLDEVICE;

                            int re = 1;
                            if (!string.IsNullOrWhiteSpace(strIdentify))
                            {

                                re = GlobalUtils.DeviceBLLInstance.AddDevice(di);

                            }

                            if (re < 0)
                            {
                                if (re == -10)
                                {
                                    GlobalUtils.AddLogs(hub.Clients, "系统提示", "音频终端已经达到最大数量");
                                }
                                else if (re == -11)
                                {

                                    GlobalUtils.AddLogs(hub.Clients, "系统提示", "视频终端已经达到最大数量");
                                }
                                else if (re == -12)
                                {
                                    GlobalUtils.AddLogs(hub.Clients, "系统提示", "物联终端已经达到最大数量");
                                }


                                di.UsedToAudioBroandcast = false;
                                GlobalUtils.DeviceBLLInstance.AddDevice(di);
                            }


                        }


                        string extingCid = GlobalUtils.SingalConnectedClientsBLLIntance.GetSingalConnectedClientsByIndetify(strIdentify, sc.ConnectionType.ToString());

                        if (!string.IsNullOrEmpty(extingCid))
                        {
                            GlobalUtils.DeleteSingalConnectedClientByConnectIds(extingCid);
                        }

                        if (sc.ConnectionType == SingalRClientConnectionType.REMOTECONTORLDEVICE)
                        {
                            SendRefreshRemoteControlDeviceNotice(hub);
                        }

                        if (sc.ConnectionType == SingalRClientConnectionType.ANDROID)
                        {
                            if (isExstingDevice)
                            {
                                GlobalUtils.sendDeviceOnlineOfflineStatus(hub.Clients, idExstingDev, "ic_image_device");
                            }
                            else
                            {
                                SendRefreshAudioDeviceNotice(hub);
                            }
                        }



                    }

                    if (sc.ConnectionType == SingalRClientConnectionType.ENCODERAUDIODEVICE)
                    {
                        SendRefreshCallerEncoderDeviceMessge(hub);



                        //Connect again, if running, stop it.
                        object[] objes = new object[2];
                        objes[0] = strIdentify;
                        objes[1] = hub.Clients;
                        new Thread(ProcesStopLogs).Start(objes);

                    }


                    GlobalUtils.AddConnection(sc);

                    string str = "Someone Connected: Connected Id" + hub.Context.ConnectionId;
                    System.Diagnostics.Debug.WriteLine(str + "Date Time->" + DateTime.Now.ToString("HH:mm:ss"));

                    if (sc.ConnectionType != SingalRClientConnectionType.PC)
                    {
                        GlobalUtils.AddConnectionTestLogs(sc.ConnectionType.ToString(), "设备：(" + sc.ConnectionIdentify + ")已连接");
                    }


                    GlobalUtils.WriteDebugLogs(str);

                    if (sc.ConnectionType == SingalRClientConnectionType.REMOTECONTORLDEVICE)
                    {
                        ComunicationBase cmd = new ComunicationBase();

                        cmd.guidId = Guid.NewGuid().ToString();
                        cmd.commandType = CommandTypeEnum.REMOTECONTRL_COMMAND_REQUEST_STATE;

                        hub.Clients.Client(hub.Context.ConnectionId).sendRemoteControlToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmd));
                    }



                }

                catch (Exception ex)
                {
                    try
                    {

                        GlobalUtils.AddLogs(null, "Exception", ex.StackTrace);

                    }
                    catch { }

                }
            }
        }

        private void SendSyncTimeAndVersionCheck(UpgradeInfo ui, IHub hub, SingalRClientConnectionType type)
        {

            SyncTimeCommand cmd = new SyncTimeCommand();

            cmd.guidId = Guid.NewGuid().ToString();
            cmd.commandType = CommandTypeEnum.SYNCTIME;
            cmd.arg = new SyncTimeCommandArg();

            cmd.arg.upgradeUrl = ui.UpgardeUrl;
            cmd.arg.upgradeVer = String.IsNullOrEmpty(ui.VersionId) ? "1" : ui.VersionId;
            cmd.arg.serverNowTime = ((DateTime.UtcNow.Ticks - 621355968000000000) / 10000).ToString();

            try
            {
                string fileBasePath = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["filePath"].ToString();

                string xmlFilePath = fileBasePath + @"\OTA\OTA.xml";
                XmlDocument doc = new XmlDocument();
                doc.Load(xmlFilePath);

                XmlNodeList osVersionNodeList = doc.SelectNodes("/Firmware/OsVersion");

                XmlNodeList urlDmUrl = doc.SelectNodes("/Firmware/DownloadUrl");

                XmlNodeList urlMd5Url = doc.SelectNodes("/Firmware/MD5");

                string strOsVersion = osVersionNodeList[0].InnerText;

                string strDMList = urlDmUrl[0].InnerText;

                string strMD5 = urlMd5Url[0].InnerText;

                cmd.arg.otaNewVersion = strOsVersion;

                cmd.arg.otaMd5String = strMD5;

                cmd.arg.otaUrl = strDMList;
            }
            catch (Exception ex)
            {
            }

            if (type == SingalRClientConnectionType.ANDROID)
            {
                hub.Clients.Client(hub.Context.ConnectionId).sendMessageToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmd));
            }
            else if (type == SingalRClientConnectionType.REMOTECONTORLDEVICE)
            {
                hub.Clients.Client(hub.Context.ConnectionId).sendRemoteControlToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmd));

            }
        }
        private void SyncRingShedule(object obj)
        {
            try
            {
                object[] objs = obj as object[];

                IHub hub = objs[0] as IHub;
                string ipAddress = objs[1].ToString();

                List<DeviceInfo> dis = GlobalUtils.DeviceBLLInstance.GetADevicesByIPAddress(ipAddress);

                if (dis != null && dis.Count > 0)
                {
                    string groupId = dis[0].GroupId;


                    List<GroupInfo> groups = GlobalUtils.GroupBLLInstance.GetGroupById(groupId);
                    {
                        if (groups != null && groups.Count > 0)
                        {
                            string cid = groups[0].ChannelId;

                            if (!string.IsNullOrEmpty(cid))
                            {
                                int cOut = 0;

                                if (int.TryParse(cid, out cOut))
                                {
                                    ChannelInfo channel = GlobalUtils.ChannelBLLInstance.GetChannelById(cid);

                                    if (channel != null)
                                    {
                                        List<ScheduleTaskInfo> tasks = GlobalUtils.ScheduleBLLInstance.GetAllRingScheduleTaksByScheduleId(channel.ScheduelId);

                                        EncoderAudioSendScheduleTaskInfoCommand cmd = new EncoderAudioSendScheduleTaskInfoCommand();
                                        cmd.commandType = CommandTypeEnum.SYNCRINGSCHEDULE;

                                        cmd.guidId = Guid.NewGuid().ToString();

                                        cmd.tasks = new List<EncoderSyncScheduleTaskInfo>();

                                        // string baseUrl = HttpContext.Current.Request.Url.AbsoluteUri.Substring(0, HttpContext.Current.Request.Url.AbsoluteUri.IndexOf(HttpContext.Current.Request.RawUrl));

                                        //string fileUrl = 

                                        foreach (var t in tasks)
                                        {

                                            if (t.IsRing == "1")
                                            {
                                                EncoderSyncScheduleTaskInfo st = new EncoderSyncScheduleTaskInfo();
                                                // st.baseUrl = baseUrl + "/FileSource/";

                                                if (!string.IsNullOrWhiteSpace(t.ScheduleTaskProgarmId))
                                                {
                                                    List<ProgramInfo> pis = GlobalUtils.ProgramBLLInstance.GetProgramById(t.ScheduleTaskProgarmId, true);
                                                    if (pis != null && pis.Count > 0)
                                                    {
                                                        st.fileName = pis[0].MappingFiles[0].FileName;
                                                        st.filePath = UrlEncode(pis[0].MappingFiles[0].FileRelatePath);
                                                    }
                                                }

                                                st.startTime = t.ScheduleTaskStartTime;
                                                st.endTime = t.ScheduleTaskEndTime;
                                                st.days = t.StrSpecialDaysToWeeks;
                                                st.weeks = t.StrWeeks;


                                                if (!string.IsNullOrWhiteSpace(st.fileName))
                                                {
                                                    cmd.tasks.Add(st);
                                                }
                                            }


                                        }



                                        hub.Clients.Client(hub.Context.ConnectionId).sendMessageToClient(Newtonsoft.Json.JsonConvert.SerializeObject(cmd));

                                    }
                                }

                            }
                        }
                    }
                }
            }


            catch (Exception ex)
            {
                try
                {

                    GlobalUtils.AddLogs(null, "Exception", ex.StackTrace);

                }
                catch { }

            }


        }

        public string UrlEncode(string str)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                byte[] byStr = System.Text.Encoding.UTF8.GetBytes(str); //默认是System.Text.Encoding.Default.GetBytes(str)
                for (int i = 0; i < byStr.Length; i++)
                {
                    sb.Append(@"%" + Convert.ToString(byStr[i], 16));
                }



                return (sb.ToString());
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        private void SendDoingBusinessToClient(object obj)
        {

            object[] objs = obj as object[];

            IHub hub = objs[0] as IHub;
            string ipAddress = objs[1].ToString();
            List<DeviceInfo> dis = GlobalUtils.DeviceBLLInstance.GetADevicesByIPAddress(ipAddress);

            if (dis != null && dis.Count > 0)
            {
                string groupId = dis[0].GroupId;
                foreach (var g in GlobalUtils.GlobalGroupBusinessStatus)
                {


                    if (!string.IsNullOrWhiteSpace(g.GroupId) && g.GroupId.Equals(groupId))
                    {

                        if (g.TypeRunning == BusinessTypeForGroup.ManualScheduleTask)
                        {
                            if ((g.BusType == BusinessType.AUDITBROADCAST && dis[0].UsedToAudioBroandcast) ||
                                (g.BusType == BusinessType.VIDEOONLINE && dis[0].UsedToVideoOnline))
                            {

                                string jsonDataToClient = Newtonsoft.Json.JsonConvert.SerializeObject(g.BaseOperAndriodClientCommandData);
                                hub.Clients.Client(hub.Context.ConnectionId).sendMessageToClient(jsonDataToClient);
                            }
                        }

                        else if (g.TypeRunning == BusinessTypeForGroup.VideoEncoder && dis[0].UsedToVideoOnline)
                        {
                            string jsonDataToClient = Newtonsoft.Json.JsonConvert.SerializeObject(g.EncoderVideoOperCommandData);

                            hub.Clients.Client(hub.Context.ConnectionId).sendMessageToClient(jsonDataToClient);
                        }

                        if (g.TypeRunning == BusinessTypeForGroup.AudioEncoder && dis[0].UsedToAudioBroandcast)
                        {
                            string jsonDataToClient = Newtonsoft.Json.JsonConvert.SerializeObject(g.CallerCommandData);

                            hub.Clients.Client(hub.Context.ConnectionId).sendMessageToClient(jsonDataToClient);
                        }

                    }
                }

            }


        }



        private void SendRefreshAudioDeviceNotice(IHub hub)
        {

            List<string> ids = GlobalUtils.GetAllPCDeviceConnectionIds();

            hub.Clients.Clients(ids).sendRefreshAudioDeviceMessge();
        }



        private void SendRefreshCallerEncoderDeviceMessge(IHub hub)
        {

            List<string> ids = GlobalUtils.GetAllPCDeviceConnectionIds();

            hub.Clients.Clients(ids).sendRefreshCallerEncoderDeviceMessge();
        }


        private void SendRefreshRemoteControlDeviceNotice(IHub hub)
        {

            List<string> ids = GlobalUtils.GetAllPCDeviceConnectionIds();

            hub.Clients.Clients(ids).sendRefreshRemoteControlDeviceMessge();
        }


        protected override void OnAfterDisconnect(IHub hub)
        {
            try
            {
                DateTime dt = DateTime.UtcNow;

                SingalRClientConnectionType disConnectType = SingalRClientConnectionType.PC;

                string str = "DISConnected: Connected Id" + hub.Context.ConnectionId;
                System.Diagnostics.Debug.WriteLine(str);

                GlobalUtils.WriteDebugLogs(str);
                if (hub.Context.ConnectionId == GlobalUtils.VideoServerConnectionId)
                {
                    disConnectType = SingalRClientConnectionType.VEDIOSERVER;
                    // SendRefreshAudioDeviceNotice(hub);
                    GlobalUtils.AddLogs(hub.Clients, "系统异常", "视频服务器断开连接");
                    GlobalUtils.AddConnectionTestLogs("系统异常", "视频服务器断开连接");

                }

                if (hub.Context.ConnectionId == GlobalUtils.WindowsServiceConnectionId)
                {
                    disConnectType = SingalRClientConnectionType.WINDOWSSERVICE;
                    //SendRefreshAudioDeviceNotice(hub);
                    GlobalUtils.AddLogs(hub.Clients, "系统异常", "后台计划服务断开连接");
                    GlobalUtils.AddConnectionTestLogs("系统异常", "后台计划服务断开连接");
                }
                string strOutIpAddres = "";
                if (GlobalUtils.CheckIfConnectionIdIsAndriod(hub.Context.ConnectionId, out strOutIpAddres))
                {
                    disConnectType = SingalRClientConnectionType.ANDROID;

                    List<DeviceInfo> dvs = GlobalUtils.DeviceBLLInstance.GetADevicesByIPAddress(strOutIpAddres);

                    if (dvs != null && dvs.Count > 0)
                    {
                        GlobalUtils.sendDeviceOnlineOfflineStatus(hub.Clients, dvs[0].DeviceId, "ic_image_device_offline");
                    }


                    // SendRefreshAudioDeviceNotice(hub);


                }

                if (GlobalUtils.CheckIfConnectionIdIsAudioEncoder(hub.Context.ConnectionId))
                {
                    disConnectType = SingalRClientConnectionType.ENCODERAUDIODEVICE;
                    //  SendRefreshAudioDeviceNotice(hub);


                }

                if (GlobalUtils.CheckIfConnectionIdIsRemoteControlDevice(hub.Context.ConnectionId))
                {
                    disConnectType = SingalRClientConnectionType.REMOTECONTORLDEVICE;
                    SendRefreshRemoteControlDeviceNotice(hub);
                }


                if (GlobalUtils.CheckIfConnectionIdIsAudioEncoder(hub.Context.ConnectionId))
                {
                    SendRefreshCallerEncoderDeviceMessge(hub);
                }


                String ci = GlobalUtils.GetIdentifyByConectionId(hub.Context.ConnectionId);


                if (disConnectType == SingalRClientConnectionType.ENCODERAUDIODEVICE)
                {

                    object[] objes = new object[2];
                    objes[0] = ci;
                    objes[1] = hub.Clients;
                    new Thread(ProcesStopLogs).Start(objes);
                }


                if (disConnectType != SingalRClientConnectionType.PC)
                {



                    GlobalUtils.AddConnectionTestLogs(disConnectType.ToString(), "设备：(" + ci + ")断开连接");
                }


                GlobalUtils.DeleteSingalConnectedClientByConnectIds(hub.Context.ConnectionId);

            }
            catch (Exception ex)
            {
                try
                {

                    GlobalUtils.AddLogs(null, "Exception", ex.StackTrace);

                }
                catch { }

            }


        }
        private void ProcesStopLogs(object cbObj)
        {
            try
            {
                // System.Diagnostics.Debug.WriteLine( "Process stop now" + DateTime.Now.ToString("HH:mm:ss"));

                object[] ojbs = cbObj as object[];

                string ci = ojbs[0].ToString();

                System.Diagnostics.Debug.WriteLine("Process stop now" + ci + DateTime.Now.ToString("HH:mm:ss"));
                IHubCallerConnectionContext clients = (IHubCallerConnectionContext)ojbs[1];

                if (!string.IsNullOrEmpty(ci))
                {
                    RunningEncoder re = GlobalUtils.EncoderAudioRunningClientsBLLInstance.CheckIfEncoderRunning(ci);
                    if (re != null && !string.IsNullOrEmpty(re.ClientIdentify))
                    {

                        CallerEncoderControlLogic.SendEncoderAudioCloseCommand(clients, ci);
                    }
                }
            }
            catch (Exception ex)
            {
                try
                {
                    GlobalUtils.AddLogs(null, "Exception->Stop Cllaer", ex.StackTrace);
                }
                catch (Exception ex1)
                { }
            }
        }

        protected override object OnAfterIncoming(object result, IHubIncomingInvokerContext context)
        {
            return base.OnAfterIncoming(result, context);
        }

    }
}

