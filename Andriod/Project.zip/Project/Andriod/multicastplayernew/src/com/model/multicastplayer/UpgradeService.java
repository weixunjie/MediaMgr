package com.model.multicastplayer;

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.os.RecoverySystem;
import android.os.RecoverySystem.ProgressListener;
import android.util.Log;

import com.model.utils.MD5;
import com.model.utils.Sharereference;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;

/**
 * ��ⰲװ�����ļ���������
 * 
 * @author G.Y.Y
 * 
 */

public class UpgradeService extends Service {

	/** ��׿ϵͳ������ **/
	DownloadManager manager;

	/** ����������Ĺ㲥 **/
	DownloadCompleteReceiver receiver;

	String md5String = "";

	/** ��ʼ�������� **/
	private void initDownManager(String urlToDownload, boolean paramBoolean) {

		// manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
		//
		// receiver = new DownloadCompleteReceiver();
		//
		// Log.d("laowei", "Begin to downlaod files at " + urlToDownload);
		// DownloadManager.Request down = new DownloadManager.Request(
		// Uri.parse(urlToDownload));
		//
		// // down.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE
		// // | DownloadManager.Request.NETWORK_WIFI);
		//
		// // down.setNotificationVisibility(Request.VISIBILITY_VISIBLE);
		//
		// // down.setVisibleInDownloadsUi(true);
		//
		// //
		// Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).mkdir()
		//
		// // down.setDestinationInExternalFilesDir(this,
		// // Environment.DIRECTORY_DOWNLOADS, "MediaPlayer.apk");
		//
		// Log.d("laowei", "To Queuee Now ............... ");
		// // ����������������
		// manager.enqueue(down);
		//
		// // ע�����ع㲥
		// registerReceiver(receiver, new IntentFilter(
		// DownloadManager.ACTION_DOWNLOAD_COMPLETE));

		this.manager = ((DownloadManager) getSystemService("download"));
		this.receiver = new DownloadCompleteReceiver();
		Log.d("laowei", "Begin to downlaod files at " + urlToDownload);
		DownloadManager.Request localRequest = new DownloadManager.Request(
				Uri.parse(urlToDownload));
		if (paramBoolean) {
			localRequest.setDestinationInExternalPublicDir(
					Environment.DIRECTORY_DCIM, "updateOTA.zip");
			File localFile = new File("mnt/sdcard/DCIM/updateOTA.zip");
			if ((localFile.exists()) && (localFile.isFile())) {
				localFile.delete();
			}
		}
		Log.d("laowei", "To Queuee Now ............... ");
		this.manager.enqueue(localRequest);
		Sharereference.setIsDownloading(this.mContext, "1");
		registerReceiver(this.receiver, new IntentFilter(
				"android.intent.action.DOWNLOAD_COMPLETE"));
	}

	private Context mContext;

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		// super.onStart(intent, startId);
		// mContext = this;
		//
		// initDownManager(intent.getStringExtra("upgradeUrl"));

		// initDownManager("http://192.168.1.101/MediaMgrDemo/mp.apk");

		super.onStart(intent, startId);
		this.mContext = this;
		if (!Sharereference.getIsDownloading(this.mContext, "2").equals("1")) {
			this.md5String = intent.getStringExtra("md5String");
			initDownManager(intent.getStringExtra("upgradeUrl"),
					intent.getBooleanExtra("isOTA", false));
		}
	}

	@Override
	public IBinder onBind(Intent intent) {

		return null;
	}

	@Override
	public void onDestroy() {

		// ע�����ع㲥
		if (receiver != null)
			unregisterReceiver(receiver);

		super.onDestroy();
	}

	// ����������ɺ��intent
	class DownloadCompleteReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			// �ж��Ƿ�������ɵĹ㲥
			if (intent.getAction().equals(
					DownloadManager.ACTION_DOWNLOAD_COMPLETE)) {

				// ��ȡ���ص��ļ�id
				long downId = intent.getLongExtra(
						DownloadManager.EXTRA_DOWNLOAD_ID, -1);

				Query myDownloadQuery = new Query();
				myDownloadQuery.setFilterById(downId);

				Log.d("laowei", "Donwload complete ");

				Cursor myDownload = manager.query(myDownloadQuery);
				if (myDownload.moveToFirst()) {
					int fileNameIdx = myDownload
							.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME);

					String strFilename = myDownload.getString(fileNameIdx);

					Log.e("OTA", "the donwload file is" + strFilename);

					File localFile = null;

					if ((strFilename != null) && (strFilename.length() > 0)) {
						int i = strFilename.lastIndexOf('.');
						if ((i > -1) && (i < -1 + strFilename.length())) {
							if (strFilename.substring(i + 1).toUpperCase()
									.equals("ZIP")) {

								Log.e("OTA",
										"the donwload file is zip now......");
								String strMd5 = MD5.md5sum(strFilename);
								Log.e("OTA", "File Md5:" + strMd5
										+ ", and server md5String:"
										+ UpgradeService.this.md5String);
								if (strMd5.toUpperCase().trim()
										.equals(md5String.toUpperCase().trim())) {
									Log.e("OTA", "md5 macth.........");
									localFile = new File(strFilename);
								}

								try {
									try {
										RecoverySystem
												.verifyPackage(
														localFile,
														new RecoverySystem.ProgressListener() {
															public void onProgress(
																	int paramAnonymousInt) {
															}
														}, null);
									} catch (GeneralSecurityException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}

									Log.e("OTA",
											"verifyPackage is completed and it ok");
									Log.e("OTA", "It will install package");
								} catch (IOException localIOException2) {

									try {
										RecoverySystem.installPackage(
												UpgradeService.this.mContext,
												localFile);
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}

								}
							} else

							{
								// �Զ���װapk
								installAPK(strFilename);
								UpgradeService.this.stopSelf();
							}
						}
					}

					// ֹͣ���񲢹رչ㲥
					// UpgradeService.this.stopSelf();
				}

			}
		}

		/**
		 * ��װapk�ļ�
		 */
		private void installAPK(String apk) {

			Log.d("laowei", "url " + apk.toString());

			Intent mIntent = new Intent();
			ComponentName comp = new ComponentName(
					"com.example.jld.base.devoperation",
					"com.example.jld.base.devoperation.MainActivity");
			mIntent.setComponent(comp);
			mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			mIntent.setAction("android.intent.action.VIEW");
			mContext.startActivity(mIntent);
			Log.d("laowei",
					"open listner now->com.example.jld.base.devoperation.MainActivity");
			installSlient(mContext, apk);

		}

		/**
		 * install slient
		 * 
		 * @param context
		 * @param filePath
		 * @return 0 means normal, 1 means file not exist, 2 means other
		 *         exception error
		 */
		private int installSlient(Context context, String filePath) {
			File file = new File(filePath);
			if (filePath == null || filePath.length() == 0
					|| (file = new File(filePath)) == null
					|| file.length() <= 0 || !file.exists() || !file.isFile()) {
				return 1;
			}

			Log.d("laowei", "url " + filePath.toString());
			String[] args = { "pm", "install", "-r", filePath };
			ProcessBuilder processBuilder = new ProcessBuilder(args);

			Process process = null;
			BufferedReader successResult = null;
			BufferedReader errorResult = null;
			StringBuilder successMsg = new StringBuilder();
			StringBuilder errorMsg = new StringBuilder();
			int result;
			try {
				process = processBuilder.start();
				successResult = new BufferedReader(new InputStreamReader(
						process.getInputStream()));
				errorResult = new BufferedReader(new InputStreamReader(
						process.getErrorStream()));
				String s;

				while ((s = successResult.readLine()) != null) {
					successMsg.append(s);
				}

				while ((s = errorResult.readLine()) != null) {
					errorMsg.append(s);
				}
			} catch (IOException e) {
				e.printStackTrace();
				result = 2;
			} catch (Exception e) {
				e.printStackTrace();
				result = 2;
			} finally {
				try {
					if (successResult != null) {
						successResult.close();
					}
					if (errorResult != null) {
						errorResult.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (process != null) {
					process.destroy();
				}
			}

			// TODO should add memory is not enough here
			if (successMsg.toString().contains("Success")
					|| successMsg.toString().contains("success")) {
				result = 0;

			} else {
				result = 2;
			}

			return result;
		}

	}
}