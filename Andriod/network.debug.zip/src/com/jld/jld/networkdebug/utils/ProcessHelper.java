package com.jld.jld.networkdebug.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import microsoft.aspnet.signalr.client.hubs.HubConnection;
import microsoft.aspnet.signalr.client.hubs.HubProxy;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class ProcessHelper {

	public static HubProxy GlobalHub = null;
	public static String RequestGuidId = "";
	public static boolean IsSigalConncted = false;
	public static boolean IsReqeustToOpen = false;

	public static HubConnection GlobalConnection = null;

	public static void startEncoder(String baudRate, String udpBroadcastAddress) {
		// Todo by Wang XU

	}

	public static void stopEncoder() {
		// Todo by Wang XU

	}

	public static String getLocalIPAddress() throws SocketException {
		for (Enumeration<NetworkInterface> en = NetworkInterface
				.getNetworkInterfaces(); en.hasMoreElements();) {
			NetworkInterface intf = en.nextElement();
			for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr
					.hasMoreElements();) {
				InetAddress inetAddress = enumIpAddr.nextElement();
				if (!inetAddress.isLoopbackAddress()
						&& (inetAddress instanceof Inet4Address)) {
					return inetAddress.getHostAddress().toString();
				}
			}
		}
		return "null";
	}

	public static void processUIRequest(boolean isOpen, String groupIds) {

		List<String> args = new ArrayList<String>();

		String js = "";

		UUID uuid = UUID.randomUUID();

		JSONArray jsa = new JSONArray();
		JSONObject jo = new JSONObject();
		try {
			jo.put("guidId", uuid.toString());
			jo.put("groupIds", groupIds);
			try {
				jo.put("clientIdentify", getLocalIPAddress());
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isOpen) {
				jo.put("commandType", "402");

			} else {
				jo.put("commandType", "403");
			}
			
			jsa.put(jo);
			RequestGuidId = uuid.toString();
			IsReqeustToOpen = isOpen;
			js = jsa.optString(0);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		args.add(js);
		if (GlobalConnection != null) {
			args.add(GlobalConnection.getConnectionId());
		}

		if (GlobalHub != null) {
			try {
				GlobalHub.invoke("SendEncoderAudioControlToMgrServer", js,
						GlobalConnection.getConnectionId()).get();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
	
	public static void setTimeValue(Context context, String name,String value) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"sss", Context.MODE_MULTI_PROCESS);
		Editor editor = sharedPreferences.edit();
		editor.putString(name, value);
		editor.commit();
	}
	
	public static String getTimeValue(Context context, String name) {
		String add = "";
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"sss", Context.MODE_MULTI_PROCESS);
		add = sharedPreferences.getString(name, "0");
		return add;
	}

	public static void setPathAddr(Context context, String path) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		Editor editor = sharedPreferences.edit();
		editor.putString("addrUrl", path);
		editor.commit();
	}

	public static String getMulticastAddr(Context context, String def) {
		String add = "";
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		add = sharedPreferences.getString("addrUrl", def);
		return add;
	}



	public static void setGroupIds(Context context, String groupIds) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		Editor editor = sharedPreferences.edit();
		editor.putString("groupIds", groupIds);
		editor.commit();
	}

	public static ArrayList<String> getGroupIds(Context context, String def) {
		ArrayList<String> resultList = new ArrayList<String>();
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		String strGroupIds = sharedPreferences.getString("groupIds", def);

		if (!strGroupIds.equals("")) {

			String[] strs = strGroupIds.split(",");

			for (int i = 0; i < strs.length; i++) {
				resultList.add(strs[i]);

			}
		}

		return resultList;
	}

	public static void setGroupNames(Context context, String groupNames) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		Editor editor = sharedPreferences.edit();
		editor.putString("groupNames", groupNames);
		editor.commit();
	}

	public static ArrayList<String> getGroupNames(Context context, String def) {
		ArrayList<String> resultList = new ArrayList<String>();
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCaller", Context.MODE_MULTI_PROCESS);
		String strGroupNames = sharedPreferences.getString("groupNames", def);

		if (!strGroupNames.equals("")) {

			String[] strs = strGroupNames.split(",");

			for (int i = 0; i < strs.length; i++) {
				resultList.add(strs[i]);
			}
		}

		return resultList;
	}

	public static void setIsOneMoreTime(Context context, boolean isSecend) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCallerisAnotherTime", Context.MODE_MULTI_PROCESS);
		Editor editor = sharedPreferences.edit();
		editor.putBoolean("aTime", isSecend);
		editor.commit();
	}

	public static boolean getIsOneMoreTime(Context context, boolean isSecend) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"jldCallerisAnotherTime", Context.MODE_MULTI_PROCESS);
		return sharedPreferences.getBoolean("aTime", isSecend);
	}

	public static boolean isServiceRunning(Context context) {
		ActivityManager manager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager
				.getRunningServices(Integer.MAX_VALUE)) {
			if ("jld.com.jld.audiobroadcast.client".equals(service.service
					.getClassName())) {
				return true;
			}
		}
		return false;
	}

}
