﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class LogInfo
    {
        public String LogId { get; set; }

        public String LogName { get; set; }

        public String LogDesp { get; set; }

        public String LogDate { get; set; }

    }

}
