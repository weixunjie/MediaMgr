package com.jld.jld.networkdebug.client;

import java.util.ArrayList;
import java.util.Map;

import com.jld.jld.networkdebug.utils.ProcessHelper;

import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.os.Build;

public class MainActivity extends Activity {

	private ArrayList<String> checkBoxList = new ArrayList<String>();

	private ArrayList<Integer> checkBoxSates = new ArrayList<Integer>();

	private TextView tvSend;
	private TextView tvFailed;
	private TextView tvSuc;

	private CheckBoxList cbList;
	private CheckBox cbAllGroups;

	private Button btnStartCall;

	private Button btnEndCall;
	private TextView tvVolValue;

	private Button btnVolAdd;

	private Button btnVolSub;

	private AudioManager mAudioManager = null;

	private int maxMusicAudio = 100;

	private int currentVolToSet = 0;

	private Context mContext;
	private ArrayList<String> groupListIds;
	private ArrayList<String> groupListNames;

	public interface statusChangedInterface {
		public void status_change(String statusText);
	}

	public static statusChangedInterface statusChanged;

	public interface commandNoticeInteface {
		public void command_Notice(String isOpen);
	}

	public static commandNoticeInteface commandNotice;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mContext = this;

		// GridView gvGroupList = (GridView) findViewById(R.id.gvGroupList);
		//
		// tvVolValue = (TextView) findViewById(R.id.tvVolValue);
		//
		// btnVolAdd = (Button) findViewById(R.id.btnVolAdd);
		// btnVolSub = (Button) findViewById(R.id.btnVolSub);
		//
		// mAudioManager = (AudioManager) getSystemService(this.AUDIO_SERVICE);
		//
		// maxMusicAudio = mAudioManager
		// .getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		//
		// currentVolToSet = mAudioManager
		// .getStreamVolume(AudioManager.STREAM_MUSIC);
		// tvVolValue.setText("������+" + currentVolToSet + ")");
		//
		// btnVolAdd.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// if (currentVolToSet < maxMusicAudio) {
		// currentVolToSet++;
		// }
		// mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
		// currentVolToSet, AudioManager.FLAG_SHOW_UI);
		// tvVolValue.setText("������+" + currentVolToSet + ")");
		//
		// }
		// });
		//
		// btnVolSub.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// if (currentVolToSet > 0) {
		// currentVolToSet--;
		// }
		// mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
		// currentVolToSet, AudioManager.FLAG_SHOW_UI);
		// tvVolValue.setText("������+" + currentVolToSet + ")");
		//
		// }
		// });
		//
		// tvConnState = (TextView) findViewById(R.id.tvConnState);
		// tvShowTime = (TextView) findViewById(R.id.tvShowTime);
		// cbList = new CheckBoxList(this);
		//
		// cbAllGroups = (CheckBox) findViewById(R.id.cbAllGroups);
		//
		// cbAllGroups.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// for (int i = 0; i < checkBoxSates.size(); i++) {
		// Integer status = 0;
		// if (cbAllGroups.isChecked()) {
		// status = 1;
		// }
		// checkBoxSates.set(i, status);
		//
		// }
		//
		// cbList.notifyDataSetChanged();
		//
		// }
		// });
		//
		String url = ProcessHelper.getMulticastAddr(this, "");

		if (url.equals("")) {
			showSettingDialog();
		} else {

			if (ProcessHelper.isServiceRunning(this)) {
				Intent intent = new Intent();
				intent.setClass(this, MainService.class);
				this.stopService(intent);

			} else {

				Intent intent = new Intent();
				intent.setClass(this, MainService.class);
				startService(intent);
				// finish();
			}
		}

		commandNotice = new commandNoticeInteface() {

			@Override
			public void command_Notice(String commandType) {

				Message msg = new Message();

				msg.obj = commandType;
				msg.what = 2;
				mHandlerRefreshUI.sendMessage(msg);

			}

		};


		
		Button btmREst=(Button) findViewById(R.id.btmREst);
		btmREst.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				
			 ProcessHelper.setTimeValue(mContext, "TotalTime", "0");
			 ProcessHelper.setTimeValue(mContext, "Suc", "0");
			 ProcessHelper.setTimeValue(mContext, "Failed", "0");
				
			}
		});
		tvSend = (TextView) findViewById(R.id.tvSent);
		tvFailed = (TextView) findViewById(R.id.tvFail);
		tvSuc = (TextView) findViewById(R.id.tvSuc);
		 
		// btnStartCall.setOnClickListener(new View.OnClickListener() {
		//
		//
		// regCallBack();
		// gvGroupList.setAdapter(cbList);
		// loadGroupsInfo();
		//
		// btnStartCall = (Button) findViewById(R.id.btnStartCall);
		// btnEndCall = (Button) findViewById(R.id.btnStopCall);
		// btnStartCall.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// String groupIds = "";
		// boolean isNotSelectedGroup = true;
		// for (int i = 0; i < checkBoxSates.size(); i++) {
		//
		// if (checkBoxSates.get(i) == 1) {
		// isNotSelectedGroup = false;
		// groupIds = groupIds + groupListIds.get(i) + ",";
		// }
		//
		// }
		//
		// if (isNotSelectedGroup) {
		// Dialog alertDialog = new AlertDialog.Builder(mContext)
		// .setTitle("����̨����").setMessage("��ѡ��Ҫ���еķ���").create();
		// alertDialog.show();
		// } else {
		//
		// groupIds = groupIds.substring(0, groupIds.length() - 1);
		// ProcessHelper.processUIRequest(true, groupIds);
		//
		// btnEndCall.setVisibility(View.VISIBLE);
		// //btnStartCall.setVisibility(View.VIS);
		//
		// }
		//
		// }
		// });
		//
		// btnEndCall.setOnClickListener(new View.OnClickListener() {
		//
		// @Override
		// public void onClick(View arg0) {
		//
		// ProcessHelper.processUIRequest(false, "");
		//
		// btnEndCall.setVisibility(View.INVISIBLE);
		// btnStartCall.setVisibility(View.VISIBLE);
		//
		// }
		// });
		//
		// new TimeThread().start();

	}

	private void regCallBack() {
		statusChanged = new statusChangedInterface() {

			@Override
			public void status_change(String statusText) {

				Message msg = new Message();
				msg.obj = statusText;
				msg.what = 1;
				mHandlerRefreshUI.sendMessage(msg);

			}

		};

	}

	private void loadGroupsInfo() {
		groupListIds = ProcessHelper.getGroupIds(mContext, "");
		groupListNames = ProcessHelper.getGroupNames(mContext, "");
		checkBoxList = groupListNames;

		checkBoxSates = new ArrayList<Integer>();

		for (int i = 0; i < checkBoxList.size(); i++) {
			checkBoxSates.add(0);
		}

		cbList.notifyDataSetChanged();
	}

	private void showSettingDialog() {

		LayoutInflater factory = LayoutInflater.from(mContext);
		final View textEntryView = factory
				.inflate(R.layout.serversetting, null);

		EditText addrEdit = new EditText(mContext);

		addrEdit.setText(ProcessHelper.getMulticastAddr(mContext, ""));

		AlertDialog dlg = new AlertDialog.Builder(mContext)
				.setTitle("��������ַ")
				.setView(textEntryView)
				.setPositiveButton("��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						EditText addrEdit = (EditText) textEntryView
								.findViewById(R.id.addr_edit);
						String addr = addrEdit.getText().toString();

						if (addr != null && !"".equals(addr)) {

							ProcessHelper.setPathAddr(mContext, addr);

							if (ProcessHelper.isServiceRunning(mContext)) {
								// notifyServer(COMMAND_CLIENT_UPDATEADDR);

								Intent intent = new Intent();
								intent.setClass(mContext, MainService.class);
								mContext.stopService(intent);

							} else {

								Intent intent = new Intent();
								intent.setClass(mContext, MainService.class);
								startService(intent);
								// finish();
							}

							// Toast.makeText(
							// mContext,
							// mContext.getString(R.string.serversettingok),
							// Toast.LENGTH_LONG).show();
							// finish();
						} else {
							// Dialog mDialog = new
							// MyDialog(mContext,R.style.MyDialog);
							// mDialog.show();
						}
					}
				})
				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {

					}
				}).create();
		dlg.show();
	}

	public class TimeThread extends Thread {
		@Override
		public void run() {
			do {
				try {
					Thread.sleep(1000);
					Message msg = new Message();
					msg.what = 1;
					handlerShowTime.sendMessage(msg);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} while (true);
		}
	}

	private Handler handlerShowTime = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);

		}
	};

	private Handler mHandlerRefreshUI = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);

			tvSend.setText("Total:"
					+ ProcessHelper.getTimeValue(mContext, "TotalTime"));

			tvFailed.setText("Suc:"
					+ ProcessHelper.getTimeValue(mContext, "Suc"));
			tvSuc.setText("Failed:"
					+ ProcessHelper.getTimeValue(mContext, "Failed"));

			// switch (msg.what) {
			//
			// case 2:
			//
			// String str = msg.obj.toString();
			//
			// if (str.equals("3")) {
			// loadGroupsInfo();
			// } else {
			//
			// if (str.equals("1")) {
			//
			// btnStartCall.setVisibility(View.INVISIBLE);
			//
			// btnEndCall.setVisibility(View.VISIBLE);
			//
			// } else {
			//
			// btnStartCall.setVisibility(View.VISIBLE);
			//
			// btnEndCall.setVisibility(View.INVISIBLE);
			// }
			//
			// }
			// break;
			// default:
			// break;
			// }
		}
	};

	public class CheckBoxList extends BaseAdapter {
		Activity activity;
		LayoutInflater inflater;

		// construct
		public CheckBoxList(Activity a) {
			activity = a;
			inflater = LayoutInflater.from(activity);
		}

		@Override
		public int getCount() {
			return checkBoxList.size();
		}

		@Override
		public Object getItem(int position) {
			return checkBoxList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub

			if (arg1 == null) {
				arg1 = inflater.inflate(R.layout.checkbox_item, null);
				// arg1.setTag(im);

			}

			CheckBox ctv = (CheckBox) arg1.findViewById(R.id.ct_Item);

			ctv.setChecked(checkBoxSates.get(arg0) == 1);

			ctv.setText(checkBoxList.get(arg0));

			ctv.setTag(arg0);
			ctv.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
					// TODO Auto-generated method stub

					Integer selInt = 0;
					if (arg1) {
						selInt = 1;
					} else

					{

						cbAllGroups.setChecked(false);
					}

					checkBoxSates.set(
							Integer.valueOf(arg0.getTag().toString()), selInt);

				}
			});

			return arg1;
		}
	}

}
