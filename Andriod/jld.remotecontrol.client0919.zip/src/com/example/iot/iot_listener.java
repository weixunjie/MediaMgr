package com.example.iot;

public interface iot_listener {
	
	public int  received_message(byte[] value);
}
