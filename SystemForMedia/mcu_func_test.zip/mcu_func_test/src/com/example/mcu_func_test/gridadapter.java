package com.example.mcu_func_test;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import android.R.integer;

public class gridadapter extends BaseAdapter {
	
	private LayoutInflater inflater;
	private List<Picture> pictures;
	public gridadapter(String[] titles, int[] images,Context context)
	{
		super();
		inflater=LayoutInflater.from(context);
		
		pictures=new ArrayList<Picture>();
		for(int i=0;i<images.length;i++)
		{
			Picture picture=new Picture(titles[i], images[i]);
			pictures.add(picture);
			
		}
			
	}
	
	public int getCount()
	{
		return pictures.size();
	}
	
	public  Object getItem(int arg0)
	{
		return pictures.get(arg0);
		
	}
	
	public long getItemId(int arg0)
	{
		
		return arg0;
	}
	
	public View getView(int arg0,View arg1,ViewGroup arg2)
	{
		ViewHolder  viewHolder;
		if(arg1==null)
		{
			arg1=inflater.inflate(R.layout.grid, null);
			viewHolder = new ViewHolder();
			viewHolder.title= (TextView) arg1.findViewById(R.id.Item_Title);
			viewHolder.image=(ImageView) arg1.findViewById(R.id.ItemImage);
			arg1.setTag(viewHolder);
			
		}
		else {
			viewHolder=(ViewHolder)arg1.getTag();
		}
		
		viewHolder.title.setText(pictures.get(arg0).getTitle());
		viewHolder.image.setImageResource(pictures.get(arg0).getimageid());
		return arg1;
	}
	
	public class ViewHolder {
		
		public TextView title;
		public ImageView image;

	}
	 private class Picture {
			private  String title;
			private  int imageid;

			public Picture()
			{
				super();
			}
			
			public Picture(String title,int imageid)
			{
				super();
				this.title=title;
				this.imageid=imageid;
			}
			
			public String getTitle()
			{
				return title;
			}
			
			public void setTitle(String title)
			{
				
				this.title=title;
			}
			
			public int getimageid()
			{
				return imageid;
			}
			
			public void setimageid(int id)
			{
				
				this.imageid=id;
			}
			
			
		}
	
	

}
