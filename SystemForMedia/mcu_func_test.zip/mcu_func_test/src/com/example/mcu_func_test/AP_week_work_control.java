package com.example.mcu_func_test;



import android.R.integer;
import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class AP_week_work_control extends Activity {
	
	private EditText et1,et2,et3,et4,et5,et6,et7;
	private Button  bt_en;
	
	private boolean enable(boolean en)
	{
	         boolean ret;
	         int[] week_value={0,0,0,0,0,0,0};
	         if((et1.length() <1) || (et2.length()<1) || (et3.length()<1) ||(et4.length()<1) || (et5.length()<1) || (et6.length()<1 )|| (et7.length()<1) )
	         { 
	        	 Toast.makeText(getApplicationContext(), "输入为空", Toast.LENGTH_SHORT).show();
	        	 return true;
	         }
	        	  week_value[0]=et7.getText().toString().charAt(0)-0x30;
	        	  week_value[1]=et1.getText().toString().charAt(0)-0x30;
	        	  week_value[2]=et2.getText().toString().charAt(0)-0x30;
	        	  week_value[3]=et3.getText().toString().charAt(0)-0x30;
	        	  week_value[4]=et4.getText().toString().charAt(0)-0x30;
	        	  week_value[5]=et5.getText().toString().charAt(0)-0x30;
	        	  week_value[6]=et6.getText().toString().charAt(0)-0x30;
	       
	    
	    
            ret=MainActivity.mSerialManager.enable_onoff_by_week( week_value);

        		//ret=MainActivity.mSerialManager.get_autopower_command();
			if(ret==en)
			return true;
			else
			return false;
			
        	}
		

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ap_week_work_control);

		et1=(EditText) findViewById(R.id.week_get1);
		et2=(EditText) findViewById(R.id.week_get2);
		et3=(EditText) findViewById(R.id.week_get3);
		et4=(EditText) findViewById(R.id.week_get4);
		et5=(EditText) findViewById(R.id.week_get5);
		et6=(EditText) findViewById(R.id.week_get6);
		et7=(EditText) findViewById(R.id.week_get7);
	
		

		bt_en=(Button) findViewById(R.id.enable);
		 
		
		
		bt_en.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				enable(true);
			}
		});
	
	
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ap_week_work_control, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(
					R.layout.fragment_ap_week_work_control, container, false);
			return rootView;
		}
	}

}
