package com.jld.jld.audiobroadcast.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.jld.jld.audiobroadcast.utils.ProcessHelper;

import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.os.Build;

public class ActivityChooseGroupClass extends Activity {

	private ArrayList<String> checkBoxList = new ArrayList<String>();

	private ArrayList<Integer> checkBoxSates = new ArrayList<Integer>();

	private CheckBoxListForGroupClass cbList;

	private boolean isListForGroup = true;

	private ArrayList<String> groupListIds;
	private ArrayList<String> groupListNames;

	private ArrayList<String> classListIds;
	private ArrayList<String> classListNames;

	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_select_group_class);

		mContext = this;

		Intent intent = this.getIntent();

		String IsByGroup = intent.getStringExtra("IsByGroup");

		isListForGroup = IsByGroup.equals("Y");

		Button btnConfirmSel = (Button) findViewById(R.id.btnComfirmSel);
		btnConfirmSel.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				if (isListForGroup) {
					String groupIds = "";

					ArrayList<String> selGroupIdArray = new ArrayList<String>();
					ArrayList<String> selGroupNameArray = new ArrayList<String>();

					for (int i = 0; i < checkBoxSates.size(); i++) {

						if (checkBoxSates.get(i) == 1) {

							// isNotSelectedGroup = false;
							groupIds = groupIds + groupListIds.get(i) + ",";
							selGroupIdArray.add(groupListIds.get(i));
							selGroupNameArray.add(groupListNames.get(i));
						}

					}

					Intent it = new Intent();

					it.putStringArrayListExtra("groupIdsArray", selGroupIdArray);
					it.putStringArrayListExtra("groupNamesArray",
							selGroupNameArray);

					it.putExtra("groupIds", groupIds);
					setResult(200, it);
					finish();
				} else {

					String devIds = "";
					ArrayList<String> selDevIdArray = new ArrayList<String>();
					ArrayList<String> selDevNameArray = new ArrayList<String>();
					for (int i = 0; i < checkBoxSates.size(); i++) {

						if (checkBoxSates.get(i) == 1) {

							// isNotSelectedGroup = false;
							devIds = devIds + classListIds.get(i) + ",";

							selDevIdArray.add(classListIds.get(i));
							selDevNameArray.add(classListNames.get(i));
						}

					}

					Intent it = new Intent();
					it.putExtra("devIds", devIds);
					it.putStringArrayListExtra("devIdsArray", selDevIdArray);
					it.putStringArrayListExtra("devNamesArray", selDevNameArray);
					setResult(201, it);
					finish();

				}

				// TODO Auto-generated method stub

			}
		});

		Button btnCacelSel = (Button) findViewById(R.id.btnCacelSel);
		btnCacelSel.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				Intent it = new Intent();
				setResult(300, it);
				finish();

				// TODO Auto-generated method stub

			}
		});

		GridView gvGroupAndClassList = (GridView) findViewById(R.id.gvGroupAndClassList);

		cbList = new CheckBoxListForGroupClass(this);

		gvGroupAndClassList.setAdapter(cbList);
		if (isListForGroup) {
			loadGroupsInfo();
		} else {
			loadClassInfo();
		}

	}

	private void loadGroupsInfo() {
		groupListIds = ProcessHelper.getGroupIds(mContext, "");
		groupListNames = ProcessHelper.getGroupNames(mContext, "");
		checkBoxList = groupListNames;

		checkBoxSates = new ArrayList<Integer>();

		for (int i = 0; i < checkBoxList.size(); i++) {
			checkBoxSates.add(0);
		}

		cbList.notifyDataSetChanged();
	}

	private void loadClassInfo() {
		classListIds = ProcessHelper.getDeviceIds(mContext, "");
		classListNames = ProcessHelper.getDevNames(mContext, "");
		checkBoxList = classListNames;

		checkBoxSates = new ArrayList<Integer>();

		for (int i = 0; i < checkBoxList.size(); i++) {
			checkBoxSates.add(0);
		}

		cbList.notifyDataSetChanged();
	}

	public class CheckBoxListForGroupClass extends BaseAdapter {
		Activity activity;
		LayoutInflater inflater;

		// construct
		public CheckBoxListForGroupClass(Activity a) {
			activity = a;
			inflater = LayoutInflater.from(activity);
		}

		@Override
		public int getCount() {
			return checkBoxList.size();
		}

		@Override
		public Object getItem(int position) {
			return checkBoxList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub

			if (arg1 == null) {
				if (isListForGroup) {
					arg1 = inflater.inflate(R.layout.checkbox_item_for_group,
							null);
				} else

				{
					arg1 = inflater.inflate(R.layout.checkbox_item_for_class,
							null);

				}
				// arg1.setTag(im);

			}

			ToggleButton tbItem = null;
			TextView tvItemText = null;

			if (isListForGroup) {

				tbItem = (ToggleButton) arg1.findViewById(R.id.tbGroupItem);
				tvItemText = (TextView) arg1.findViewById(R.id.tbGroupItemText);

				tvItemText.setTag(tbItem);
				tvItemText.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub

						ToggleButton tb = (ToggleButton) arg0.getTag();
						tb.setChecked(!tb.isChecked());
					}
				});

			} else {

				tbItem = (ToggleButton) arg1.findViewById(R.id.tbClassItem);
				tvItemText = (TextView) arg1.findViewById(R.id.tbClassItemText);

				tvItemText.setTag(tbItem);
				tvItemText.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub

						ToggleButton tb = (ToggleButton) arg0.getTag();
						tb.setChecked(!tb.isChecked());
					}
				});

			}

			tbItem.setText("");

			tbItem.setChecked(checkBoxSates.get(arg0) == 1);

			tvItemText.setText(checkBoxList.get(arg0));

			tbItem.setTag(arg0);
			tbItem.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
					// TODO Auto-generated method stub

					Integer selInt = 0;
					if (arg1) {
						selInt = 1;
					} else {
						// cbAllGroups.setChecked(false);
					}

					checkBoxSates.set(
							Integer.valueOf(arg0.getTag().toString()), selInt);

				}
			});

			return arg1;
		}
	}

}
