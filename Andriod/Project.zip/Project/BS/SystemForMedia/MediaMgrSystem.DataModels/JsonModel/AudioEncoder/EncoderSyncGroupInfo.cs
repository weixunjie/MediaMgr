﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public class EncoderSyncGroupInfo
    {
        public String groupId { get; set; }

        public String groupName { get; set; }

     


    }
}
