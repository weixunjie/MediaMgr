package com.datamodels;

import java.io.Serializable;
import java.util.List;

public class ScheduleInfo
  implements Serializable
{
  private List<TaskInfo> tasks;
  
  public List<TaskInfo> getTasks()
  {
    return this.tasks;
  }
  
  public void setTasks(List<TaskInfo> paramList)
  {
    this.tasks = paramList;
  }
}
