﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaMgrSystem.DataModels
{
    public enum RemoveControlDeviceType
    {
        NONE,
        AC=1,
        TV=2,
        PROJECTOR=3,
        COMPUTER=4,
        LIGHT=5


    }
}
