package com.example.mcu_func_test;



import android.R.integer;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.os.Build;
import android.hardware.SerialManager;
import android.hardware.SerialPort;

import java.nio.ByteBuffer;
import java.io.IOException;

public class AP_data_work_control extends Activity {
	private Switch  sw;

	private boolean enable(boolean en)
	{
		

	   int value= (en==true)? 1:0;
	    boolean ret;
            ret=MainActivity.mSerialManager.enable_onoff_by_day((int)value);
	    if(ret==true) 
        	{
              int re;
        		re=MainActivity.mSerialManager.check_onoff_by_day();
			if(re==1)
			return true;
			else
			return false;
			
        	}
		else
		{
			return false;
		}

	}



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ap_data_work_control);

		sw=(Switch)findViewById(R.id.set_ap_by_day);
		



		 sw.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			   
			   @Override
			   public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			
			    // TODO Auto-generated method stub
			    if(isChecked)
			    {
			     
			     if(enable(true))
			     {
	    			 
			     	Log.e("pengyong", "AP_data_work_control 打开ok");
			     }
			     else
			     {

			     	Log.e("pengyong", "AP_data_work_control 打开fail");
			      sw.setChecked(false);
			     }
			
			     Log.e("pengyong", "AP_data_work_control 打开中");
			    }
			    else {
			      Log.e("pengyong", "AP_data_work_control关闭中");
			     
			     if(enable(false))
			      {

			      Log.e("pengyong", "AP_data_work_control关闭ok");
			      }
			      else
			      {
			       sw.setChecked(true);

			      Log.e("pengyong", "AP_data_work_control关闭fail");
			      }
			    }

			   }
			  });
		
		
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ap_data_work_control, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(
					R.layout.fragment_ap_data_work_control, container, false);
			return rootView;
		}
	}

}
